package com.altay.denizgizem

data class SearchBundle(
    val regionKey: String,
    val categoryKey: String,
    val items: List<PlaceItem>,
    val offlineCount: Int,
    val liveCount: Int,
    val liveOk: Boolean,
    val deepPending: Boolean,
    val status: String
)

object PlaceRepository {
    fun offline(region: String, category: CategorySpec): SearchBundle {
        val local = OfflineCatalog.find(region, category.key)
        return SearchBundle(
            regionKey=TextNorm.norm(region), categoryKey=category.key,
            items=local.take(15), offlineCount=local.size, liveCount=0,
            liveOk=false, deepPending=true,
            status=if(local.isNotEmpty())
                "${local.size} doğrulanmış sonuç anında hazır"
            else
                "⚡ Güvenli canlı arama başlatıldı"
        )
    }

    fun quick(region: String, category: CategorySpec): SearchBundle {
        val local = OfflineCatalog.find(region, category.key)
        return try {
            val quick = LiveOsmClient.quickSearch(region, category)
            val merged = finalGate(region, category, SafetyRules.mergeAndRank(local, quick)).take(15)
            SearchBundle(
                regionKey=TextNorm.norm(region), categoryKey=category.key,
                items=merged, offlineCount=local.size, liveCount=quick.size,
                liveOk=true, deepPending=true,
                status=when {
                    merged.isEmpty() -> "İlk güvenli taramada eşleşme çıkmadı; derin tarama sürüyor"
                    quick.isEmpty() && local.isNotEmpty() -> "Doğrulanmış sonuçlar hazır; daha fazla yer aranıyor"
                    else -> "⚡ ${merged.size} kategori-doğrulanmış sonuç hazır • derin tarama sürüyor"
                }
            )
        } catch (_: Throwable) {
            SearchBundle(
                regionKey=TextNorm.norm(region), categoryKey=category.key,
                items=local.take(15), offlineCount=local.size, liveCount=0,
                liveOk=local.isNotEmpty(), deepPending=true,
                status=if(local.isNotEmpty()) "Doğrulanmış sonuçlar hazır • derin tarama sürüyor"
                else "Hızlı kaynak cevap vermedi • derin tarama sürüyor"
            )
        }
    }

    fun deep(region: String, category: CategorySpec, current: List<PlaceItem>): SearchBundle {
        val local = OfflineCatalog.find(region, category.key)
        var osmOk = false
        val osm = try {
            LiveOsmClient.deepSearch(region, category).also { osmOk = true }
        } catch (_: Throwable) {
            emptyList()
        }

        // Efsane/Gizem için OSM tek başına yeterli değildir. Anahtarsız Türkçe Vikipedi
        // aramasıyla yerel anlatılar taranır ve ayrıca sert bölge/efsane filtresinden geçirilir.
        var wikiOk = false
        val wiki = if (category.key == "gizem") {
            try { WikiLegendClient.search(region).also { wikiOk = true } } catch (_: Throwable) { emptyList() }
        } else emptyList()

        val merged = finalGate(
            region,
            category,
            SafetyRules.mergeAndRank(
                SafetyRules.mergeAndRank(local, current),
                SafetyRules.mergeAndRank(osm, wiki)
            )
        ).take(20)

        val status = when {
            merged.isEmpty() && category.key == "gizem" && wikiOk ->
                "Bu bölgede kaynaklı efsane/anlatı eşleşmesi bulunamadı; alakasız tarihî yer göstermiyoruz"
            merged.isEmpty() -> "Bu bölgede güvenilir kategori eşleşmesi bulunamadı; yanlış sonuç göstermiyoruz"
            category.key == "gizem" && wikiOk -> "✅ ${merged.size} kaynaklı yerel anlatı • Vikipedi + harita doğrulaması"
            osmOk -> "✅ ${merged.size} güvenli sonuç • sert kategori koruması aktif"
            else -> "Mevcut doğrulanmış sonuçlar gösteriliyor; canlı kaynak geçici olarak cevap vermedi"
        }

        return SearchBundle(
            regionKey=TextNorm.norm(region), categoryKey=category.key,
            items=merged, offlineCount=local.size,
            liveCount=merged.count { it.live }, liveOk=merged.isNotEmpty(), deepPending=false,
            status=status
        )
    }

    fun finalGate(region: String, category: CategorySpec, items: List<PlaceItem>): List<PlaceItem> =
        SafetyRules.dedupe(items)
            .filter { it.categoryKey == category.key }
            .filter { SafetyRules.isMeaningfulName(it.name) }
            .filter { TextNorm.containsRegionEvidence("${it.area} ${it.address}", region) }
            .sortedByDescending { it.smartScore() }
}
