package com.altay.denizgizem

import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

/**
 * API anahtarı gerektirmeyen yerel efsane/gizem kaynağı.
 * Türkçe Vikipedi'nin MediaWiki API'sinde bölge + efsane/mitoloji araması yapar,
 * yalnız bölge ve anlatı kanıtı bulunan sayfaları kabul eder.
 */
object WikiLegendClient {
    private const val API = "https://tr.wikipedia.org/w/api.php"
    private const val USER_AGENT = "DenizGizemGeziAsistani/14.0 (personal travel search; Turkiye)"

    private val storyWords = listOf(
        "efsane", "söylence", "soylence", "mitoloji", "mitolojik", "rivayet", "destan",
        "halk inan", "anlatı", "anlati", "şahmeran", "sahmeran", "şahmaran", "sahmaran",
        "yedi uyurlar", "eshab", "kehf", "lokman", "ejder", "peri", "cin", "kehanet",
        "kutsal", "efsanevi", "myth", "legend"
    ).map(TextNorm::norm)

    private val blockedTitleWords = listOf(
        "liste", "kategori", "ilçeleri", "ilceleri", "belediyesi", "seçimleri", "secimleri"
    ).map(TextNorm::norm)

    fun search(region: String): List<PlaceItem> {
        val regionTrim = region.trim()
        if (regionTrim.length < 2) return emptyList()

        val queries = listOf(
            "$regionTrim efsane",
            "$regionTrim mitoloji rivayet"
        )

        val all = mutableListOf<PlaceItem>()
        queries.forEach { q ->
            try { all += searchOne(regionTrim, q) } catch (_: Throwable) { }
        }
        return SafetyRules.dedupe(all)
            .sortedByDescending { it.smartScore() }
            .take(8)
    }

    @Suppress("UNCHECKED_CAST")
    fun parseResponse(body: String, region: String): List<PlaceItem> {
        val root = MiniJson.parse(body) as? Map<String, Any?> ?: return emptyList()
        val query = root["query"] as? Map<String, Any?> ?: return emptyList()
        val pages = query["pages"] as? Map<String, Any?> ?: return emptyList()
        val out = mutableListOf<PlaceItem>()

        pages.values.forEach { raw ->
            val page = raw as? Map<String, Any?> ?: return@forEach
            val title = page["title"]?.toString()?.trim().orEmpty()
            val extract = cleanText(page["extract"]?.toString().orEmpty())
            if (!SafetyRules.isMeaningfulName(title) || extract.length < 40) return@forEach

            val titleNorm = TextNorm.norm(title)
            val combined = TextNorm.norm("$title $extract")
            if (blockedTitleWords.any { titleNorm.contains(it) }) return@forEach
            if (!TextNorm.containsRegionEvidence("$title $extract", region)) return@forEach
            if (storyWords.none { combined.contains(it) }) return@forEach

            val short = shortStory(extract)
            if (short.length < 55) return@forEach
            out += PlaceItem(
                name = title,
                categoryKey = "gizem",
                group = Group.DISCOVER,
                area = region,
                why = "EFSANE / ANLATI ÖZETİ: $short",
                tags = listOf("📚 Vikipedi", "Yerel anlatı", "Kaynaklı"),
                sourceLabel = "Türkçe Vikipedi (MediaWiki API)",
                routeQuery = "$title $region",
                verified = true,
                fameScore = 7,
                localScore = 9,
                typeScore = 10,
                live = true
            )
        }
        return out
    }

    private fun searchOne(region: String, search: String): List<PlaceItem> {
        val url = "$API?action=query&generator=search&gsrnamespace=0&gsrlimit=8" +
            "&gsrsearch=${enc(search)}&prop=extracts&exintro=1&explaintext=1&exsentences=5" +
            "&redirects=1&format=json&formatversion=1&utf8=1"
        return parseResponse(get(url), region)
    }

    private fun shortStory(text: String): String {
        val clean = cleanText(text)
        if (clean.length <= 420) return clean
        val sentences = clean.split(Regex("(?<=[.!?])\\s+"))
        val picked = mutableListOf<String>()
        var size = 0
        for (s in sentences) {
            if (s.isBlank()) continue
            if (size + s.length > 420 && picked.isNotEmpty()) break
            picked += s.trim()
            size += s.length + 1
            if (picked.size >= 3) break
        }
        return picked.joinToString(" ").take(420).trim()
    }

    private fun cleanText(s: String): String = s
        .replace("&nbsp;", " ")
        .replace("&amp;", "&")
        .replace("&quot;", "\"")
        .replace("&#39;", "'")
        .replace(Regex("<[^>]+>"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "GET"
        c.connectTimeout = 5000
        c.readTimeout = 7000
        c.setRequestProperty("User-Agent", USER_AGENT)
        c.setRequestProperty("Accept", "application/json")
        val code = c.responseCode
        val input = if (code in 200..299) c.inputStream else c.errorStream
        val body = BufferedReader(InputStreamReader(input, StandardCharsets.UTF_8)).use { r ->
            buildString { while (true) { val line = r.readLine() ?: break; append(line) } }
        }
        c.disconnect()
        if (code !in 200..299) error("Wikipedia HTTP $code")
        return body
    }

    private fun enc(s: String): String = URLEncoder.encode(s, StandardCharsets.UTF_8)
}
