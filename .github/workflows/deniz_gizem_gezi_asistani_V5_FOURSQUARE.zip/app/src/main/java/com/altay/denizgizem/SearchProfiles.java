package com.altay.denizgizem;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class SearchProfiles {

    public static final class Profile {
        public final String group;
        public final String label;
        public final String query;
        public final String sort;
        public final boolean cheapLocal;

        public Profile(String group, String label, String query, String sort, boolean cheapLocal) {
            this.group = group;
            this.label = label;
            this.query = query;
            this.sort = sort;
            this.cheapLocal = cheapLocal;
        }
    }

    private SearchProfiles() {}

    public static List<Profile> forGroup(String group) {
        switch (group) {
            case "food":
                return Arrays.asList(
                    p("food", "🥩 Ciğer / Arnavut", "ciğer", "RATING", true),
                    p("food", "🧆 Köfte", "köfte", "RATING", true),
                    p("food", "🔥 Kebap", "kebap", "RATING", true),
                    p("food", "🍲 Sulu Yemek", "sulu yemek", "RATING", true),
                    p("food", "🍗 Tavuk", "tavuk", "RATING", true),
                    p("food", "🥘 Esnaf Lokantası", "esnaf lokantası", "RATING", true),
                    p("food", "🐟 Balık", "balık", "RATING", true),
                    p("food", "🍳 Kahvaltı", "kahvaltı", "RATING", true)
                );
            case "sea":
                return Arrays.asList(
                    p("sea", "🏖️ En İyi Plajlar", "plaj", "RATING", false),
                    p("sea", "👣 Kum / Sığ Deniz", "kum plaj", "RATING", false),
                    p("sea", "🌊 Sakin Koy", "koy", "RATING", false)
                );
            case "discover":
                return Arrays.asList(
                    p("discover", "🏺 Antik Kent", "antik kent", "RATING", false),
                    p("discover", "🏰 Kale", "kale", "RATING", false),
                    p("discover", "🕳️ Mağara", "mağara", "RATING", false),
                    p("discover", "🏛️ Müze", "müze", "RATING", false),
                    p("discover", "📜 Tarihi Yer", "tarihi yer", "RATING", false),
                    p("discover", "👁️ Gizemli Yer", "gizemli yer", "POPULARITY", false)
                );
            case "stay":
                return Arrays.asList(
                    p("stay", "🏡 Pansiyon", "pansiyon", "RATING", true),
                    p("stay", "🏢 Apart", "apart otel", "RATING", true),
                    p("stay", "🏨 Uygun Otel", "otel", "RATING", true),
                    p("stay", "⛺ Kamp", "kamp alanı", "RATING", true)
                );
            default:
                return Collections.emptyList();
        }
    }

    private static Profile p(String group, String label, String query, String sort, boolean cheapLocal) {
        return new Profile(group, label, query, sort, cheapLocal);
    }
}
