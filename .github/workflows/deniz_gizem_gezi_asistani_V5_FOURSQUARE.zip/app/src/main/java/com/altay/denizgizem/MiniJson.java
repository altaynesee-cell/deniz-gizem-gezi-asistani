package com.altay.denizgizem;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class MiniJson {
    private final String text;
    private int pos;

    private MiniJson(String text) {
        this.text = text == null ? "" : text;
    }

    public static Object parse(String text) {
        MiniJson p = new MiniJson(text);
        Object value = p.readValue();
        p.skipWs();
        if (p.pos != p.text.length()) {
            throw new IllegalArgumentException("JSON sonunda beklenmeyen veri var.");
        }
        return value;
    }

    private Object readValue() {
        skipWs();
        if (pos >= text.length()) throw new IllegalArgumentException("JSON boş.");

        char c = text.charAt(pos);
        if (c == '{') return readObject();
        if (c == '[') return readArray();
        if (c == '"') return readString();
        if (c == 't') { expect("true"); return Boolean.TRUE; }
        if (c == 'f') { expect("false"); return Boolean.FALSE; }
        if (c == 'n') { expect("null"); return null; }
        if (c == '-' || Character.isDigit(c)) return readNumber();

        throw new IllegalArgumentException("Geçersiz JSON karakteri: " + c);
    }

    private Map<String, Object> readObject() {
        Map<String, Object> out = new LinkedHashMap<>();
        expectChar('{');
        skipWs();
        if (peek('}')) { pos++; return out; }

        while (true) {
            skipWs();
            String key = readString();
            skipWs();
            expectChar(':');
            Object value = readValue();
            out.put(key, value);
            skipWs();

            if (peek('}')) { pos++; break; }
            expectChar(',');
        }
        return out;
    }

    private List<Object> readArray() {
        List<Object> out = new ArrayList<>();
        expectChar('[');
        skipWs();
        if (peek(']')) { pos++; return out; }

        while (true) {
            out.add(readValue());
            skipWs();
            if (peek(']')) { pos++; break; }
            expectChar(',');
        }
        return out;
    }

    private String readString() {
        expectChar('"');
        StringBuilder sb = new StringBuilder();

        while (pos < text.length()) {
            char c = text.charAt(pos++);
            if (c == '"') return sb.toString();

            if (c == '\\') {
                if (pos >= text.length()) throw new IllegalArgumentException("Eksik escape.");
                char e = text.charAt(pos++);
                switch (e) {
                    case '"': sb.append('"'); break;
                    case '\\': sb.append('\\'); break;
                    case '/': sb.append('/'); break;
                    case 'b': sb.append('\b'); break;
                    case 'f': sb.append('\f'); break;
                    case 'n': sb.append('\n'); break;
                    case 'r': sb.append('\r'); break;
                    case 't': sb.append('\t'); break;
                    case 'u':
                        if (pos + 4 > text.length()) throw new IllegalArgumentException("Eksik unicode.");
                        String hex = text.substring(pos, pos + 4);
                        sb.append((char) Integer.parseInt(hex, 16));
                        pos += 4;
                        break;
                    default: throw new IllegalArgumentException("Geçersiz escape: " + e);
                }
            } else {
                sb.append(c);
            }
        }

        throw new IllegalArgumentException("Kapanmayan string.");
    }

    private Number readNumber() {
        int start = pos;

        if (peek('-')) pos++;
        while (pos < text.length() && Character.isDigit(text.charAt(pos))) pos++;

        boolean decimal = false;
        if (peek('.')) {
            decimal = true;
            pos++;
            while (pos < text.length() && Character.isDigit(text.charAt(pos))) pos++;
        }

        if (pos < text.length() && (text.charAt(pos) == 'e' || text.charAt(pos) == 'E')) {
            decimal = true;
            pos++;
            if (pos < text.length() && (text.charAt(pos) == '+' || text.charAt(pos) == '-')) pos++;
            while (pos < text.length() && Character.isDigit(text.charAt(pos))) pos++;
        }

        String raw = text.substring(start, pos);
        return decimal ? Double.parseDouble(raw) : Long.parseLong(raw);
    }

    private void skipWs() {
        while (pos < text.length() && Character.isWhitespace(text.charAt(pos))) pos++;
    }

    private boolean peek(char c) {
        return pos < text.length() && text.charAt(pos) == c;
    }

    private void expectChar(char c) {
        skipWs();
        if (!peek(c)) throw new IllegalArgumentException("Beklenen karakter: " + c);
        pos++;
    }

    private void expect(String s) {
        if (!text.startsWith(s, pos)) throw new IllegalArgumentException("Beklenen: " + s);
        pos += s.length();
    }
}
