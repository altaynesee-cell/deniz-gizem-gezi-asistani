package com.altay.denizgizem;

import java.text.Normalizer;
import java.util.Locale;

public final class HeritageHints {
    private HeritageHints() {}

    public static String note(String region, String query, String placeName) {
        String r = n(region);
        String q = n(query);
        String p = n(placeName);

        if (r.contains("bodrum") && q.contains("ciger")) {
            if (p.contains("milas sofrasi") || p.contains("cigerci durmus")) {
                return "KÖKLÜ NOT: İşletmenin kendi tanıtımında 2000'den beri hizmet verdiği belirtiliyor; ciğer, sulu yemek ve ızgara öne çıkıyor.";
            }
        }

        return "";
    }

    private static String n(String s) {
        if (s == null) return "";
        String x = s.toLowerCase(new Locale("tr", "TR"))
                .replace('ı','i').replace('ğ','g').replace('ü','u')
                .replace('ş','s').replace('ö','o').replace('ç','c');
        x = Normalizer.normalize(x, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return x.replaceAll("[^a-z0-9]+", " ").trim();
    }
}
