package com.altay.denizgizem;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class MysteryData {

    private MysteryData() {}

    public static List<FoursquareClient.Place> find(String region) {
        String r = n(region);
        List<FoursquareClient.Place> out = new ArrayList<>();

        if (r.contains("bodrum")) {
            out.add(place(
                "Salmakis (Bardakçı) Koyu",
                "Bardakçı Koyu, Bodrum, Muğla",
                "EFSANE: Salmakis su perisi ile Hermaphroditos anlatısı Bodrum'daki antik Halikarnassos geleneğiyle ilişkilendirilir."
            ));
            out.add(place(
                "Halikarnassos Mausoleion",
                "Tepecik Mahallesi, Bodrum, Muğla",
                "GİZEM & TARİH: Karia Kralı Mausolos için yapılan anıt mezar, Antik Dünyanın Yedi Harikası arasında anılır."
            ));
            out.add(place(
                "Myndos Antik Kenti",
                "Gümüşlük, Bodrum, Muğla",
                "ARKEOLOJİK GİZEM: Antik Myndos çevresindeki nekropol ve yerleşim kalıntıları Bodrum yarımadasının en eski izleri arasındadır."
            ));
            out.add(place(
                "Bodrum Kalesi",
                "Çarşı, Bodrum, Muğla",
                "KARANLIK TARİH: Saint Jean Şövalyeleri tarafından inşa edilen kale daha sonraki dönemlerde hapishane olarak da kullanılmıştır."
            ));
        } else if (r.contains("antalya") || r.contains("kemer") || r.contains("cirali")) {
            out.add(place(
                "Yanartaş / Chimera",
                "Çıralı, Kemer, Antalya",
                "EFSANE: Kayalardan doğal olarak çıkan alevler antik Kimera anlatısıyla ilişkilendirilir."
            ));
            out.add(place(
                "Olympos Antik Kenti",
                "Olympos, Kumluca, Antalya",
                "ANTİK ATMOSFER: Likya-Roma kalıntıları, nekropol ve orman içindeki yerleşim dokusuyla güçlü bir keşif noktasıdır."
            ));
            out.add(place(
                "Termessos Antik Kenti",
                "Güllük Dağı, Antalya",
                "DAĞ KENTİ: Yüksek ve savunmalı konumu, nekropolü ve tiyatrosuyla sıra dışı bir antik kenttir."
            ));
        } else if (r.contains("mersin") || r.contains("silifke") || r.contains("kizkalesi")) {
            out.add(place(
                "Cennet-Cehennem Obrukları",
                "Narlıkuyu, Silifke, Mersin",
                "MİTOLOJİ: Büyük karst oluşumları antik Typhon anlatılarıyla ilişkilendirilir."
            ));
            out.add(place(
                "Kızkalesi",
                "Kızkalesi, Erdemli, Mersin",
                "EFSANE & TARİH: Deniz kalesi hem tarihî dokusu hem de yerel prenses efsanesiyle anılır."
            ));
            out.add(place(
                "Kanlıdivane",
                "Erdemli, Mersin",
                "ANTİK ATMOSFER: Büyük obruk çevresindeki antik yerleşim ve mezar yapılarıyla dikkat çeker."
            ));
        } else if (r.contains("bursa") || r.contains("iznik") || r.contains("golyazi")) {
            out.add(place(
                "Gölyazı",
                "Gölyazı, Nilüfer, Bursa",
                "EFSANELİ TARİH: Uluabat Gölü kıyısındaki antik Apollonia ad Rhyndacum yerleşimi ve ada dokusu."
            ));
            out.add(place(
                "İznik",
                "İznik, Bursa",
                "ÇOK KATMANLI TARİH: Roma, Bizans ve Osmanlı dönemlerinin izlerini taşıyan tarihî merkez."
            ));
        }

        return out;
    }

    private static FoursquareClient.Place place(String name, String address, String note) {
        FoursquareClient.Place p = new FoursquareClient.Place();
        p.name = name;
        p.address = address;
        p.categories = "Efsane • Gizem • Tarih";
        p.heritageNote = note;
        return p;
    }

    private static String n(String s) {
        if (s == null) return "";
        String x = s.toLowerCase(new Locale("tr", "TR"))
                .replace('ı','i').replace('ğ','g').replace('ü','u')
                .replace('ş','s').replace('ö','o').replace('ç','c');
        x = Normalizer.normalize(x, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return x.replaceAll("[^a-z0-9]+", " ").trim();
    }
}
