package com.altay.denizgizem;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

public final class FoursquareClient {

    public static final String ENDPOINT = "https://places-api.foursquare.com/places/search";
    public static final String API_VERSION = "2025-06-17";

    public static final class Place {
        public String id = "";
        public String name = "";
        public String address = "";
        public String categories = "";
        public String tel = "";
        public String website = "";
        public double latitude = Double.NaN;
        public double longitude = Double.NaN;
        public double rating = -1;
        public double popularity = -1;
        public int price = 0;
        public int distance = -1;
        public int totalRatings = -1;
        public String heritageNote = "";
    }

    public static final class SearchResult {
        public final List<Place> places;
        public final boolean premiumFieldsAvailable;
        public final boolean strictFilters;

        public SearchResult(List<Place> places, boolean premiumFieldsAvailable, boolean strictFilters) {
            this.places = places;
            this.premiumFieldsAvailable = premiumFieldsAvailable;
            this.strictFilters = strictFilters;
        }
    }

    public static final class ApiException extends Exception {
        public final int httpCode;
        public ApiException(int httpCode, String message) {
            super(message);
            this.httpCode = httpCode;
        }
    }

    private FoursquareClient() {}

    public static SearchResult search(
            String apiKey,
            String region,
            SearchProfiles.Profile profile,
            boolean strictFilters) throws Exception {

        if (apiKey == null || apiKey.trim().isEmpty()) {
            throw new ApiException(401, "Foursquare API anahtarı girilmemiş.");
        }
        if (region == null || region.trim().isEmpty()) {
            throw new IllegalArgumentException("Bölge boş.");
        }

        String near = normalizeNear(region);

        // FREE/PRO MODE:
        // Premium fields such as rating, price and popularity are NOT requested.
        // We still use sort=RATING so Foursquare can return the strongest-rated
        // matches first without exposing the premium numeric rating field.
        String proFields =
                "fsq_place_id,name,categories,location,latitude,longitude,distance,tel,website";

        HttpResponse response = request(
                apiKey,
                buildUrl(near, profile, strictFilters, proFields)
        );

        if (response.code < 200 || response.code >= 300) {
            throw apiError(response.code, response.body);
        }

        List<Place> places = parsePlaces(response.body, region, profile.query);

        // Preserve the order returned by Foursquare.
        // The API already applies the requested sort (RATING / RELEVANCE etc).
        return new SearchResult(places, false, strictFilters);
    }

    public static String buildUrl(
            String near,
            SearchProfiles.Profile profile,
            boolean strictFilters,
            String fields) {

        StringBuilder u = new StringBuilder(ENDPOINT);
        u.append("?near=").append(enc(near));
        u.append("&query=").append(enc(profile.query));
        u.append("&sort=").append(enc(profile.sort));
        u.append("&limit=20");
        u.append("&fields=").append(enc(fields));

        if (strictFilters && profile.cheapLocal) {
            u.append("&exclude_all_chains=true");
            u.append("&max_price=2");
        }

        return u.toString();
    }

    public static String normalizeNear(String region) {
        String s = region.trim();
        String lower = s.toLowerCase();
        if (lower.contains("türkiye") || lower.contains("turkiye") || lower.contains("turkey")) {
            return s;
        }
        return s + ", Türkiye";
    }

    @SuppressWarnings("unchecked")
    public static List<Place> parsePlaces(String json, String region, String query) {
        Object rootObj = MiniJson.parse(json);
        if (!(rootObj instanceof Map)) throw new IllegalArgumentException("API yanıtı nesne değil.");

        Map<String, Object> root = (Map<String, Object>) rootObj;
        Object resultsObj = root.get("results");

        List<Place> out = new ArrayList<>();
        if (!(resultsObj instanceof List)) return out;

        for (Object rowObj : (List<Object>) resultsObj) {
            if (!(rowObj instanceof Map)) continue;
            Map<String, Object> row = (Map<String, Object>) rowObj;

            Place p = new Place();
            p.id = str(row.get("fsq_place_id"));
            p.name = str(row.get("name"));
            p.latitude = num(row.get("latitude"), Double.NaN);
            p.longitude = num(row.get("longitude"), Double.NaN);
            p.distance = (int) num(row.get("distance"), -1);
            p.rating = num(row.get("rating"), -1);
            p.popularity = num(row.get("popularity"), -1);
            p.price = (int) num(row.get("price"), 0);
            p.tel = str(row.get("tel"));
            p.website = str(row.get("website"));

            Object locObj = row.get("location");
            if (locObj instanceof Map) {
                Map<String, Object> loc = (Map<String, Object>) locObj;
                String address = str(loc.get("address"));
                String locality = str(loc.get("locality"));
                String regionName = str(loc.get("region"));
                StringBuilder a = new StringBuilder();
                if (!address.isEmpty()) a.append(address);
                if (!locality.isEmpty()) {
                    if (a.length() > 0) a.append(", ");
                    a.append(locality);
                }
                if (!regionName.isEmpty() && !regionName.equalsIgnoreCase(locality)) {
                    if (a.length() > 0) a.append(", ");
                    a.append(regionName);
                }
                p.address = a.toString();
            }

            Object catsObj = row.get("categories");
            if (catsObj instanceof List) {
                StringBuilder c = new StringBuilder();
                for (Object catObj : (List<Object>) catsObj) {
                    if (!(catObj instanceof Map)) continue;
                    String name = str(((Map<String, Object>) catObj).get("name"));
                    if (!name.isEmpty()) {
                        if (c.length() > 0) c.append(" • ");
                        c.append(name);
                    }
                }
                p.categories = c.toString();
            }

            Object statsObj = row.get("stats");
            if (statsObj instanceof Map) {
                p.totalRatings = (int) num(((Map<String, Object>) statsObj).get("total_ratings"), -1);
            }

            p.heritageNote = HeritageHints.note(region, query, p.name);

            if (!p.name.isEmpty()) out.add(p);
        }

        return out;
    }

    private static void sortPlaces(List<Place> places, String sort) {
        Comparator<Place> heritageFirst = (a, b) -> {
            boolean ah = a.heritageNote != null && !a.heritageNote.isEmpty();
            boolean bh = b.heritageNote != null && !b.heritageNote.isEmpty();
            if (ah != bh) return ah ? -1 : 1;
            return 0;
        };

        Comparator<Place> rating = (a, b) -> Double.compare(b.rating, a.rating);
        Comparator<Place> popularity = (a, b) -> Double.compare(b.popularity, a.popularity);
        Comparator<Place> distance = (a, b) -> Integer.compare(
                a.distance < 0 ? Integer.MAX_VALUE : a.distance,
                b.distance < 0 ? Integer.MAX_VALUE : b.distance
        );

        Comparator<Place> cmp = heritageFirst;
        if ("POPULARITY".equals(sort)) cmp = cmp.thenComparing(popularity).thenComparing(rating);
        else cmp = cmp.thenComparing(rating).thenComparing(popularity);

        places.sort(cmp.thenComparing(distance));
    }

    private static HttpResponse request(String apiKey, String urlText) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(urlText).openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(12000);
        conn.setRequestProperty("Accept", "application/json");
        conn.setRequestProperty("Authorization", "Bearer " + apiKey.trim());
        conn.setRequestProperty("X-Places-Api-Version", API_VERSION);

        int code = conn.getResponseCode();
        InputStream stream = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();

        StringBuilder body = new StringBuilder();
        if (stream != null) {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) body.append(line);
            }
        }
        conn.disconnect();

        return new HttpResponse(code, body.toString());
    }

    @SuppressWarnings("unchecked")
    private static ApiException apiError(int code, String body) {
        String message;
        if (code == 401) message = "API anahtarı geçersiz veya iptal edilmiş.";
        else if (code == 429) message = "Foursquare kullanım sınırına ulaşıldı. Bir süre sonra tekrar dene.";
        else if (code == 400) message = "Bölge veya arama Foursquare tarafından çözülemedi.";
        else message = "Foursquare servis hatası (HTTP " + code + ").";

        try {
            Object root = MiniJson.parse(body);
            if (root instanceof Map) {
                Map<String, Object> m = (Map<String, Object>) root;
                String apiMessage = str(m.get("message"));
                if (apiMessage.isEmpty()) apiMessage = str(m.get("error"));
                if (!apiMessage.isEmpty()) message += " " + apiMessage;
            }
        } catch (Exception ignored) {}

        return new ApiException(code, message);
    }

    private static String enc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8);
    }

    private static String str(Object o) {
        return o == null ? "" : String.valueOf(o);
    }

    private static double num(Object o, double fallback) {
        return o instanceof Number ? ((Number) o).doubleValue() : fallback;
    }

    private static final class HttpResponse {
        final int code;
        final String body;
        HttpResponse(int code, String body) {
            this.code = code;
            this.body = body;
        }
    }
}
