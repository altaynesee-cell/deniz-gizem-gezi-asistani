package com.altay.denizgizem;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final String PREFS = "deniz_gizem_prefs";
    private static final String KEY_FSQ = "foursquare_service_key";

    private EditText regionInput;
    private EditText keyInput;
    private TextView keyStatus;
    private TextView status;
    private LinearLayout settingsBox;
    private LinearLayout optionBox;
    private LinearLayout resultBox;
    private ProgressBar progress;

    private String currentGroup = "food";
    private SearchProfiles.Profile lastProfile;
    private boolean lastStrict = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(14), dp(14), dp(12));

        TextView title = tv("DENİZ GİZEM\nGEZİ ASİSTANI", 24, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView sub = tv(
                "Salaş ve yerel lezzetler, plajlar, keşif ve konaklama. Sonuçlar uygulamanın içinde; yol tarifi tek tuş.",
                14, false);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(4), 0, dp(10));
        root.addView(sub);

        Button settingsButton = button("⚙ API ANAHTARI AYARLARI");
        settingsButton.setOnClickListener(v -> toggleSettings());
        root.addView(settingsButton);

        settingsBox = new LinearLayout(this);
        settingsBox.setOrientation(LinearLayout.VERTICAL);
        settingsBox.setPadding(dp(8), dp(6), dp(8), dp(8));

        keyStatus = tv("", 13, false);
        settingsBox.addView(keyStatus);

        keyInput = new EditText(this);
        keyInput.setHint("Foursquare Service API Key");
        keyInput.setSingleLine(true);
        keyInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        settingsBox.addView(keyInput);

        LinearLayout keyButtons = row();
        Button saveKey = button("KAYDET");
        saveKey.setOnClickListener(v -> saveKey());
        Button deleteKey = button("SİL");
        deleteKey.setOnClickListener(v -> deleteKey());
        keyButtons.addView(saveKey);
        keyButtons.addView(deleteKey);
        settingsBox.addView(keyButtons);

        TextView keyNote = tv(
                "Anahtar kaynak koda veya GitHub'a yazılmaz; yalnızca bu telefondaki uygulama ayarında saklanır.",
                12, false);
        settingsBox.addView(keyNote);

        root.addView(settingsBox);

        regionInput = new EditText(this);
        regionInput.setHint("Bölge: örn. Bodrum, Antalya, Bursa");
        regionInput.setSingleLine(true);
        regionInput.setTextSize(18);
        regionInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        root.addView(regionInput);

        status = tv("Bir bölge yaz, sonra aşağıdan ne aradığını seç.", 14, false);
        status.setPadding(0, dp(6), 0, dp(4));
        root.addView(status);

        progress = new ProgressBar(this);
        progress.setVisibility(View.GONE);
        root.addView(progress);

        HorizontalScrollView groupScroll = new HorizontalScrollView(this);
        groupScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout groups = row();

        addGroupButton(groups, "🍽 LEZZET", "food");
        addGroupButton(groups, "🌊 DENİZ", "sea");
        addGroupButton(groups, "🏛 KEŞFET", "discover");
        addGroupButton(groups, "🛏 KONAK", "stay");

        groupScroll.addView(groups);
        root.addView(groupScroll);

        ScrollView scroll = new ScrollView(this);
        LinearLayout scrollContent = new LinearLayout(this);
        scrollContent.setOrientation(LinearLayout.VERTICAL);

        optionBox = new LinearLayout(this);
        optionBox.setOrientation(LinearLayout.VERTICAL);
        optionBox.setPadding(0, dp(6), 0, dp(4));
        scrollContent.addView(optionBox);

        resultBox = new LinearLayout(this);
        resultBox.setOrientation(LinearLayout.VERTICAL);
        resultBox.setPadding(0, dp(6), 0, dp(24));
        scrollContent.addView(resultBox);

        scroll.addView(scrollContent);
        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView attribution = tv("Mekân verileri: Foursquare Places", 11, false);
        attribution.setGravity(Gravity.CENTER);
        root.addView(attribution);

        setContentView(root);

        updateKeyUi();
        settingsBox.setVisibility(hasKey() ? View.GONE : View.VISIBLE);
        showGroup("food");
    }

    private void addGroupButton(LinearLayout parent, String label, String group) {
        Button b = button(label);
        b.setOnClickListener(v -> showGroup(group));
        parent.addView(b);
    }

    private void showGroup(String group) {
        currentGroup = group;
        optionBox.removeAllViews();
        resultBox.removeAllViews();

        String title;
        String desc;

        if ("food".equals(group)) {
            title = "🍽 LEZZET";
            desc = "Varsayılan: zincirleri dışarıda bırakır, ucuz–orta fiyatı hedefler ve puanı yüksek olanları öne çıkarır.";
        } else if ("sea".equals(group)) {
            title = "🌊 DENİZ";
            desc = "Plaj ve koyları puana göre getirir. Kum/sığ bilgisinin Foursquare kaydına bağlı olduğunu unutma.";
        } else if ("discover".equals(group)) {
            title = "🏛 KEŞFET & GİZEM";
            desc = "Antik kent, kale, mağara, müze ve tarihî yerleri getirir.";
        } else {
            title = "🛏 KONAK";
            desc = "Pansiyon, apart, otel ve kamp seçeneklerini getirir; uygun fiyat filtresi varsayılandır.";
        }

        optionBox.addView(tv(title, 20, true));
        optionBox.addView(tv(desc, 13, false));

        for (SearchProfiles.Profile p : SearchProfiles.forGroup(group)) {
            Button b = button(p.label);
            b.setAllCaps(false);
            b.setOnClickListener(v -> startSearch(p, true));
            optionBox.addView(b);
        }
    }

    private void startSearch(SearchProfiles.Profile profile, boolean strict) {
        String region = regionInput.getText().toString().trim();

        if (region.isEmpty()) {
            Toast.makeText(this, "Önce bölgeyi yaz hocam.", Toast.LENGTH_SHORT).show();
            return;
        }

        String apiKey = getSavedKey();
        if (apiKey.isEmpty()) {
            settingsBox.setVisibility(View.VISIBLE);
            Toast.makeText(this, "Önce Foursquare anahtarını kaydet.", Toast.LENGTH_LONG).show();
            return;
        }

        lastProfile = profile;
        lastStrict = strict;
        progress.setVisibility(View.VISIBLE);
        status.setText(region + " • " + profile.label + " aranıyor…");
        resultBox.removeAllViews();

        new Thread(() -> {
            try {
                FoursquareClient.SearchResult r =
                        FoursquareClient.search(apiKey, region, profile, strict);

                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    renderResults(region, profile, r);
                });

            } catch (Exception e) {
                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    status.setText("Arama başarısız.");
                    renderError(e);
                });
            }
        }).start();
    }

    private void renderResults(
            String region,
            SearchProfiles.Profile profile,
            FoursquareClient.SearchResult result) {

        resultBox.removeAllViews();

        if (result.places.isEmpty()) {
            status.setText("Sonuç bulunamadı.");

            resultBox.addView(tv(
                    result.strictFilters
                            ? "Ucuz + yerel filtresiyle sonuç çıkmadı. İstersen filtreyi gevşet."
                            : "Bu arama için Foursquare sonuç döndürmedi.",
                    15, false));

            if (result.strictFilters && profile.cheapLocal) {
                Button relaxed = button("DAHA GENİŞ ARA");
                relaxed.setOnClickListener(v -> startSearch(profile, false));
                resultBox.addView(relaxed);
            }
            return;
        }

        status.setText(region + " • " + profile.label + " • " + result.places.size() + " sonuç");

        if (!result.premiumFieldsAvailable) {
            resultBox.addView(tv(
                    "ÜCRETSİZ MOD: Sonuçlar Foursquare'ın puan sırasına göre geliyor; ücretli sayısal puan/fiyat alanlarını istemiyoruz.",
                    13, false));
        }

        int rank = 1;
        for (FoursquareClient.Place p : result.places) {
            addPlaceCard(rank++, p);
        }

        if (result.strictFilters && profile.cheapLocal) {
            Button relaxed = button("DAHA GENİŞ SONUÇLAR");
            relaxed.setOnClickListener(v -> startSearch(profile, false));
            resultBox.addView(relaxed);
        }
    }

    private void addPlaceCard(int rank, FoursquareClient.Place p) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(10), dp(12), dp(10));

        String crown = rank == 1 ? "🏆 EN ÜST SIRADA • " : "";
        card.addView(tv(crown + rank + ". " + p.name, 18, true));

        StringBuilder meta = new StringBuilder();

        if (p.rating >= 0) {
            meta.append(String.format(Locale.US, "⭐ %.1f/10", p.rating));
            if (p.totalRatings >= 0) meta.append(" (").append(p.totalRatings).append(" puan)");
        }

        if (p.price > 0) {
            if (meta.length() > 0) meta.append("  •  ");
            meta.append(priceText(p.price));
        }

        if (p.distance >= 0) {
            if (meta.length() > 0) meta.append("  •  ");
            if (p.distance < 1000) meta.append(p.distance).append(" m");
            else meta.append(String.format(Locale.US, "%.1f km", p.distance / 1000.0));
        }

        if (meta.length() > 0) card.addView(tv(meta.toString(), 14, false));
        if (!p.categories.isEmpty()) card.addView(tv(p.categories, 13, false));
        if (!p.address.isEmpty()) card.addView(tv("📍 " + p.address, 14, false));

        if (p.heritageNote != null && !p.heritageNote.isEmpty()) {
            card.addView(tv("🏺 " + p.heritageNote, 14, true));
        }

        LinearLayout actions = row();

        Button route = button("YOL TARİFİ");
        route.setOnClickListener(v -> openDirections(p));
        actions.addView(route);

        if (p.tel != null && !p.tel.isEmpty()) {
            Button phone = button("ARA");
            phone.setOnClickListener(v -> dial(p.tel));
            actions.addView(phone);
        }

        card.addView(actions);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(5), 0, dp(7));
        resultBox.addView(card, lp);
    }

    private void renderError(Exception e) {
        resultBox.removeAllViews();

        String message = e.getMessage() == null ? "Bilinmeyen hata." : e.getMessage();
        resultBox.addView(tv(message, 15, false));

        if (e instanceof FoursquareClient.ApiException) {
            int code = ((FoursquareClient.ApiException) e).httpCode;
            if (code == 401) {
                Button settings = button("API ANAHTARINI DÜZELT");
                settings.setOnClickListener(v -> settingsBox.setVisibility(View.VISIBLE));
                resultBox.addView(settings);
            }
        }

        if (lastProfile != null) {
            Button retry = button("TEKRAR DENE");
            retry.setOnClickListener(v -> startSearch(lastProfile, lastStrict));
            resultBox.addView(retry);
        }
    }

    private void openDirections(FoursquareClient.Place p) {
        try {
            String query;
            String uriText;

            if (!Double.isNaN(p.latitude) && !Double.isNaN(p.longitude)) {
                query = p.latitude + "," + p.longitude + "(" + p.name + ")";
                uriText = "geo:" + p.latitude + "," + p.longitude + "?q=" + Uri.encode(query);
            } else if (!p.address.isEmpty()) {
                uriText = "geo:0,0?q=" + Uri.encode(p.address + " " + p.name);
            } else {
                Toast.makeText(this, "Bu yerde yol tarifi için konum bilgisi yok.", Toast.LENGTH_SHORT).show();
                return;
            }

            Intent map = new Intent(Intent.ACTION_VIEW, Uri.parse(uriText));
            startActivity(Intent.createChooser(map, "Yol tarifi uygulamasını seç"));

        } catch (Exception ex) {
            Toast.makeText(this, "Navigasyon uygulaması açılamadı.", Toast.LENGTH_SHORT).show();
        }
    }

    private void dial(String tel) {
        try {
            startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(tel))));
        } catch (Exception ex) {
            Toast.makeText(this, "Telefon uygulaması açılamadı.", Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleSettings() {
        settingsBox.setVisibility(settingsBox.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
    }

    private void saveKey() {
        String key = keyInput.getText().toString().trim();
        if (key.length() < 20) {
            Toast.makeText(this, "Anahtar çok kısa görünüyor.", Toast.LENGTH_SHORT).show();
            return;
        }

        getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_FSQ, key)
                .apply();

        keyInput.setText("");
        updateKeyUi();
        settingsBox.setVisibility(View.GONE);
        Toast.makeText(this, "Foursquare anahtarı kaydedildi.", Toast.LENGTH_SHORT).show();
    }

    private void deleteKey() {
        getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .remove(KEY_FSQ)
                .apply();

        keyInput.setText("");
        updateKeyUi();
        Toast.makeText(this, "API anahtarı silindi.", Toast.LENGTH_SHORT).show();
    }

    private void updateKeyUi() {
        keyStatus.setText(hasKey()
                ? "✅ Foursquare anahtarı kayıtlı."
                : "⚠️ Foursquare anahtarı henüz kayıtlı değil.");
    }

    private boolean hasKey() {
        return !getSavedKey().isEmpty();
    }

    private String getSavedKey() {
        SharedPreferences p = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return p.getString(KEY_FSQ, "");
    }

    private String priceText(int price) {
        switch (price) {
            case 1: return "₺ Ucuz";
            case 2: return "₺₺ Orta";
            case 3: return "₺₺₺ Pahalı";
            case 4: return "₺₺₺₺ Çok pahalı";
            default: return "";
        }
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        return r;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        return b;
    }

    private TextView tv(String text, float size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setPadding(0, dp(3), 0, dp(3));
        return t;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
