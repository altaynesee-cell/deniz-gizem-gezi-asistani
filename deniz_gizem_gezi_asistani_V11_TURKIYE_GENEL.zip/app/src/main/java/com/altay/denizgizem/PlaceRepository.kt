package com.altay.denizgizem

data class SearchBundle(
    val regionKey: String,
    val categoryKey: String,
    val items: List<PlaceItem>,
    val offlineCount: Int,
    val liveCount: Int,
    val liveOk: Boolean,
    val status: String
)

object PlaceRepository {
    fun offline(region: String, category: CategorySpec): SearchBundle {
        val local = OfflineCatalog.find(region, category.key)
        return SearchBundle(
            regionKey=TextNorm.norm(region), categoryKey=category.key, items=local,
            offlineCount=local.size, liveCount=0, liveOk=false,
            status=if(local.isNotEmpty()) "${local.size} doğrulanmış yerel sonuç hazır; Türkiye geneli canlı arama devam ediyor"
            else "Türkiye geneli canlı arama hazırlanıyor"
        )
    }

    fun enrich(region: String, category: CategorySpec): SearchBundle {
        val local=OfflineCatalog.find(region,category.key)
        return try {
            val bounds=LiveOsmClient.resolveRegion(region)
            val live=LiveOsmClient.search(bounds,region,category)
            val merged=SafetyRules.mergeAndRank(local,live)
            SearchBundle(
                regionKey=TextNorm.norm(region), categoryKey=category.key, items=merged,
                offlineCount=local.size, liveCount=live.size, liveOk=true,
                status=when {
                    merged.isEmpty() -> "${bounds.canonical}: güvenli kategori eşleşmesi bulunamadı"
                    local.isNotEmpty() -> "${bounds.canonical}: ${local.size} doğrulanmış + ${live.size} canlı sonuç"
                    else -> "${bounds.canonical}: ${live.size} canlı sonuç bulundu"
                }
            )
        } catch(t:Throwable) {
            SearchBundle(
                regionKey=TextNorm.norm(region), categoryKey=category.key, items=local,
                offlineCount=local.size, liveCount=0, liveOk=false,
                status=if(local.isNotEmpty()) "Canlı servis geçici olarak cevap vermedi; doğrulanmış sonuçlarla devam ediliyor"
                else "Canlı servis geçici olarak cevap vermedi; tekrar dene"
            )
        }
    }
}
