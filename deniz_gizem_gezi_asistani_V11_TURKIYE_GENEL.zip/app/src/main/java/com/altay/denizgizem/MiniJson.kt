package com.altay.denizgizem

class MiniJson private constructor(private val s: String) {
    private var p = 0

    companion object {
        fun parse(s: String): Any? = MiniJson(s).value()
    }

    private fun value(): Any? {
        ws()
        if (p >= s.length) error("JSON boş")
        return when (s[p]) {
            '{' -> obj()
            '[' -> arr()
            '"' -> str()
            't' -> { word("true"); true }
            'f' -> { word("false"); false }
            'n' -> { word("null"); null }
            else -> number()
        }
    }

    private fun obj(): Map<String, Any?> {
        val m = linkedMapOf<String, Any?>()
        p++; ws()
        if (s[p] == '}') { p++; return m }
        while (true) {
            val k = str(); ws(); expect(':')
            m[k] = value(); ws()
            val c = s[p++]
            if (c == '}') return m
            require(c == ',')
            ws()
        }
    }

    private fun arr(): List<Any?> {
        val a = mutableListOf<Any?>()
        p++; ws()
        if (s[p] == ']') { p++; return a }
        while (true) {
            a += value(); ws()
            val c = s[p++]
            if (c == ']') return a
            require(c == ',')
            ws()
        }
    }

    private fun str(): String {
        ws(); expect('"')
        val b = StringBuilder()
        while (p < s.length) {
            val c = s[p++]
            if (c == '"') return b.toString()
            if (c == '\\') {
                val e = s[p++]
                when (e) {
                    '"' -> b.append('"')
                    '\\' -> b.append('\\')
                    '/' -> b.append('/')
                    'b' -> b.append('\b')
                    'f' -> b.append('\u000C')
                    'n' -> b.append('\n')
                    'r' -> b.append('\r')
                    't' -> b.append('\t')
                    'u' -> {
                        b.append(s.substring(p, p + 4).toInt(16).toChar())
                        p += 4
                    }
                    else -> error("JSON escape")
                }
            } else b.append(c)
        }
        error("JSON string")
    }

    private fun number(): Number {
        val start = p
        while (p < s.length && s[p] in "-+.eE0123456789") p++
        val x = s.substring(start, p)
        return if (x.contains('.') || x.contains('e', true)) x.toDouble() else x.toLong()
    }

    private fun ws() { while (p < s.length && s[p].isWhitespace()) p++ }
    private fun expect(c: Char) { require(p < s.length && s[p] == c); p++ }
    private fun word(w: String) { require(s.startsWith(w, p)); p += w.length }
}
