package com.altay.denizgizem

import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import kotlin.math.*

object LiveOsmClient {
    private const val USER_AGENT = "DenizGizemGeziAsistani/11.0 (personal travel search; Türkiye)"
    private const val NOMINATIM = "https://nominatim.openstreetmap.org/search"
    private val overpass = listOf(
        "https://overpass-api.de/api/interpreter",
        "https://overpass.private.coffee/api/interpreter",
        "https://overpass.kumi.systems/api/interpreter"
    )
    private val geocodeCache = mutableMapOf<String, RegionBounds>()
    private val poiCache = mutableMapOf<String, List<PlaceItem>>()
    private var lastNominatim = 0L

    @Synchronized
    fun resolveRegion(region: String): RegionBounds {
        RegionCatalog.known(region)?.let { return it }
        val key = TextNorm.norm(region)
        geocodeCache[key]?.let { return it }

        val q = if (key.contains("turkiye") || key.contains("turkey")) region else "$region, Türkiye"
        val body = nominatimGet(
            "$NOMINATIM?format=jsonv2&limit=1&countrycodes=tr&accept-language=tr&addressdetails=1&q=${enc(q)}"
        )
        val root = MiniJson.parse(body) as? List<*> ?: error("Bölge cevabı okunamadı")
        val first = root.firstOrNull() as? Map<*, *> ?: error("Türkiye içinde bölge bulunamadı")
        val bb = first["boundingbox"] as? List<*> ?: error("Bölge sınırı yok")
        val g = RegionBounds(
            canonical = first["display_name"]?.toString() ?: region,
            south = bb[0].toString().toDouble(),
            north = bb[1].toString().toDouble(),
            west = bb[2].toString().toDouble(),
            east = bb[3].toString().toDouble(),
            centerLat = first["lat"].toString().toDouble(),
            centerLon = first["lon"].toString().toDouble()
        )
        geocodeCache[key] = g
        return g
    }

    fun search(bounds: RegionBounds, regionText: String, category: CategorySpec): List<PlaceItem> {
        val all = mutableListOf<PlaceItem>()
        var overpassFailed = false
        try {
            val body = overpassPost(buildQuery(bounds, category))
            all += parseOverpass(body, bounds, category)
        } catch (_: Throwable) {
            overpassFailed = true
        }

        // Türkiye'nin herhangi bir il/ilçesinde sonuç azsa, kullanıcı tetiklemeli ve
        // hız sınırlı Nominatim aramasıyla kategoriye özel ikinci kaynak denenir.
        if (all.size < 5) {
            all += searchTargetedNominatim(bounds, regionText, category)
        }

        val out = SafetyRules.dedupe(all).sortedByDescending { it.smartScore() }.take(30)
        if (out.isEmpty() && overpassFailed) error("Canlı harita servisleri cevap vermedi")
        return out
    }

    fun queryTerms(c: CategorySpec): List<String> = when (c.key) {
        "ciger" -> listOf("ciğerci", "arnavut ciğeri")
        "kofte" -> listOf("köfteci", "meşhur köfteci")
        "kebap" -> listOf("kebapçı", "kebap")
        "sulu" -> listOf("ev yemekleri", "sulu yemek lokantası")
        "tavuk" -> listOf("tavukçu", "tavuk restoran")
        "esnaf" -> listOf("esnaf lokantası", "lokanta")
        "balik" -> listOf("balık restoranı", "balıkçı")
        "kahvalti" -> listOf("kahvaltı", "serpme kahvaltı")
        "plaj" -> listOf("plaj", "halk plajı")
        "kum" -> listOf("sığ kumlu plaj", "kumsal")
        "koy" -> listOf("koy", "koyu")
        "antik" -> listOf("antik kent", "ören yeri")
        "kale" -> listOf("kale", "hisar")
        "magara" -> listOf("mağara")
        "muze" -> listOf("müze")
        "tarihi" -> listOf("tarihi yer", "tarihi yapı")
        "gizem" -> listOf("efsane tarihi yer", "gizemli tarihi yer")
        "pansiyon" -> listOf("pansiyon")
        "apart" -> listOf("apart otel")
        "otel" -> listOf("otel")
        "kamp" -> listOf("kamp alanı")
        else -> listOf(c.title)
    }

    fun buildQuery(b: RegionBounds, c: CategorySpec): String {
        val box = "${b.south},${b.west},${b.north},${b.east}"
        fun nwr(filters: String) = "nwr$filters($box);"
        val q = StringBuilder("[out:json][timeout:22];(")
        when (c.key) {
            "plaj" -> {
                q.append(nwr("[\"natural\"=\"beach\"][\"name\"]"))
                q.append(nwr("[\"leisure\"~\"^(beach|beach_resort)$\"][\"name\"]"))
            }
            "kum" -> {
                q.append(nwr("[\"natural\"=\"beach\"][\"surface\"~\"sand|fine_sand|sandy\",i][\"name\"]"))
                q.append(nwr("[\"natural\"=\"beach\"][\"name\"~\"kum|kumsal|sand\",i]"))
                q.append(nwr("[\"natural\"=\"beach\"][\"description\"~\"sığ|sig|shallow|kum|sand\",i][\"name\"]"))
            }
            "koy" -> q.append(nwr("[\"natural\"=\"bay\"][\"name\"]"))
            "magara" -> {
                q.append(nwr("[\"natural\"=\"cave_entrance\"][\"name\"]"))
                q.append(nwr("[\"natural\"=\"cave\"][\"name\"]"))
            }
            "muze" -> q.append(nwr("[\"tourism\"=\"museum\"][\"name\"]"))
            "kale" -> {
                q.append(nwr("[\"historic\"~\"^(castle|fort|city_gate|citywalls)$\"][\"name\"]"))
                q.append(nwr("[\"name\"~\"kale|hisar|sur|fort\",i][\"historic\"][\"name\"]"))
            }
            "antik" -> {
                q.append(nwr("[\"historic\"=\"archaeological_site\"][\"name\"]"))
                q.append(nwr("[\"historic\"=\"ruins\"][\"name\"]"))
                q.append(nwr("[\"tourism\"=\"attraction\"][\"name\"~\"antik|ören|oren\",i]"))
            }
            "tarihi" -> q.append(nwr("[\"historic\"][\"name\"]"))
            "gizem" -> {
                q.append(nwr("[\"historic\"][\"wikipedia\"][\"name\"]"))
                q.append(nwr("[\"historic\"][\"wikidata\"][\"name\"]"))
                q.append(nwr("[\"natural\"=\"cave_entrance\"][\"wikipedia\"][\"name\"]"))
                q.append(nwr("[\"name\"~\"efsane|gizem|peri|şeytan|seytan|kız|kiz|mitoloji\",i][\"name\"]"))
            }
            "otel" -> q.append(nwr("[\"tourism\"~\"^(hotel|motel|resort)$\"][\"name\"]"))
            "pansiyon" -> q.append(nwr("[\"tourism\"~\"^(guest_house|hostel|bed_and_breakfast)$\"][\"name\"]"))
            "apart" -> q.append(nwr("[\"tourism\"=\"apartment\"][\"name\"]"))
            "kamp" -> q.append(nwr("[\"tourism\"~\"^(camp_site|caravan_site)$\"][\"name\"]"))
            else -> {
                val food = "[\"amenity\"~\"^(restaurant|fast_food|cafe)$\"]"
                when (c.key) {
                    "ciger" -> q.append(nwr(food + "[\"name\"~\"ciğer|ciger|arnavut|liver\",i]"))
                    "kofte" -> {
                        q.append(nwr(food + "[\"name\"~\"köfte|kofte|meatball\",i]"))
                        q.append(nwr(food + "[\"cuisine\"~\"meatball|köfte|kofte\",i][\"name\"]"))
                    }
                    "kebap" -> {
                        q.append(nwr(food + "[\"name\"~\"kebap|kebab|ocakbaşı|ocakbasi\",i]"))
                        q.append(nwr(food + "[\"cuisine\"~\"kebab\",i][\"name\"]"))
                    }
                    "sulu", "esnaf" -> q.append(nwr(food + "[\"name\"~\"lokanta|sofra|ev yemek|esnaf|tabldot\",i]"))
                    "tavuk" -> {
                        q.append(nwr(food + "[\"name\"~\"tavuk|piliç|pilic|chicken\",i]"))
                        q.append(nwr(food + "[\"cuisine\"~\"chicken\",i][\"name\"]"))
                    }
                    "balik" -> {
                        q.append(nwr(food + "[\"name\"~\"balık|balik|fish|seafood\",i]"))
                        q.append(nwr(food + "[\"cuisine\"~\"fish|seafood\",i][\"name\"]"))
                    }
                    "kahvalti" -> {
                        q.append(nwr(food + "[\"name\"~\"kahvaltı|kahvalti|breakfast|serpme\",i]"))
                        q.append(nwr(food + "[\"breakfast\"=\"yes\"][\"name\"]"))
                    }
                }
            }
        }
        return q.append(");out center tags 80;").toString()
    }

    @Suppress("UNCHECKED_CAST")
    fun parseOverpass(body: String, bounds: RegionBounds, category: CategorySpec): List<PlaceItem> {
        val root = MiniJson.parse(body) as? Map<String, Any?> ?: return emptyList()
        val elements = root["elements"] as? List<Any?> ?: return emptyList()
        val out = mutableListOf<PlaceItem>()
        for (e0 in elements) {
            val e = e0 as? Map<String, Any?> ?: continue
            val tags = e["tags"] as? Map<String, Any?> ?: continue
            val name = tags["name"]?.toString()?.trim().orEmpty()
            if (name.isBlank()) continue
            var lat = (e["lat"] as? Number)?.toDouble()
            var lon = (e["lon"] as? Number)?.toDouble()
            if (lat == null || lon == null) {
                val center = e["center"] as? Map<String, Any?>
                lat = (center?.get("lat") as? Number)?.toDouble()
                lon = (center?.get("lon") as? Number)?.toDouble()
            }
            if (lat == null || lon == null || !bounds.contains(lat, lon)) continue

            val osmType = typeLabel(tags)
            val brand = tags["brand"]?.toString().orEmpty()
            val evidence = listOfNotNull(
                tags["cuisine"]?.toString(), tags["description"]?.toString(), tags["surface"]?.toString(),
                tags["wikipedia"]?.toString()?.let { "wikipedia $it" },
                tags["wikidata"]?.toString()?.let { "wikidata $it" }
            ).joinToString(" ")
            if (!SafetyRules.acceptLive(name, category, osmType, brand, evidence)) continue

            val hasWiki = tags["wikipedia"] != null || tags["wikidata"] != null
            val hasHistory = !tags["start_date"]?.toString().isNullOrBlank()
            val exactFood = category.group == Group.FOOD && SafetyRules.foodKeywords(category.key).any {
                TextNorm.norm("$name $evidence").contains(it)
            }
            val fame = when {
                hasWiki -> 9
                hasHistory -> 8
                exactFood -> 7
                else -> 4
            }
            val area = listOfNotNull(
                tags["addr:district"]?.toString(), tags["addr:city"]?.toString(), tags["addr:province"]?.toString()
            ).filter { it.isNotBlank() }.distinct().joinToString(", ").ifBlank { bounds.canonical }

            out += PlaceItem(
                name=name, categoryKey=category.key, group=category.group, area=area,
                address=listOfNotNull(tags["addr:street"]?.toString(), tags["addr:neighbourhood"]?.toString(), tags["addr:suburb"]?.toString()).filter { it.isNotBlank() }.joinToString(", "),
                why=when {
                    category.key == "gizem" && hasWiki -> "Wikipedia/Wikidata bağlantısı olan tarihî veya doğal nokta; kısa hikâye için kaynak bağlantısı mevcut."
                    category.group == Group.FOOD -> "Canlı açık veride seçtiğin yemek türüyle eşleşen yerel işletme."
                    else -> "Canlı açık harita verisinde seçtiğin kategoriyle eşleşti."
                },
                tags=listOfNotNull("Canlı", osmType, if (hasWiki) "Kaynaklı" else null),
                established=tags["start_date"]?.toString().orEmpty(),
                sourceLabel=if (hasWiki) "OpenStreetMap + Wikipedia/Wikidata etiketi" else "OpenStreetMap",
                routeQuery="$name $area", verified=false, fameScore=fame,
                localScore=if (brand.isBlank()) 8 else 3, typeScore=10,
                distanceKm=haversine(bounds.centerLat,bounds.centerLon,lat,lon), lat=lat, lon=lon, live=true
            )
        }
        return out.sortedByDescending { it.smartScore() }.take(30)
    }

    private fun searchTargetedNominatim(bounds: RegionBounds, regionText: String, category: CategorySpec): List<PlaceItem> {
        val cacheKey = TextNorm.norm(regionText) + "|" + category.key
        poiCache[cacheKey]?.let { return it }
        val out = mutableListOf<PlaceItem>()
        for (term in queryTerms(category).take(2)) {
            if (out.size >= 8) break
            try {
                val q = "$term $regionText Türkiye"
                val view = "${bounds.west},${bounds.north},${bounds.east},${bounds.south}"
                val url = "$NOMINATIM?format=jsonv2&limit=12&countrycodes=tr&accept-language=tr&addressdetails=1&namedetails=1&extratags=1&bounded=1&viewbox=${enc(view)}&q=${enc(q)}"
                val body = nominatimGet(url)
                out += parseNominatim(body,bounds,category,term)
            } catch (_: Throwable) { }
        }
        val result = SafetyRules.dedupe(out).sortedByDescending { it.smartScore() }.take(15)
        poiCache[cacheKey] = result
        return result
    }

    @Suppress("UNCHECKED_CAST")
    private fun parseNominatim(body: String, bounds: RegionBounds, category: CategorySpec, term: String): List<PlaceItem> {
        val root = MiniJson.parse(body) as? List<Any?> ?: return emptyList()
        val out = mutableListOf<PlaceItem>()
        for (x0 in root) {
            val x = x0 as? Map<String, Any?> ?: continue
            val lat = x["lat"]?.toString()?.toDoubleOrNull() ?: continue
            val lon = x["lon"]?.toString()?.toDoubleOrNull() ?: continue
            if (!bounds.contains(lat,lon)) continue
            val named = x["namedetails"] as? Map<String, Any?>
            val name = named?.get("name")?.toString()?.takeIf { it.isNotBlank() }
                ?: x["name"]?.toString()?.takeIf { it.isNotBlank() }
                ?: x["display_name"]?.toString()?.substringBefore(',')?.trim().orEmpty()
            if (name.isBlank()) continue
            val clazz = x["category"]?.toString().orEmpty()
            val type = x["type"]?.toString().orEmpty()
            val extra = x["extratags"] as? Map<String, Any?>
            val evidence = buildString {
                append(term).append(' ')
                extra?.forEach { (k,v) -> append(k).append(' ').append(v).append(' ') }
            }
            val mapped = nominatimType(clazz,type,name)
            if (!SafetyRules.acceptLive(name,category,mapped,extra?.get("brand")?.toString().orEmpty(),evidence,targetedSearch=true)) continue
            val importance = (x["importance"] as? Number)?.toDouble() ?: x["importance"]?.toString()?.toDoubleOrNull() ?: 0.0
            val fame = when {
                importance >= 0.5 -> 9
                importance >= 0.2 -> 8
                importance >= 0.05 -> 7
                else -> 6
            }
            out += PlaceItem(
                name=name, categoryKey=category.key, group=category.group, area=bounds.canonical,
                address=x["display_name"]?.toString().orEmpty(),
                why=if (category.group == Group.FOOD)
                    "Seçtiğin yemek türü için ${regionLabel(bounds.canonical)} içinde hedefli yer aramasında öne çıktı."
                else "${regionLabel(bounds.canonical)} sınırları içinde hedefli kategori aramasında bulundu.",
                tags=listOf("Canlı", "Hedefli arama", term), sourceLabel="OpenStreetMap Nominatim",
                routeQuery="$name ${regionLabel(bounds.canonical)}", verified=false, fameScore=fame,
                localScore=8, typeScore=9, distanceKm=haversine(bounds.centerLat,bounds.centerLon,lat,lon),
                lat=lat,lon=lon,live=true
            )
        }
        return out
    }

    private fun nominatimType(clazz: String, type: String, name: String): String {
        val s = TextNorm.norm("$clazz $type $name")
        return when {
            listOf("restaurant","fast food","cafe").any { s.contains(it) } -> "Restaurant"
            s.contains("beach") -> "Beach / Plaj"
            s.contains("bay") -> "Bay / Koy"
            s.contains("cave") -> "Cave / Mağara"
            s.contains("museum") -> "Museum / Müze"
            s.contains("castle") || s.contains("fort") || s.contains("city gate") -> "Historic / Castle"
            s.contains("archaeological") || s.contains("ruins") -> "Historic / Archaeological"
            s.contains("historic") || s.contains("memorial") || s.contains("monument") -> "Historic"
            s.contains("hotel") || s.contains("motel") || s.contains("resort") -> "Hotel"
            s.contains("guest house") || s.contains("hostel") -> "Guest House"
            s.contains("apartment") -> "Apartment"
            s.contains("camp") -> "Camp"
            else -> "$clazz / $type"
        }
    }

    private fun typeLabel(t: Map<String, Any?>): String = when {
        t["natural"]?.toString() == "beach" -> "Beach / Plaj"
        t["natural"]?.toString() == "bay" -> "Bay / Koy"
        t["natural"]?.toString() == "cave_entrance" || t["natural"]?.toString() == "cave" -> "Cave / Mağara"
        t["tourism"]?.toString() == "museum" -> "Museum / Müze"
        !t["historic"]?.toString().isNullOrBlank() -> "Historic / ${t["historic"]}"
        !t["tourism"]?.toString().isNullOrBlank() -> "Konaklama / ${t["tourism"]}"
        !t["amenity"]?.toString().isNullOrBlank() -> when (t["amenity"]!!.toString()) {
            "restaurant" -> "Restaurant"; "fast_food" -> "Fast Food"; "cafe" -> "Cafe"; else -> t["amenity"]!!.toString()
        }
        else -> "OpenStreetMap"
    }

    private fun overpassPost(query: String): String {
        var last: Throwable? = null
        for (endpoint in overpass) {
            try {
                val data = ("data=" + enc(query)).toByteArray(StandardCharsets.UTF_8)
                val c = URL(endpoint).openConnection() as HttpURLConnection
                c.requestMethod="POST"; c.doOutput=true; c.connectTimeout=10000; c.readTimeout=25000
                c.setRequestProperty("User-Agent",USER_AGENT)
                c.setRequestProperty("Content-Type","application/x-www-form-urlencoded; charset=UTF-8")
                c.outputStream.use { it.write(data) }
                val code=c.responseCode
                val body=read(if(code in 200..299)c.inputStream else c.errorStream)
                c.disconnect()
                if(code !in 200..299) error("Overpass HTTP $code")
                return body
            } catch(t:Throwable){ last=t }
        }
        throw last ?: IllegalStateException("Overpass erişilemiyor")
    }

    @Synchronized
    private fun nominatimGet(url: String): String {
        val wait = 1100 - (System.currentTimeMillis() - lastNominatim)
        if (wait > 0) Thread.sleep(wait)
        val c=URL(url).openConnection() as HttpURLConnection
        c.requestMethod="GET"; c.connectTimeout=9000; c.readTimeout=12000
        c.setRequestProperty("User-Agent",USER_AGENT); c.setRequestProperty("Accept","application/json")
        val code=c.responseCode
        val body=read(if(code in 200..299)c.inputStream else c.errorStream)
        c.disconnect(); lastNominatim=System.currentTimeMillis()
        if(code !in 200..299) error("Nominatim HTTP $code")
        return body
    }

    private fun regionLabel(canonical:String)=canonical.split(',').take(3).joinToString(",").trim()
    private fun read(input:InputStream?):String = if(input==null) "" else BufferedReader(InputStreamReader(input,StandardCharsets.UTF_8)).use { r -> buildString { while(true){ val line=r.readLine()?:break; append(line) } } }
    private fun enc(s:String)=URLEncoder.encode(s,StandardCharsets.UTF_8)
    private fun haversine(a:Double,o:Double,b:Double,p:Double):Double { val r=6371.0; val dLat=Math.toRadians(b-a); val dLon=Math.toRadians(p-o); val q=sin(dLat/2).pow(2)+cos(Math.toRadians(a))*cos(Math.toRadians(b))*sin(dLon/2).pow(2); return r*2*atan2(sqrt(q),sqrt(1-q)) }
}
