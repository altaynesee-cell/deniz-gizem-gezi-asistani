package com.altay.denizgizem

import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import java.io.File
import kotlin.math.*

object OfflineDb {
    private const val ASSET = "turkey_v14.sqlite"
    private const val LOCAL = "turkey_v14.sqlite"

    @Synchronized
    private fun file(context: Context): File {
        val out=File(context.filesDir,LOCAL)
        if(!out.exists() || out.length()==0L) {
            context.assets.open(ASSET).use { input ->
                out.outputStream().use { output -> input.copyTo(output) }
            }
        }
        return out
    }

    private fun open(context:Context)=SQLiteDatabase.openDatabase(
        file(context).absolutePath,null,SQLiteDatabase.OPEN_READONLY
    )

    fun metadata(context:Context):String=open(context).use { db ->
        db.rawQuery("SELECT value FROM meta WHERE key='dataset_label' LIMIT 1",null).use { c ->
            if(c.moveToFirst()) c.getString(0) else "V15 Köklü + Temiz Türkiye"
        }
    }

    fun findRegion(context:Context, raw:String):RegionHit? {
        val q=TextNorm.norm(raw)
        if(q.isBlank()) return null
        open(context).use { db ->
            db.rawQuery("""
                SELECT r.name,r.kind,r.province,r.lat,r.lon
                FROM aliases a JOIN regions r ON r.name_norm=a.target_norm
                WHERE a.alias_norm=? LIMIT 1
            """.trimIndent(), arrayOf(q)).use { c ->
                if(c.moveToFirst()) return c.region()
            }
            db.rawQuery("""
                SELECT name,kind,province,lat,lon FROM regions
                WHERE name_norm=?
                ORDER BY CASE kind WHEN 'province' THEN 0 ELSE 1 END LIMIT 1
            """.trimIndent(), arrayOf(q)).use { c ->
                if(c.moveToFirst()) return c.region()
            }
        }
        return null
    }

    fun search(context:Context, rawRegion:String, categoryKey:String, limit:Int=40):Pair<RegionHit?,List<ResultItem>> {
        val region=findRegion(context,rawRegion) ?: return null to emptyList()
        return if(categoryKey=="gizem") region to searchLegends(context,region,limit)
        else region to searchPoi(context,region,categoryKey,limit)
    }

    private fun searchPoi(context:Context,r:RegionHit,key:String,limit:Int):List<ResultItem> =
        open(context).use { db ->
            val district = r.kind=="district"
            val food = key in setOf("ciger","kofte","kebap","sulu","tavuk","esnaf","balik","kahvalti")
            val order = if(food)
                "curated DESC, CASE WHEN start_year IS NULL THEN 1 ELSE 0 END ASC, start_year ASC, is_chain ASC, source_count DESC, quality_rank DESC, rank_score DESC, name COLLATE NOCASE"
            else
                "curated DESC, source_count DESC, quality_rank DESC, rank_score DESC, name COLLATE NOCASE"
            val scope = if(district) "district_norm=?" else "province_norm=?"
            val sql = """
                SELECT id,name,category_key,province,district,address,detail,source,source_url,
                       match_note,route_query,rank_score,source_count,curated,start_year,branch_count,is_chain,lat,lon
                FROM poi WHERE category_key=? AND $scope
                ORDER BY $order LIMIT ?
            """
            val target=TextNorm.norm(if(district) r.name else r.province.ifBlank{r.name})
            db.rawQuery(sql.trimIndent(),arrayOf(key,target,(limit*3).toString())).use { c ->
                dedupeResults(buildList { while(c.moveToNext()) add(c.poi(false)) },key,limit)
            }
        }

    private fun searchLegends(context:Context,r:RegionHit,limit:Int):List<ResultItem> =
        open(context).use { db ->
            val district=r.kind=="district"
            val sql=if(district) """
                SELECT id,title,province,district,summary,source_title,source_url,place_query,rank_score,curated
                FROM legends
                WHERE district_norm=? OR (district_norm='' AND province_norm=?)
                ORDER BY CASE WHEN district_norm=? THEN 0 ELSE 1 END, curated DESC, rank_score DESC, title
                LIMIT ?
            """ else """
                SELECT id,title,province,district,summary,source_title,source_url,place_query,rank_score,curated
                FROM legends WHERE province_norm=?
                ORDER BY curated DESC, rank_score DESC, title LIMIT ?
            """
            val prov=TextNorm.norm(r.province.ifBlank{r.name})
            val args=if(district) arrayOf(TextNorm.norm(r.name),prov,TextNorm.norm(r.name),limit.toString())
                     else arrayOf(prov,limit.toString())
            db.rawQuery(sql.trimIndent(),args).use { c ->
                buildList {
                    while(c.moveToNext()) {
                        add(ResultItem(
                            id=c.getLong(0),name=c.getString(1),categoryKey="gizem",
                            province=c.getString(2).orEmpty(),district=c.getString(3).orEmpty(),
                            address="",detail=c.getString(4).orEmpty(),source=c.getString(5).orEmpty(),
                            sourceUrl=c.getString(6).orEmpty(),matchNote="Kaynaklı efsane / menkıbe / rivayet",
                            routeQuery=c.getString(7).orEmpty(),rankScore=c.getDouble(8),
                            sourceCount=1,curated=c.getInt(9)==1,isLegend=true,
                            startYear=null,branchCount=1,isChain=false
                        ))
                    }
                }
            }
        }

    private fun Cursor.region()=RegionHit(getString(0),getString(1),getString(2).orEmpty(),getDouble(3),getDouble(4))
    private fun Cursor.poi(isLegend:Boolean)=ResultItem(
        id=getLong(0),name=getString(1),categoryKey=getString(2),
        province=getString(3).orEmpty(),district=getString(4).orEmpty(),
        address=getString(5).orEmpty(),detail=getString(6).orEmpty(),
        source=getString(7).orEmpty(),sourceUrl=getString(8).orEmpty(),
        matchNote=getString(9).orEmpty(),routeQuery=getString(10).orEmpty(),
        rankScore=getDouble(11),sourceCount=getInt(12),curated=getInt(13)==1,isLegend=isLegend,
        startYear=if(isNull(14)) null else getInt(14),branchCount=getInt(15),isChain=getInt(16)==1,
        lat=if(isNull(17)) null else getDouble(17),lon=if(isNull(18)) null else getDouble(18)
    )

    private fun uniqueTokens(s:String):String {
        val out=mutableListOf<String>()
        for(t in s.split(Regex("\\s+")).filter{it.isNotBlank()}) if(t !in out) out+=t
        return out.joinToString(" ")
    }

    private fun coreName(name:String,key:String,province:String="",district:String=""):String {
        var n=TextNorm.norm(name)
        val generic=when(key){
            "magara" -> listOf("magarasi","magara","cave entrance","cave","girisi","giris","entrance")
            "antik" -> listOf("antik kenti","antik kent","oren yeri","arkeolojik alani","arkeolojik alan","ruins")
            "kale" -> listOf("kalesi","kale","hisari","hisar","surlari","sur")
            "plaj" -> listOf("halk plaji","plaji","plaj","beach")
            "koy" -> listOf("koyu","koy","bay")
            else -> emptyList()
        }
        generic.sortedByDescending{it.length}.forEach {
            n=n.replace(Regex("(^|\\s)"+Regex.escape(it)+"(\\s|$)")," ")
        }
        n=uniqueTokens(n.replace(Regex("\\s+")," ").trim())
        if(key=="magara" && TextNorm.norm(province)=="mersin" && TextNorm.norm(district)=="tarsus" && n in setOf("taskaya","taskuyu")) n="taskuyu"
        return n
    }

    private fun editDistance(a0:String,b0:String):Int {
        val a=TextNorm.norm(a0); val b=TextNorm.norm(b0)
        if(a==b) return 0
        if(a.isEmpty()) return b.length
        if(b.isEmpty()) return a.length
        var prev=IntArray(b.length+1){it}
        for(i in 1..a.length){
            val cur=IntArray(b.length+1); cur[0]=i
            for(j in 1..b.length){
                val cost=if(a[i-1]==b[j-1]) 0 else 1
                cur[j]=minOf(cur[j-1]+1,prev[j]+1,prev[j-1]+cost)
            }
            prev=cur
        }
        return prev[b.length]
    }

    private fun similarCore(a:String,b:String,key:String):Boolean {
        if(a==b) return true
        if(a.length<5 || b.length<5) return false
        if(a.contains(b) || b.contains(a)) return true
        val d=editDistance(a,b)
        return if(key=="magara") d<=2 else d<=1
    }

    private fun havMeters(aLat:Double?,aLon:Double?,bLat:Double?,bLon:Double?):Double {
        if(aLat==null||aLon==null||bLat==null||bLon==null) return Double.MAX_VALUE
        val r=6371000.0
        val p1=Math.toRadians(aLat); val p2=Math.toRadians(bLat)
        val dp=Math.toRadians(bLat-aLat); val dl=Math.toRadians(bLon-aLon)
        val h=sin(dp/2).pow(2)+cos(p1)*cos(p2)*sin(dl/2).pow(2)
        return 2*r*asin(min(1.0,sqrt(h)))
    }

    private fun dedupeResults(input:List<ResultItem>,key:String,limit:Int):List<ResultItem>{
        val highRisk=key in setOf("magara","antik","kale","plaj","koy")
        if(!highRisk) return input.take(limit)
        val out=mutableListOf<ResultItem>()
        for(x in input){
            val scope=TextNorm.norm(x.district.ifBlank{x.province})
            val c=coreName(x.name,key,x.province,x.district).ifBlank{TextNorm.norm(x.name)}
            val dup=out.any { y ->
                val yScope=TextNorm.norm(y.district.ifBlank{y.province})
                if(scope!=yScope) false else {
                    val yc=coreName(y.name,key,y.province,y.district).ifBlank{TextNorm.norm(y.name)}
                    val same=similarCore(c,yc,key)
                    val dist=havMeters(x.lat,x.lon,y.lat,y.lon)
                    same && (c==yc || dist <= (if(key=="magara") 2500.0 else 900.0) || (key=="magara" && editDistance(c,yc)<=2))
                }
            }
            if(!dup){ out+=x; if(out.size>=limit) break }
        }
        return out
    }

}
