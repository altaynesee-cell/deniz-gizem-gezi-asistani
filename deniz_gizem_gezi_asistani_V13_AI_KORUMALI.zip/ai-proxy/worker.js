const OPENAI_URL = "https://api.openai.com/v1/responses";

export default {
  async fetch(request, env) {
    if (request.method !== "POST") {
      return json({ error: "POST required" }, 405);
    }
    if (!env.OPENAI_API_KEY) {
      return json({ error: "OPENAI_API_KEY missing" }, 500);
    }

    let body;
    try { body = await request.json(); }
    catch { return json({ error: "Invalid JSON" }, 400); }

    const region = clean(body.region, 100);
    const categoryKey = clean(body.categoryKey, 40);
    const categoryTitle = clean(body.categoryTitle, 80);
    const strictType = clean(body.strictType, 60);
    const mode = clean(body.mode, 20);
    const candidates = Array.isArray(body.candidates) ? body.candidates.slice(0, 12) : [];
    if (!region || !categoryKey) return json({ error: "region/category missing" }, 400);

    const rules = `
You are the verification engine of a Turkish travel app. Research the public web when useful.
The user searched region: ${region}
Category: ${categoryTitle} (${categoryKey}), strict type: ${strictType}
Mode: ${mode}

NON-NEGOTIABLE RULES:
1) Accuracy beats result count. Never invent a venue, historical site, legend, address, source, age, or popularity claim.
2) A result must genuinely belong to the requested il/ilçe or clearly be within that district's administrative area. Do not silently substitute a nearby city.
3) KALE/HİSAR: only a real castle, fortress, fortification, city wall, or historic city gate. A bakery/cafe/hotel/restaurant/market/business whose NAME contains Kale/Hisar is forbidden.
4) ANTİK KENT: only a genuine archaeological site, ancient settlement/city, ruins, or officially recognized ancient site. Never infer from a business name.
5) MAĞARA: only a real natural/historic cave or cave entrance; never a cafe/business named Mağara.
6) SIĞ + KUM: include only beaches for which both sandy shore/seabed and shallow/gradually deepening water are supported. If only one is supported, omit it.
7) FOOD: the place must actually be associated with the selected food. Prefer a locally established/well-known independent place when support exists; do not claim 'most famous' without support.
8) GİZEM/EFSANE: return real local legends, myths, folklore or historically documented mysterious traditions tied to the region. Give a short 2-4 sentence Turkish summary and distinguish legend/tradition from established history.
9) KONAKLAMA: return only the requested accommodation type. Do not invent current prices or availability.
10) Prefer official tourism/culture/municipal sources for heritage and legends. For businesses, use credible current business/guide sources. SourceLabel must name the source(s) you actually relied on.
11) You may keep good candidates and may add better verified results found during research. Return at most 8 items.
12) Output Turkish text. Output JSON only, no markdown.

Return exactly this JSON shape:
{"items":[{"name":"...","area":"...","address":"...","why":"...","tags":["..."],"established":"","sourceLabel":"...","routeQuery":"...","confidence":0.0,"fameScore":0,"localScore":0,"typeScore":0,"lat":null,"lon":null}]}
Scores are integers 0-10. confidence is 0-1. Omit uncertain items instead of lowering standards.
`;

    const payload = {
      model: env.OPENAI_MODEL || "gpt-5.5",
      tools: [{ type: "web_search" }],
      tool_choice: "auto",
      instructions: rules,
      input: JSON.stringify({ region, categoryKey, categoryTitle, strictType, mode, candidates })
    };

    let upstream = await callOpenAI(env.OPENAI_API_KEY, payload);
    // If an account/model does not support web_search, still keep AI classification alive.
    if (!upstream.ok && [400, 404].includes(upstream.status)) {
      delete payload.tools;
      delete payload.tool_choice;
      upstream = await callOpenAI(env.OPENAI_API_KEY, payload);
    }
    if (!upstream.ok) {
      const err = await upstream.text();
      return json({ error: "OpenAI request failed", detail: err.slice(0, 700) }, 502);
    }

    const data = await upstream.json();
    const text = extractText(data);
    if (!text) return json({ error: "Empty AI response" }, 502);

    try {
      const parsed = JSON.parse(stripFence(text));
      const items = Array.isArray(parsed.items) ? parsed.items.slice(0, 8) : [];
      return json({ items });
    } catch {
      return json({ error: "AI JSON parse failed", detail: text.slice(0, 700) }, 502);
    }
  }
};

async function callOpenAI(key, payload) {
  return fetch(OPENAI_URL, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${key}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });
}

function extractText(data) {
  if (typeof data.output_text === "string" && data.output_text.trim()) return data.output_text;
  let out = "";
  for (const item of (data.output || [])) {
    for (const c of (item.content || [])) {
      if (c.type === "output_text" && typeof c.text === "string") out += c.text;
    }
  }
  return out;
}

function stripFence(s) {
  return s.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "").trim();
}

function clean(v, max) {
  return String(v ?? "").replace(/[\u0000-\u001f]/g, " ").trim().slice(0, max);
}

function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
  });
}
