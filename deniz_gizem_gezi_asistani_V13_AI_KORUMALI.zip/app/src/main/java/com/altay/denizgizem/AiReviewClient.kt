package com.altay.denizgizem

import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

/**
 * V13 AI doğrulama katmanı.
 * OpenAI anahtarı APK'ya KONMAZ. Uygulama yalnız güvenli proxy URL'sine bağlanır.
 */
object AiReviewClient {
    private val endpoint: String
        get() = BuildConfig.AI_PROXY_URL.trim().trimEnd('/')

    fun isEnabled(): Boolean = endpoint.startsWith("https://")

    fun enrich(region: String, category: CategorySpec, candidates: List<PlaceItem>): List<PlaceItem>? {
        if (!isEnabled()) return null
        return try {
            val payload = buildPayload(region, category, candidates.take(12))
            val body = postJson(endpoint, payload)
            parseItems(body, region, category)
        } catch (_: Throwable) {
            null
        }
    }

    private fun buildPayload(region: String, category: CategorySpec, candidates: List<PlaceItem>): String {
        val list = candidates.joinToString(",") { p ->
            """{
              "name":"${esc(p.name)}",
              "area":"${esc(p.area)}",
              "address":"${esc(p.address)}",
              "why":"${esc(p.why)}",
              "source":"${esc(p.sourceLabel)}",
              "lat":${p.lat?.toString() ?: "null"},
              "lon":${p.lon?.toString() ?: "null"},
              "verified":${p.verified}
            }""".trimIndent()
        }
        return """{
          "region":"${esc(region)}",
          "categoryKey":"${esc(category.key)}",
          "categoryTitle":"${esc(category.title)}",
          "strictType":"${esc(category.strictType)}",
          "mode":"${if (category.key == "gizem") "research" else "review"}",
          "candidates":[$list]
        }""".trimIndent()
    }

    @Suppress("UNCHECKED_CAST")
    private fun parseItems(body: String, region: String, category: CategorySpec): List<PlaceItem> {
        val root = MiniJson.parse(body) as? Map<String, Any?> ?: return emptyList()
        val items = root["items"] as? List<Any?> ?: return emptyList()
        return items.mapNotNull { raw ->
            val x = raw as? Map<String, Any?> ?: return@mapNotNull null
            val name = x["name"]?.toString()?.trim().orEmpty()
            if (!SafetyRules.isMeaningfulName(name)) return@mapNotNull null
            val tags = (x["tags"] as? List<Any?>)?.mapNotNull { it?.toString()?.trim() }
                ?.filter { it.isNotBlank() }?.take(4).orEmpty()
            val confidence = number(x["confidence"]) ?: 0.80
            if (confidence < 0.62) return@mapNotNull null
            PlaceItem(
                name = name,
                categoryKey = category.key,
                group = category.group,
                area = x["area"]?.toString()?.trim().takeUnless { it.isNullOrBlank() } ?: region,
                address = x["address"]?.toString()?.trim().orEmpty(),
                why = x["why"]?.toString()?.trim().orEmpty(),
                tags = (listOf("🤖 AI doğrulandı") + tags).distinct(),
                established = x["established"]?.toString()?.trim().orEmpty(),
                sourceLabel = x["sourceLabel"]?.toString()?.trim().takeUnless { it.isNullOrBlank() } ?: "AI kaynak doğrulaması",
                routeQuery = x["routeQuery"]?.toString()?.trim().takeUnless { it.isNullOrBlank() } ?: "$name $region",
                verified = true,
                fameScore = (number(x["fameScore"])?.toInt() ?: 8).coerceIn(0, 10),
                localScore = (number(x["localScore"])?.toInt() ?: 8).coerceIn(0, 10),
                typeScore = (number(x["typeScore"])?.toInt() ?: 10).coerceIn(0, 10),
                lat = number(x["lat"]),
                lon = number(x["lon"]),
                live = false
            )
        }
    }

    private fun number(v: Any?): Double? = when (v) {
        is Number -> v.toDouble()
        is String -> v.toDoubleOrNull()
        else -> null
    }

    private fun postJson(url: String, payload: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 6000
        c.readTimeout = 18000
        c.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
        c.setRequestProperty("Accept", "application/json")
        c.setRequestProperty("User-Agent", "DenizGizemGeziAsistani/13.0")
        c.outputStream.use { it.write(payload.toByteArray(StandardCharsets.UTF_8)) }
        val code = c.responseCode
        val input = if (code in 200..299) c.inputStream else c.errorStream
        val body = BufferedReader(InputStreamReader(input, StandardCharsets.UTF_8)).use { r ->
            buildString {
                while (true) {
                    val line = r.readLine() ?: break
                    append(line)
                }
            }
        }
        c.disconnect()
        if (code !in 200..299) error("AI proxy HTTP $code")
        return body
    }

    private fun esc(s: String): String = buildString {
        s.forEach { ch ->
            when (ch) {
                '\\' -> append("\\\\")
                '"' -> append("\\\"")
                '\n' -> append("\\n")
                '\r' -> append("\\r")
                '\t' -> append("\\t")
                else -> append(ch)
            }
        }
    }
}
