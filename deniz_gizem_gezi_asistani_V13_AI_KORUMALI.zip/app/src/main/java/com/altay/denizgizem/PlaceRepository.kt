package com.altay.denizgizem

data class SearchBundle(
    val regionKey: String,
    val categoryKey: String,
    val items: List<PlaceItem>,
    val offlineCount: Int,
    val liveCount: Int,
    val liveOk: Boolean,
    val deepPending: Boolean,
    val status: String
)

object PlaceRepository {
    fun offline(region: String, category: CategorySpec): SearchBundle {
        val local = OfflineCatalog.find(region, category.key)
        return SearchBundle(
            regionKey=TextNorm.norm(region), categoryKey=category.key,
            items=local.take(15), offlineCount=local.size, liveCount=0,
            liveOk=false, deepPending=true,
            status=if(local.isNotEmpty())
                "${local.size} doğrulanmış sonuç anında hazır"
            else
                "⚡ Güvenli canlı arama başlatıldı"
        )
    }

    fun quick(region: String, category: CategorySpec): SearchBundle {
        val local = OfflineCatalog.find(region, category.key)
        return try {
            val quick = LiveOsmClient.quickSearch(region, category)
            val merged = SafetyRules.mergeAndRank(local, quick)
                .filter { it.categoryKey == category.key && SafetyRules.isMeaningfulName(it.name) }
                .take(15)
            SearchBundle(
                regionKey=TextNorm.norm(region), categoryKey=category.key,
                items=merged, offlineCount=local.size, liveCount=quick.size,
                liveOk=true, deepPending=true,
                status=when {
                    merged.isEmpty() -> "İlk güvenli taramada eşleşme çıkmadı; derin tarama sürüyor"
                    quick.isEmpty() && local.isNotEmpty() -> "Doğrulanmış sonuçlar hazır; daha fazla yer aranıyor"
                    else -> "⚡ ${merged.size} kategori-doğrulanmış sonuç hazır • derin tarama sürüyor"
                }
            )
        } catch (_: Throwable) {
            SearchBundle(
                regionKey=TextNorm.norm(region), categoryKey=category.key,
                items=local.take(15), offlineCount=local.size, liveCount=0,
                liveOk=local.isNotEmpty(), deepPending=true,
                status=if(local.isNotEmpty()) "Doğrulanmış sonuçlar hazır • derin tarama sürüyor"
                else "Hızlı kaynak cevap vermedi • derin tarama sürüyor"
            )
        }
    }

    fun deep(region: String, category: CategorySpec, current: List<PlaceItem>): SearchBundle {
        val local = OfflineCatalog.find(region, category.key)
        var sourceOk = false
        val deep = try {
            LiveOsmClient.deepSearch(region, category).also { sourceOk = true }
        } catch (_: Throwable) {
            emptyList()
        }

        val deterministic = SafetyRules.mergeAndRank(SafetyRules.mergeAndRank(local, current), deep)
            .filter { it.categoryKey == category.key && SafetyRules.isMeaningfulName(it.name) }
            .take(20)

        // V13 AI: güvenli proxy ayarlıysa adayları ikinci kez denetler.
        // Gizem/Efsane kategorisinde adaylarla sınırlı kalmaz; kaynaklı yerel anlatı araştırması ister.
        val aiItems = AiReviewClient.enrich(region, category, deterministic)
        val aiUsed = aiItems != null
        val merged = when {
            aiItems == null -> deterministic
            category.key == "gizem" -> SafetyRules.mergeAndRank(local, aiItems).take(20)
            else -> SafetyRules.mergeAndRank(local, aiItems).take(20)
        }

        val status = when {
            merged.isEmpty() && aiUsed -> "AI kontrolü tamamlandı • bu kategoride güvenilir eşleşme bulunamadı"
            merged.isEmpty() -> "Bu bölgede güvenilir kategori eşleşmesi bulunamadı"
            aiUsed -> "🤖 AI doğrulaması tamamlandı • ${merged.size} güvenli sonuç"
            sourceOk -> "✅ ${merged.size} güvenli sonuç • kategori koruması aktif"
            else -> "Mevcut güvenli sonuçlar gösteriliyor; canlı kaynak geçici olarak cevap vermedi"
        }

        return SearchBundle(
            regionKey=TextNorm.norm(region), categoryKey=category.key,
            items=merged, offlineCount=local.size,
            liveCount=merged.count { it.live }, liveOk=merged.isNotEmpty(), deepPending=false,
            status=status
        )
    }
}
