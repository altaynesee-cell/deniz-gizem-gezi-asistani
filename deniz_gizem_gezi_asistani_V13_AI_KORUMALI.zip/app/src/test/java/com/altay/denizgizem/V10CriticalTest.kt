package com.altay.denizgizem

import org.junit.Assert.*
import org.junit.Test

class V10CriticalTest {
    @Test
    fun bursaPlajOfflineIsRichAndSafe() {
        val x = OfflineCatalog.find("Bursa", "plaj")
        assertTrue("Bursa plaj sayısı", x.size >= 8)
        assertTrue(x.all { TextNorm.norm(it.area).contains("bursa") })
        assertTrue(x.none { TextNorm.norm(it.name).contains("alanya") })
        assertTrue(x.none { TextNorm.norm(it.name).contains("market") })
        assertTrue(x.first().verified)
    }

    @Test
    fun bursaKaleReturnsMultipleVerifiedPlaces() {
        val x = OfflineCatalog.find("Bursa", "kale")
        assertTrue("Bursa kale/hisar seçenekleri", x.size >= 5)
        assertEquals("Bursa Kalesi ve Hisar Surları", x.first().name)
        assertTrue(x.all { it.verified })
    }

    @Test
    fun bodrumCigerciYasinIsFirst() {
        val x = OfflineCatalog.find("Bodrum", "ciger")
        assertTrue(x.isNotEmpty())
        assertEquals("Ciğerci Yasin", x.first().name)
        assertTrue(x.first().tags.any { it.contains("meşhur", ignoreCase = true) })
    }

    @Test
    fun bodrumMagaraIsRealCaveNotCafe() {
        val x = OfflineCatalog.find("Bodrum", "magara")
        assertTrue(x.any { it.name == "Peynir Çiçeği Mağarası" })
        assertTrue(x.none { TextNorm.norm(it.name).contains("cafe") || TextNorm.norm(it.name).contains("kafe") })
    }

    @Test
    fun safetyRejectsBadSeaBusinesses() {
        val plaj = Categories.byKey("plaj")
        assertFalse(SafetyRules.acceptLive("Deniz Market", plaj, "Beach / Plaj"))
        assertFalse(SafetyRules.acceptLive("Akbank", plaj, "Beach / Plaj"))
        assertTrue(SafetyRules.acceptLive("Eşkel Halk Plajı", plaj, "Beach / Plaj"))
    }

    @Test
    fun safetyRejectsCaveCafe() {
        val cave = Categories.byKey("magara")
        assertFalse(SafetyRules.acceptLive("Mağara Cafe", cave, "Cafe"))
        assertTrue(SafetyRules.acceptLive("Karain Mağarası", cave, "Cave / Mağara"))
    }

    @Test
    fun bursaBoundsRejectAlanya() {
        val b = RegionCatalog.known("Bursa")!!
        assertFalse(b.contains(36.54, 31.99))
        assertTrue(b.contains(40.38, 28.88))
    }

    @Test
    fun curatedResultsBeatLiveResults() {
        val local = PlaceItem(
            "Yerel Meşhur", "ciger", Group.FOOD, "Bodrum",
            verified = true, fameScore = 10, localScore = 10, typeScore = 10
        )
        val live = PlaceItem(
            "Canlı Sonuç", "ciger", Group.FOOD, "Bodrum",
            verified = false, fameScore = 5, localScore = 6, typeScore = 10, live = true
        )
        assertTrue(local.smartScore() > live.smartScore())
    }

    @Test
    fun bodrumAntikHasManyCuratedResults() {
        val x = OfflineCatalog.find("Bodrum", "antik")
        assertTrue("Bodrum antik kent sayısı", x.size >= 8)
        assertTrue(x.any { it.name.contains("Pedasa") })
        assertTrue(x.any { it.name.contains("Myndos") })
        assertTrue(x.all { it.categoryKey == "antik" })
        assertTrue(x.none { TextNorm.norm(it.name).contains("akyarlar sahili") })
    }

    @Test
    fun bodrumGizemHasShortStories() {
        val x = OfflineCatalog.find("Bodrum", "gizem")
        assertTrue(x.size >= 5)
        assertTrue(x.all { it.why.length >= 80 })
        assertTrue(x.any { it.name.contains("Salmakis") })
        assertTrue(x.any { it.name.contains("Pedasa") })
    }

    @Test
    fun bodrumFoodHasTopRecommendationForEveryButton() {
        listOf("ciger","kofte","kebap","sulu","tavuk","esnaf","balik","kahvalti").forEach { key ->
            val x = OfflineCatalog.find("Bodrum", key)
            assertTrue("Bodrum $key boş", x.isNotEmpty())
            assertEquals(key, x.first().categoryKey)
            assertTrue("$key ilk tavsiyesi güçlü olmalı", x.first().fameScore >= 8)
        }
    }

    @Test
    fun bodrumShallowSandyHasManyOfflineResults() {
        val x = OfflineCatalog.find("Bodrum", "kum")
        assertTrue("Bodrum kumlu/sığ sonuç sayısı", x.size >= 7)
        assertTrue(x.all { it.categoryKey == "kum" })
        assertTrue(x.all { TextNorm.norm(it.area).contains("bodrum") })
        assertTrue(x.any { it.name == "Bitez Plajı" })
        assertTrue(x.any { it.name.contains("Camel Beach") })
        assertTrue(x.any { it.name == "Karaincir Halk Plajı" })
        assertTrue(x.any { it.name.contains("Gümbet") })
    }

    @Test
    fun everyButtonHasNationwideLiveQuery() {
        val b = RegionBounds("Test", 36.0, 32.0, 37.0, 33.0, 36.5, 32.5)
        Categories.all.forEach { c ->
            val q = LiveOsmClient.buildQuery(b, c)
            assertTrue("Query boş: ${c.key}", q.contains("out center"))
            assertTrue("Hedefli terim boş: ${c.key}", LiveOsmClient.queryTerms(c).isNotEmpty())
        }
    }

    @Test
    fun tarsusKofteCanaryExistsButEngineIsNotTarsusOnly() {
        val t = OfflineCatalog.find("Tarsus", "kofte")
        assertTrue(t.any { it.name == "Köfteci" })
        assertTrue(Categories.all.size >= 20)
        assertTrue(LiveOsmClient.queryTerms(Categories.byKey("kofte")).contains("köfteci"))
    }

    @Test
    fun mysteryIsLiveNationwideNotCuratedOnly() {
        assertEquals("mystery", Categories.byKey("gizem").strictType)
        val q = LiveOsmClient.buildQuery(RegionBounds("X",36.0,32.0,37.0,33.0,36.5,32.5), Categories.byKey("gizem"))
        assertTrue(q.contains("wikipedia") || q.contains("wikidata"))
    }

    @Test
    fun shallowSandButtonIsStrictlyARealBeachSearch() {
        assertEquals("Sığ + Kum", Categories.byKey("kum").title)
        assertFalse(SafetyRules.acceptLive("Deniz Market", Categories.byKey("kum"), "Beach / Plaj", evidence="sand"))
        assertTrue(SafetyRules.acceptLive("Kumsal Plajı", Categories.byKey("kum"), "Beach / Plaj", evidence="sand"))
    }

    @Test
    fun v12NeverShowsUnnamedOrGenericPoiNames() {
        assertFalse(SafetyRules.isMeaningfulName("Unnamed"))
        assertFalse(SafetyRules.isMeaningfulName("Isimsiz"))
        assertFalse(SafetyRules.isMeaningfulName("Restaurant"))
        assertTrue(SafetyRules.isMeaningfulName("Köfteci"))
    }

    @Test
    fun v12UsesFastFirstTermAndShorterDeepQuery() {
        val k = Categories.byKey("kofte")
        assertEquals("köfteci", LiveOsmClient.queryTerms(k).first())
        val q = LiveOsmClient.buildQuery(
            RegionBounds("Tarsus",36.7,34.7,37.2,35.2,36.92,34.90), k
        )
        assertTrue(q.contains("timeout:9"))
        assertTrue(q.contains("köfte") || q.contains("kofte"))
    }

    @Test
    fun v13CastleNeverTrustsBusinessNameAlone() {
        val castle = Categories.byKey("kale")
        assertFalse(SafetyRules.acceptLive("Kale Pastanesi", castle, "Cafe"))
        assertFalse(SafetyRules.acceptLive("Hisar Otel", castle, "Hotel"))
        assertFalse(SafetyRules.acceptLive("Kale Market", castle, "Shop"))
        assertTrue(SafetyRules.acceptLive("Gülek Kalesi", castle, "Historic / Castle"))
        assertTrue(SafetyRules.acceptLive("Kleopatra Kapısı", castle, "Historic / city_gate"))
    }

    @Test
    fun v13TarsusHasVerifiedCastleAndLegends() {
        val castles = OfflineCatalog.find("Tarsus", "kale")
        assertTrue(castles.any { it.name == "Gülek Kalesi" })
        assertTrue(castles.none { TextNorm.norm(it.name).contains("pastane") })

        val legends = OfflineCatalog.find("Tarsus", "gizem")
        assertTrue(legends.any { TextNorm.norm(it.name).contains("sahmaran") })
        assertTrue(legends.any { TextNorm.norm(it.name).contains("eshab i kehf") || TextNorm.norm(it.name).contains("yedi uyurlar") })
        assertTrue(legends.all { it.why.length >= 100 })
    }

    @Test
    fun v13MysteryDoesNotTreatEveryHistoricPoiAsLegend() {
        val mystery = Categories.byKey("gizem")
        assertFalse(SafetyRules.acceptLive("Tarihi Taş Köprü", mystery, "Historic", evidence="wikipedia wikidata"))
        assertTrue(SafetyRules.acceptLive("Şahmaran Efsanesi", mystery, "Historic", evidence="Tarsus efsane"))
    }

}
