package com.altay.denizgizem;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class TravelData {

    public static final class Item {
        public final String title;
        public final String detail;
        public Item(String title, String detail) {
            this.title = title;
            this.detail = detail;
        }
    }

    public static final class Destination {
        public final String name;
        public final String intro;
        public final List<Item> sea;
        public final List<Item> food;
        public final List<Item> discover;
        public final List<Item> stay;

        public Destination(String name, String intro,
                           List<Item> sea, List<Item> food,
                           List<Item> discover, List<Item> stay) {
            this.name = name;
            this.intro = intro;
            this.sea = sea;
            this.food = food;
            this.discover = discover;
            this.stay = stay;
        }
    }

    private static final Map<String, Destination> DATA = new LinkedHashMap<>();
    private static final Map<String, String> ALIASES = new LinkedHashMap<>();

    static {
        add("Antalya", "Antalya merkez ve il genelinden deniz, lezzet, tarih ve konaklama seçkisi.",
            list(
                item("Evrenseki – Side hattı", "Kum ağırlıklı kıyı ve uzun sığlaşan bölümleriyle aile tipi deniz arayanlar için öne çıkar."),
                item("Çolaklı – Side", "Geniş kum sahili; kıyı yapısı Antalya'nın çakıllı merkez plajlarına göre daha yumuşaktır."),
                item("Lara Plajı", "Kum ağırlıklı uzun sahil. Denizin durumu rüzgâra göre değişebilir."),
                item("Konyaaltı Plajı", "Çakıl ağırlıklıdır ve çabuk derinleşebilen bölümleri vardır; sığ-kum önceliğinde ikinci planda düşün.")
            ),
            list(
                item("Antalya piyazı", "Tahinli sosuyla kentin en bilinen yerel lezzetlerinden."),
                item("Şiş köfte / şişçi geleneği", "Köfte ve piyaz ikilisi Antalya'da klasik bir seçimdir."),
                item("7 Mehmet", "Antalya'nın köklü restoran geleneklerinden biri olarak bilinir; klasik yöresel yemekler için tarihî bir referanstır."),
                item("Yanık dondurma", "Keçi sütü ve kendine özgü aromasıyla Antalya çevresinde bilinen yerel tat.")
            ),
            list(
                item("Perge", "Roma dönemi caddeleri, stadyumu ve anıtsal yapılarıyla Antalya'nın başlıca antik kentlerinden."),
                item("Termessos", "Dağlık konumu ve güçlü savunma yapısıyla sıra dışı atmosferi olan Pisidia kenti."),
                item("Aspendos", "Çok iyi korunmuş Roma tiyatrosuyla ünlü."),
                item("Yanartaş / Chimera", "Çıralı yakınındaki sürekli yanan doğal gaz çıkışları, antik Kimera anlatısıyla ilişkilendirilir."),
                item("Kaleiçi", "Roma, Selçuklu ve Osmanlı katmanlarının aynı alanda görülebildiği tarihî merkez.")
            ),
            list(
                item("Kaleiçi pansiyonları", "Merkezde yürüyerek gezi isteyenler için; küçük pansiyonlar erken rezervasyonda avantajlı olabilir."),
                item("Konyaaltı apart / pansiyon", "Plaj ve şehir ulaşımını birlikte isteyenler için."),
                item("Side – Çolaklı çevresi", "Kum plajına öncelik verenler için konaklama bölgesi."),
                item("Çıralı pansiyonları", "Doğa, antik alan ve sahili birlikte isteyenler için sakin seçenek.")
            )
        );

        add("Çıralı", "Olympos, Yanartaş ve sakin sahil hattını bir arada sunan küçük Akdeniz yerleşimi.",
            list(
                item("Çıralı Plajı", "Kum-çakıl karışık sahil; geniş ve doğal. Deniz bazı günler hızlı derinleşebilir."),
                item("Olympos Plajı", "Antik kent çıkışında doğal sahil; kum-çakıl karışımı."),
                item("Adrasan", "Yakın çevrede daha korunaklı koy seçeneklerinden biri.")
            ),
            list(
                item("Gözleme ve köy kahvaltısı", "Bölgede küçük aile işletmelerinde sık rastlanan seçenek."),
                item("Taze balık", "Sahil çevresindeki küçük restoranlarda yaygın."),
                item("Portakal ve nar ürünleri", "Antalya'nın narenciye geleneği bölgede de belirgindir.")
            ),
            list(
                item("Olympos Antik Kenti", "Likya ve Roma döneminden kalıntılar, dere yatağı ve sahile açılan antik yerleşim."),
                item("Yanartaş / Chimera", "Kayalardan çıkan doğal alevler ve Kimera efsanesi."),
                item("Ulupınar", "Su kaynakları ve doğa içindeki restoranlarıyla bilinen yakın durak.")
            ),
            list(
                item("Çıralı aile pansiyonları", "Sahile yakın küçük işletmeler; sakinlik arayanlar için."),
                item("Bungalovlar", "Bahçeli ve doğa içinde konaklama isteyenler için yaygın."),
                item("Olympos ağaç ev / pansiyon", "Daha genç ve hareketli atmosfer isteyenler için.")
            )
        );

        add("Alanya", "Kale, mağaralar ve uzun sahil şeridiyle doğu Antalya'nın güçlü gezi merkezlerinden.",
            list(
                item("Kleopatra Plajı", "Kum ağırlıklı ve berrak; bazı günler kısa mesafede derinleşebilir."),
                item("İncekum", "Adından da anlaşılacağı gibi ince kumlu ve sığlaşan bölümleriyle aileler için öne çıkar."),
                item("Avsallar sahilleri", "Korunaklı koy ve kumlu bölümler bulunur.")
            ),
            list(
                item("Alanya bohçası", "Yöresel mutfakta hamur işi seçeneklerinden."),
                item("Öksüz helvası", "Alanya çevresinde bilinen geleneksel tatlı."),
                item("Taze balık ve Akdeniz mezeleri", "Liman ve sahil çevresinde yaygın.")
            ),
            list(
                item("Alanya Kalesi", "Selçuklu döneminin güçlü savunma yapılarından."),
                item("Kızılkule", "Liman savunmasının simge yapısı."),
                item("Damlataş Mağarası", "Merkezde kolay ulaşılabilen mağara."),
                item("Syedra", "Alanya doğusunda, deniz manzaralı antik kent.")
            ),
            list(
                item("Kleopatra çevresi apartlar", "Merkeze ve plaja yakın ekonomik seçenekler bulunabilir."),
                item("Avsallar", "Daha sakin ve kumlu sahile yakın konaklama isteyenlere."),
                item("Mahmutlar", "Uzun süreli apart tipi konaklamada seçenek sayısı yüksektir.")
            )
        );

        add("Kaş", "Likya kalıntıları, berrak koylar ve küçük merkez dokusuyla Batı Antalya'nın karakterli durağı.",
            list(
                item("Kaputaş", "Kum-çakıl karışık, çok berrak; hızlı derinleşebilir."),
                item("Büyük Çakıl", "Adı gibi çakıllı; sığ kum arayanlar için uygun değildir."),
                item("Patara", "Kaş çevresinin en güçlü kum ve sığ deniz seçeneklerinden; çok uzun sahil.")
            ),
            list(
                item("Deniz ürünleri", "Kaş merkezde meze ve balık ağırlıklı mutfak güçlüdür."),
                item("Yöresel otlar ve zeytinyağlılar", "Likya kıyı mutfağında yaygın."),
                item("Dondurma ve küçük pastaneler", "Merkez yürüyüş rotasında klasik mola.")
            ),
            list(
                item("Antiphellos Tiyatrosu", "Kaş merkezde gün batımıyla öne çıkan antik tiyatro."),
                item("Likya Kaya Mezarları", "Kent dokusunun içinde görülebilen Likya izleri."),
                item("Patara Antik Kenti", "Likya Birliği'nin önemli merkezlerinden."),
                item("Kekova", "Batık kalıntılar ve kıyı yerleşimleriyle tekne rotası.")
            ),
            list(
                item("Kaş merkez pansiyonları", "Akşam yürüyüşü ve restoranlara erişim için."),
                item("Çukurbağ Yarımadası", "Daha sakin, manzaralı konaklama isteyenler için."),
                item("Patara / Gelemiş", "Kum plaj ve antik kent odaklı daha sakin konaklama.")
            )
        );

        add("Fethiye", "Likya tarihi, koylar ve dağ-deniz birlikteliğiyle Muğla'nın önemli gezi merkezi.",
            list(
                item("Çalış Plajı", "Uzun sahil; kum-çakıl karışık."),
                item("Ölüdeniz", "Lagün bölümü sakin suyla öne çıkar; yoğun sezonda kalabalık olabilir."),
                item("Kıdrak", "Çamlık çevre ve berrak deniz; çakıl-kum karışımı.")
            ),
            list(
                item("Fethiye usulü balık ve mezeler", "Balık pazarı çevresi klasik durak."),
                item("Babadağ keşkeği ve yöresel ev yemekleri", "Muğla çevresinin köy mutfağından örnekler."),
                item("Gözleme", "Köy yolları ve koy rotalarında sık bulunur.")
            ),
            list(
                item("Kayaköy", "Terk edilmiş Rum yerleşimi ve taş evleriyle güçlü atmosfer."),
                item("Telmessos Kaya Mezarları", "Fethiye merkezde Likya kaya mezarları."),
                item("Tlos", "Likya, Roma ve Osmanlı katmanlarını taşıyan antik yerleşim."),
                item("Saklıkent", "Dar kanyon ve güçlü su akışıyla doğa rotası.")
            ),
            list(
                item("Fethiye merkez pansiyonları", "Çarşı ve limana yakın."),
                item("Çalış apartları", "Sahil ve uzun süreli konaklama için."),
                item("Kayaköy", "Taş ev ve sakinlik isteyenler için.")
            )
        );

        add("Marmaris", "Koylar, çam ormanları ve yarımada rotalarıyla deniz odaklı Muğla durağı.",
            list(
                item("İçmeler", "Kum-çakıl karışık, korunaklı koy; genelde merkezden daha sakin."),
                item("Turunç", "Korunaklı koy ve berrak su."),
                item("Çiftlik Koyu", "Kumlu bölümleri ve sakin koy yapısıyla öne çıkar.")
            ),
            list(
                item("Çam balı", "Marmaris ve Muğla çevresinin bilinen yerel ürünü."),
                item("Deniz ürünleri ve mezeler", "Koy ve marina çevresinde yaygın."),
                item("Muğla köftesi", "Bölge genelinde aranabilecek klasik et yemeği.")
            ),
            list(
                item("Marmaris Kalesi", "Liman üstündeki tarihî yapı ve müze."),
                item("Amos Antik Kenti", "Turunç yakınında küçük ama manzaralı antik yerleşim."),
                item("Bozukkale / Loryma", "Yarımada üzerinde antik liman ve kale kalıntıları.")
            ),
            list(
                item("İçmeler apartları", "Koy ve merkez arasında dengeli seçenek."),
                item("Turunç pansiyonları", "Daha küçük ve sakin yerleşim isteyenler için."),
                item("Marmaris merkez", "Gece hayatı ve ulaşım kolaylığı isteyenlere.")
            )
        );

        add("Datça", "Sakin koylar, Eski Datça ve Knidos ile doğa-tarih dengesi güçlü yarımada.",
            list(
                item("Karaincir", "Datça'nın en bilinen sığ ve kumlu plaj seçeneklerinden."),
                item("Hayıtbükü", "Küçük, korunaklı koy; kum-çakıl karışık."),
                item("Palamutbükü", "Berrak su; sahil yapısı kum-çakıl karışımı.")
            ),
            list(
                item("Datça bademi", "Yarımadanın simge ürünü."),
                item("Bademli tatlılar ve dondurma", "Merkezde sık bulunur."),
                item("Balık ve mezeler", "Sahil restoranlarının temel mutfağı.")
            ),
            list(
                item("Knidos", "Yarımadanın ucunda büyük antik kent ve limanlar."),
                item("Eski Datça", "Taş evleri ve dar sokaklarıyla tarihî yerleşim."),
                item("Kızlan Yel Değirmenleri", "Yarımadanın kırsal geçmişine ait dikkat çekici yapılar.")
            ),
            list(
                item("Eski Datça pansiyonları", "Taş ev atmosferi isteyenlere."),
                item("Karaincir", "Sığ-kum plajı önceliği olanlara."),
                item("Palamutbükü", "Denize yakın küçük pansiyonlar için.")
            )
        );

        add("Bodrum", "Karyalı geçmişi, kale ve çok sayıda koyuyla Ege'nin klasik gezi merkezi.",
            list(
                item("Akyarlar", "Kumlu ve nispeten sığ sahil bölümleriyle aileler için güçlü seçenek."),
                item("Bitez", "Koy yapısı ve sığlaşan bölümleriyle rahat deniz."),
                item("Ortakent Yahşi", "Uzun sahil; kum-çakıl karışık.")
            ),
            list(
                item("Çökertme kebabı", "Bodrum adıyla özdeşleşmiş popüler et yemeği."),
                item("Deniz börülcesi ve Ege otları", "Zeytinyağlı Ege mutfağının temel tatları."),
                item("Balık ve meze", "Sahil yerleşimlerinde klasik seçenek.")
            ),
            list(
                item("Bodrum Kalesi", "Sualtı Arkeoloji Müzesi ile birlikte ana tarih durağı."),
                item("Halikarnas Mozolesi", "Antik dünyanın Yedi Harikası arasında anılan anıtın kalıntıları."),
                item("Pedasa", "Bodrum yarımadasındaki Leleg yerleşimi kalıntıları.")
            ),
            list(
                item("Bitez apartları", "Merkezden daha sakin, sahile yakın."),
                item("Akyarlar pansiyonları", "Sığ denize öncelik verenler için."),
                item("Bodrum merkez", "Gece hayatı ve tarihî alanlara yakınlık için.")
            )
        );

        add("Didim", "Altınkum sahili ve Apollon Tapınağı ile deniz-tarih birlikteliği güçlü Aydın durağı.",
            list(
                item("Altınkum", "Adını kumundan alır; sığlaşan bölümleriyle aileler için popüler."),
                item("Manastır Koyu çevresi", "Küçük koylar ve daha sakin deniz arayanlar için."),
                item("Akbük", "Korunaklı koy yapısı ve sakin suyla öne çıkar.")
            ),
            list(
                item("Ege otları", "Zeytinyağlı yerel mutfakta güçlü."),
                item("Balık ve mezeler", "Akbük ve kıyı hattında yaygın."),
                item("Aydın inciri", "Bölgesel ürün olarak tatlı ve kahvaltıda sık görülür.")
            ),
            list(
                item("Didyma Apollon Tapınağı", "Antik dünyanın büyük kehanet merkezlerinden."),
                item("Miletos", "Tiyatro, hamam ve kent planıyla önemli İyon kenti."),
                item("Priene", "Izgara planı ve Athena Tapınağı ile dikkat çeken antik kent.")
            ),
            list(
                item("Altınkum apartları", "Plaj erişimi ve ekonomik seçenekler için."),
                item("Akbük pansiyonları", "Daha sakin koy isteyenler için."),
                item("Didim merkez", "Ulaşım ve alışveriş kolaylığı için.")
            )
        );

        add("Kuşadası", "Efes'e yakınlığı, plajları ve limanıyla Aydın'ın hareketli sahil merkezi.",
            list(
                item("Kadınlar Denizi", "Kumlu sahil; erken saatlerde daha sakin olabilir."),
                item("Sevgi Plajı", "Uzun kumlu sahil ve piknik alanları."),
                item("Davutlar kıyıları", "Kumlu bölümler ve daha sakin çevre.")
            ),
            list(
                item("Aydın inciri", "Bölgenin en tanınmış ürünü."),
                item("Zeytinyağlı Ege yemekleri", "Otlar ve sebze yemekleri öne çıkar."),
                item("Balık ve mezeler", "Liman ve sahil çevresinde yaygın.")
            ),
            list(
                item("Efes", "Kuşadası'ndan kısa sürüşle ulaşılabilen dünya çapında antik kent."),
                item("Güvercinada", "Liman girişindeki kale ve ada."),
                item("Panionion / Dilek Yarımadası çevresi", "Antik İyon coğrafyası ve doğal alan.")
            ),
            list(
                item("Kadınlar Denizi pansiyonları", "Plaja yakın ekonomik konaklama için."),
                item("Davutlar / Güzelçamlı", "Daha sakin ve doğaya yakın."),
                item("Kuşadası merkez", "Liman, çarşı ve gece hayatına yakın.")
            )
        );

        add("Çeşme", "Ilıca'nın sığ denizi, Alaçatı dokusu ve Ege mutfağıyla İzmir'in güçlü yaz rotası.",
            list(
                item("Ilıca Plajı", "Uzun, kumlu ve sığ deniziyle öne çıkar."),
                item("Altınkum", "Kumlu sahil; rüzgâr durumuna göre dalga değişebilir."),
                item("Boyalık", "Merkeze yakın, kumlu bölümleri bulunan sahil.")
            ),
            list(
                item("Kumru", "Çeşme'nin en bilinen sandviçlerinden."),
                item("Sakızlı tatlılar", "Çeşme-Alaçatı hattında sakız aroması yaygın."),
                item("Ege otları ve mezeler", "Zeytinyağlı mutfağın temel parçaları.")
            ),
            list(
                item("Çeşme Kalesi", "Osmanlı döneminden güçlü liman kalesi."),
                item("Alaçatı taş evleri", "19. yüzyıl Ege mimarisinin izleri."),
                item("Erythrai", "Ildırı'daki antik İyon yerleşimi.")
            ),
            list(
                item("Ilıca pansiyonları", "Sığ kum plajına yakınlık için."),
                item("Alaçatı butik pansiyonları", "Taş ev atmosferi ve akşam yaşamı için."),
                item("Çeşme merkez", "Kale, marina ve ulaşım kolaylığı için.")
            )
        );

        add("Ayvalık", "Adalar, taş sokaklar, zeytinyağı mutfağı ve Sarımsaklı sahiliyle Kuzey Ege durağı.",
            list(
                item("Sarımsaklı", "Uzun kumlu sahil; sığlaşan bölümleriyle aileler için popüler."),
                item("Badavut", "Sarımsaklı'ya göre daha doğal ve açık kıyı."),
                item("Cunda kıyıları", "Küçük koylar; çoğu taşlık/çakıllı olabilir.")
            ),
            list(
                item("Ayvalık tostu", "Kentin en bilinen hızlı yemeği."),
                item("Papalina", "Küçük balık türü; Ayvalık mutfağında klasik."),
                item("Zeytinyağlılar", "Bölgenin ana mutfak karakteri.")
            ),
            list(
                item("Cunda / Alibey Adası", "Taş sokaklar, kiliseler ve eski Rum dokusu."),
                item("Taksiyarhis", "Ayvalık'ın önemli tarihî kilise yapılarından."),
                item("Şeytan Sofrası", "Gün batımı ve yerel anlatılarıyla tanınan seyir noktası.")
            ),
            list(
                item("Ayvalık merkez pansiyonları", "Tarihî sokaklara yakın."),
                item("Cunda pansiyonları", "Ada atmosferi ve akşam yürüyüşleri için."),
                item("Sarımsaklı", "Kum plajına öncelik verenler için.")
            )
        );

        add("Mersin", "Kızkalesi, mağaralar ve uzun Akdeniz sahiliyle arkeoloji ve deniz açısından güçlü bölge.",
            list(
                item("Kızkalesi Plajı", "Kumlu ve sığlaşan bölümleriyle ailelerin sık tercih ettiği sahil."),
                item("Susanoğlu", "Geniş kumlu sahil."),
                item("Taşucu", "Çevresinde kumlu koy ve plaj seçenekleri bulunur.")
            ),
            list(
                item("Tantuni", "Mersin'in en bilinen yemeği."),
                item("Cezerye", "Havuç, şeker ve kuruyemişle yapılan yerel tatlı."),
                item("Kerebiç", "Özellikle Ramazan döneminde öne çıkan geleneksel tatlı.")
            ),
            list(
                item("Kızkalesi / Korykos", "Kıyı ve deniz kalesiyle güçlü Orta Çağ manzarası."),
                item("Cennet-Cehennem Obrukları", "Mitolojik Typhon anlatılarıyla da ilişkilendirilen büyük karst oluşumları."),
                item("Kanlıdivane", "Antik yerleşim ve büyük obruk çevresindeki kalıntılar."),
                item("Soli Pompeipolis", "Mersin merkez yakınında sütunlu cadde kalıntıları.")
            ),
            list(
                item("Kızkalesi pansiyonları", "Deniz ve tarihî alanı birlikte isteyenler için."),
                item("Silifke merkez", "Çevre antik alanlara ulaşım için."),
                item("Taşucu", "Feribot ve sahil rotaları için.")
            )
        );

        add("Bursa", "Osmanlı mirası, hanlar, kaplıcalar ve güçlü yerel mutfağıyla tarih-kültür durağı.",
            list(
                item("Mudanya", "Bursa'da deniz görmek isteyenler için; sahiller çoğunlukla Marmara karakterindedir."),
                item("Trilye", "Küçük kıyı yerleşimi; tarihî doku ve deniz manzarası."),
                item("Kurşunlu / Gemlik çevresi", "Yazın yerel sahil seçenekleri; Ege-Akdeniz kadar kum-sığ odaklı değildir.")
            ),
            list(
                item("İskender kebap", "Bursa'nın en bilinen yemeği. İskender geleneği 19. yüzyıla uzanır."),
                item("Pideli köfte", "Bursa'da köfte için en karakteristik seçeneklerden."),
                item("Cantık", "Kıymalı yuvarlak pide; Bursa fırın geleneğinin önemli parçası."),
                item("Kestane şekeri", "Kentin klasik tatlı ürünü.")
            ),
            list(
                item("Ulu Cami", "Erken Osmanlı mimarisinin başlıca eserlerinden."),
                item("Koza Han", "İpek ticareti tarihinin merkezlerinden."),
                item("Muradiye Külliyesi", "Osmanlı hanedan türbeleri ve mimari bütünlük."),
                item("İznik", "Roma-Bizans-Osmanlı katmanları ve konsil tarihiyle önemli."),
                item("Gölyazı", "Uluabat Gölü kıyısında antik Apollonia ad Rhyndacum izleri.")
            ),
            list(
                item("Heykel / Hanlar Bölgesi", "Tarihî merkezi yürüyerek gezmek isteyenler için."),
                item("Çekirge", "Kaplıca ve termal otel geleneği için."),
                item("Mudanya", "Deniz kıyısında kalmak isteyenlere.")
            )
        );

        aliases("Antalya", "antalya merkez", "lara", "konyaalti", "konyaaltı", "side", "manavgat");
        aliases("Çıralı", "cirali", "çıralı", "olympos", "olimpos", "adrasan");
        aliases("Alanya", "alanya", "incekum", "avsallar");
        aliases("Kaş", "kas", "kaş", "patara", "kalkan");
        aliases("Fethiye", "fethiye", "oludeniz", "ölüdeniz", "kayakoy", "kayaköy");
        aliases("Marmaris", "marmaris", "icmeler", "içmeler", "turunc", "turunç");
        aliases("Datça", "datca", "datça", "palamutbuku", "palamutbükü", "karaincir");
        aliases("Bodrum", "bodrum", "akyarlar", "bitez", "turgutreis");
        aliases("Didim", "didim", "altinkum didim", "altınkum didim", "akbuk", "akbük");
        aliases("Kuşadası", "kusadasi", "kuşadası", "davutlar", "guzelcamli", "güzelçamlı");
        aliases("Çeşme", "cesme", "çeşme", "alacati", "alaçatı", "ilica", "ılıca");
        aliases("Ayvalık", "ayvalik", "ayvalık", "cunda", "sarimsakli", "sarımsaklı");
        aliases("Mersin", "mersin", "kizkalesi", "kızkalesi", "silifke", "susanoğlu", "susanoglu");
        aliases("Bursa", "bursa", "mudanya", "trilye", "tirilye", "iznik", "golyazi", "gölyazı");
    }

    private TravelData() {}

    private static Item item(String t, String d) { return new Item(t, d); }
    private static List<Item> list(Item... items) { return Arrays.asList(items); }

    private static void add(String key, String intro,
                            List<Item> sea, List<Item> food,
                            List<Item> discover, List<Item> stay) {
        DATA.put(key, new Destination(key, intro, sea, food, discover, stay));
        ALIASES.put(normalize(key), key);
    }

    private static void aliases(String key, String... aliases) {
        for (String a : aliases) ALIASES.put(normalize(a), key);
    }

    public static Destination search(String query) {
        String q = normalize(query);
        if (q.isEmpty()) return null;

        String direct = ALIASES.get(q);
        if (direct != null) return DATA.get(direct);

        String bestDestination = null;
        int bestScore = Integer.MIN_VALUE;

        for (Map.Entry<String, String> e : ALIASES.entrySet()) {
            String alias = e.getKey();
            if (q.contains(alias) || alias.contains(q)) {
                String destination = e.getValue();

                int specificity = 5;
                if ("Antalya".equals(destination) || "Mersin".equals(destination) || "Bursa".equals(destination)) {
                    specificity = 1;
                }

                int score = specificity * 100 + alias.length();

                if (score > bestScore) {
                    bestScore = score;
                    bestDestination = destination;
                }
            }
        }

        return bestDestination == null ? null : DATA.get(bestDestination);
    }

    public static List<String> supportedNames() {
        return new ArrayList<>(DATA.keySet());
    }

    static String normalize(String s) {
        if (s == null) return "";
        String x = s.toLowerCase(new Locale("tr", "TR")).trim()
                .replace('ı', 'i').replace('ğ', 'g').replace('ü', 'u')
                .replace('ş', 's').replace('ö', 'o').replace('ç', 'c');
        x = Normalizer.normalize(x, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        x = x.replaceAll("[^a-z0-9]+", " ").trim().replaceAll("\\s+", " ");
        return x;
    }
}
