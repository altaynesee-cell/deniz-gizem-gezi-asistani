package com.altay.denizgizem;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends Activity {

    private EditText input;
    private TextView status;
    private LinearLayout content;
    private TravelData.Destination current;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(12));

        TextView title = new TextView(this);
        title.setText("DENİZ GİZEM\nGEZİ ASİSTANI");
        title.setTextSize(25);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(8), 0, dp(6));
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Yeri yaz; deniz, lezzet, tarih-gizem ve konaklama bilgileri doğrudan uygulamanın içinde açılsın.");
        subtitle.setTextSize(15);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(dp(6), 0, dp(6), dp(14));
        root.addView(subtitle);

        input = new EditText(this);
        input.setHint("Örn: Antalya, Çıralı, Datça, Bursa");
        input.setSingleLine(true);
        input.setTextSize(19);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        root.addView(input, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        Button search = new Button(this);
        search.setText("BÖLGEYİ BUL");
        search.setOnClickListener(v -> runSearch());
        root.addView(search);

        status = new TextView(this);
        status.setText("Çevrimdışı V4: internet bağlantısı gerektirmez.");
        status.setTextSize(14);
        status.setPadding(0, dp(8), 0, dp(8));
        root.addView(status);

        HorizontalScrollView tabsScroll = new HorizontalScrollView(this);
        tabsScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);

        addTab(tabs, "ÖZET", "summary");
        addTab(tabs, "DENİZ", "sea");
        addTab(tabs, "LEZZET", "food");
        addTab(tabs, "KEŞFET", "discover");
        addTab(tabs, "KONAK", "stay");

        tabsScroll.addView(tabs);
        root.addView(tabsScroll);

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(10), 0, dp(30));
        scroll.addView(content);

        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
        showWelcome();
    }

    private void addTab(LinearLayout tabs, String label, String category) {
        Button b = new Button(this);
        b.setText(label);
        b.setOnClickListener(v -> {
            if (current == null) {
                Toast.makeText(this, "Önce bir bölge bul.", Toast.LENGTH_SHORT).show();
                return;
            }
            showCategory(category);
        });
        tabs.addView(b);
    }

    private void runSearch() {
        String q = input.getText().toString().trim();
        if (q.isEmpty()) {
            Toast.makeText(this, "Bir yer yaz hocam.", Toast.LENGTH_SHORT).show();
            return;
        }

        current = TravelData.search(q);

        if (current == null) {
            status.setText("Bu bölge henüz V4 veri paketinde yok.");
            showNotFound(q);
            return;
        }

        status.setText(current.name + " bulundu. Sonuçlar hazır.");
        showCategory("summary");
    }

    private void showWelcome() {
        clear();
        headline("Nasıl çalışıyor?");
        paragraph("Bu sürüm çevrimdışı çalışır. Başka siteye yönlendirme yapmaz ve ücretsiz harita sunucusu kullanmaz.");
        paragraph("Bir yer yazdığında uygulamanın kendi veri paketindeki deniz, lezzet, tarih-gizem ve konaklama bilgilerini gösterir.");
        headline("V4'te hazır bölgeler");
        paragraph(String.join(" • ", TravelData.supportedNames()));
    }

    private void showNotFound(String q) {
        clear();
        headline("📍 " + q);
        paragraph("Bu yer için henüz çevrimdışı veri eklenmemiş. Uygulama yanlış veya uydurma sonuç göstermiyor.");
        paragraph("Şimdilik desteklenen bölgeler:");
        paragraph(String.join(" • ", TravelData.supportedNames()));
    }

    private void showCategory(String category) {
        clear();

        if ("summary".equals(category)) {
            headline("📍 " + current.name);
            paragraph(current.intro);
            countLine("🌊 Deniz", current.sea.size());
            countLine("🍽️ Lezzet", current.food.size());
            countLine("🏛️ Keşfet", current.discover.size());
            countLine("🛏️ Konak", current.stay.size());
            paragraph("Yukarıdaki sekmelerden ayrıntıları aç.");
            return;
        }

        List<TravelData.Item> items;
        String title;

        switch (category) {
            case "sea":
                items = current.sea;
                title = "🌊 DENİZ — " + current.name;
                break;
            case "food":
                items = current.food;
                title = "🍽️ LEZZET — " + current.name;
                break;
            case "discover":
                items = current.discover;
                title = "🏛️ KEŞFET & GİZEM — " + current.name;
                break;
            case "stay":
                items = current.stay;
                title = "🛏️ KONAK — " + current.name;
                break;
            default:
                showCategory("summary");
                return;
        }

        headline(title);
        for (TravelData.Item item : items) {
            card(item.title, item.detail);
        }
    }

    private void countLine(String label, int count) {
        TextView t = new TextView(this);
        t.setText(label + ": " + count + " öneri");
        t.setTextSize(17);
        t.setPadding(0, dp(4), 0, dp(4));
        content.addView(t);
    }

    private void headline(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(21);
        t.setTypeface(null, Typeface.BOLD);
        t.setPadding(0, dp(12), 0, dp(8));
        content.addView(t);
    }

    private void paragraph(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(16);
        t.setPadding(0, dp(4), 0, dp(10));
        content.addView(t);
    }

    private void card(String title, String detail) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(10), dp(12), dp(12));

        TextView a = new TextView(this);
        a.setText(title);
        a.setTextSize(18);
        a.setTypeface(null, Typeface.BOLD);
        box.addView(a);

        TextView b = new TextView(this);
        b.setText(detail);
        b.setTextSize(15);
        b.setPadding(0, dp(4), 0, dp(6));
        box.addView(b);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(5), 0, dp(7));
        content.addView(box, lp);
    }

    private void clear() {
        content.removeAllViews();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
