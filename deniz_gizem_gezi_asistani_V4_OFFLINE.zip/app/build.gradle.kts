plugins {
    id("com.android.application")
}

android {
    namespace = "com.altay.denizgizem"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.altay.denizgizem"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "4.0-offline"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
