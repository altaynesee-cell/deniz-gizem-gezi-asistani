package com.altay.denizgizem

import org.junit.Assert.*
import org.junit.Test

class CoreTest {
    @Test
    fun turkishNormalizationWorks() {
        assertEquals("gozlukule hoyugu", TextNorm.norm("Gözlükule Höyüğü"))
        assertEquals("tarsus", TextNorm.norm("TARSUS"))
    }

    @Test
    fun allButtonsExist() {
        val keys = Categories.all.map { it.key }.toSet()
        listOf(
            "ciger","kofte","kebap","sulu","tavuk","esnaf","balik","kahvalti",
            "plaj","kum","koy","antik","kale","magara","muze","tarihi","gizem",
            "pansiyon","apart","otel","kamp"
        ).forEach { assertTrue(keys.contains(it)) }
        assertEquals(21, keys.size)
    }
}
