package com.altay.denizgizem

import java.text.Normalizer
import java.util.Locale

enum class Group(val title: String, val emoji: String) {
    FOOD("Lezzet", "🍽"),
    SEA("Deniz", "🌊"),
    DISCOVER("Keşfet", "🏛"),
    STAY("Konak", "🛏")
}

data class CategorySpec(
    val key: String,
    val title: String,
    val emoji: String,
    val group: Group
)

object Categories {
    val all = listOf(
        CategorySpec("ciger", "Ciğer / Arnavut", "🥩", Group.FOOD),
        CategorySpec("kofte", "Köfte", "🧆", Group.FOOD),
        CategorySpec("kebap", "Kebap", "🔥", Group.FOOD),
        CategorySpec("sulu", "Sulu Yemek", "🍲", Group.FOOD),
        CategorySpec("tavuk", "Tavuk", "🍗", Group.FOOD),
        CategorySpec("esnaf", "Esnaf Lokantası", "🥘", Group.FOOD),
        CategorySpec("balik", "Balık", "🐟", Group.FOOD),
        CategorySpec("kahvalti", "Kahvaltı", "🍳", Group.FOOD),

        CategorySpec("plaj", "Plaj", "🏖", Group.SEA),
        CategorySpec("kum", "Sığ + Kum", "👣", Group.SEA),
        CategorySpec("koy", "Koy", "🌊", Group.SEA),

        CategorySpec("antik", "Antik / Arkeolojik", "🏺", Group.DISCOVER),
        CategorySpec("kale", "Kale / Hisar", "🏰", Group.DISCOVER),
        CategorySpec("magara", "Mağara", "🕳", Group.DISCOVER),
        CategorySpec("muze", "Müze", "🏛", Group.DISCOVER),
        CategorySpec("tarihi", "Tarihi Yer", "📜", Group.DISCOVER),
        CategorySpec("gizem", "Gizem / Efsane", "👁", Group.DISCOVER),

        CategorySpec("pansiyon", "Pansiyon", "🏡", Group.STAY),
        CategorySpec("apart", "Apart", "🏢", Group.STAY),
        CategorySpec("otel", "Otel", "🏨", Group.STAY),
        CategorySpec("kamp", "Kamp", "⛺", Group.STAY)
    )

    fun byKey(key: String) = all.first { it.key == key }
    fun forGroup(group: Group) = all.filter { it.group == group }
}

data class RegionHit(
    val name: String,
    val subtype: String,
    val lat: Double,
    val lon: Double,
    val south: Double?,
    val west: Double?,
    val north: Double?,
    val east: Double?
)

data class PlaceItem(
    val name: String,
    val categoryKey: String,
    val lat: Double,
    val lon: Double,
    val locality: String,
    val region: String,
    val address: String,
    val detail: String,
    val source: String,
    val confidence: Double,
    val rankScore: Double,
    val curated: Boolean,
    val matchNote: String,
    val routeQuery: String
)

object TextNorm {
    fun norm(s: String): String {
        val lower = s.lowercase(Locale.forLanguageTag("tr-TR"))
            .replace('ı', 'i').replace('ğ', 'g').replace('ü', 'u')
            .replace('ş', 's').replace('ö', 'o').replace('ç', 'c')
        return Normalizer.normalize(lower, Normalizer.Form.NFD)
            .replace("\\p{M}".toRegex(), "")
            .replace("[^a-z0-9]+".toRegex(), " ")
            .trim()
    }
}
