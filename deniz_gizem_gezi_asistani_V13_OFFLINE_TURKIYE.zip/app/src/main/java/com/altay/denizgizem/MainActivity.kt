package com.altay.denizgizem

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

private val Deep = Color(0xFF075E61)
private val Sea = Color(0xFF168F92)
private val Warm = Color(0xFFF4B942)
private val Bg = Color(0xFFF5F8F8)
private val Ink = Color(0xFF14282A)

@Composable
fun App() {
    val context = LocalContext.current
    var group by rememberSaveable { mutableStateOf(Group.FOOD) }
    var selectedKey by rememberSaveable { mutableStateOf("kofte") }
    var regionText by rememberSaveable { mutableStateOf("Tarsus") }
    var resolvedRegion by remember { mutableStateOf<RegionHit?>(null) }
    var results by remember { mutableStateOf<List<PlaceItem>>(emptyList()) }
    var searched by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var dataset by remember { mutableStateOf("Türkiye çevrimdışı veri") }

    LaunchedEffect(Unit) {
        Thread {
            val label = runCatching { OfflineDb.metadata(context) }.getOrDefault("Türkiye çevrimdışı veri")
            Handler(Looper.getMainLooper()).post { dataset = label }
        }.start()
    }

    fun runSearch() {
        if (regionText.isBlank() || loading) return
        val myRegion = regionText.trim()
        val myCategory = selectedKey
        loading = true
        searched = true
        results = emptyList()
        Thread {
            val pair = runCatching {
                OfflineDb.search(context, myRegion, myCategory, 30)
            }.getOrElse { null to emptyList() }

            Handler(Looper.getMainLooper()).post {
                if (regionText.trim() == myRegion && selectedKey == myCategory) {
                    resolvedRegion = pair.first
                    results = pair.second
                    loading = false
                }
            }
        }.start()
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Deep,
            secondary = Sea,
            tertiary = Warm,
            background = Bg,
            surface = Color.White,
            onPrimary = Color.White,
            onBackground = Ink,
            onSurface = Ink
        )
    ) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    Group.entries.forEach { g ->
                        NavigationBarItem(
                            selected = group == g,
                            onClick = {
                                group = g
                                selectedKey = Categories.forGroup(g).first().key
                                results = emptyList()
                                searched = false
                            },
                            icon = { Text(g.emoji, fontSize = 20.sp) },
                            label = { Text(g.title) }
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                item {
                    Hero(dataset)
                    SearchCard(
                        group = group,
                        selectedKey = selectedKey,
                        onCategory = {
                            selectedKey = it
                            results = emptyList()
                            searched = false
                        },
                        region = regionText,
                        onRegion = {
                            regionText = it
                            results = emptyList()
                            searched = false
                        },
                        loading = loading,
                        onSearch = { runSearch() }
                    )
                }

                if (searched) {
                    item {
                        StatusCard(
                            loading = loading,
                            resolvedRegion = resolvedRegion,
                            count = results.size,
                            categoryKey = selectedKey
                        )
                    }
                }

                if (!loading && searched && results.isEmpty()) {
                    item {
                        EmptyCard(
                            if (selectedKey == "gizem")
                                "Bu bölgede kaynaklı efsane/gizem kaydı bulunamadı. Bu bölüm uydurma hikâye üretmez."
                            else
                                "Bu bölgede bu kategori için güvenilir çevrimdışı kayıt bulunamadı. Yanlış yer göstermek yerine boş bırakıldı."
                        )
                    }
                }

                if (results.isNotEmpty()) {
                    item {
                        val food = Categories.byKey(selectedKey).group == Group.FOOD
                        SectionTitle(
                            if (food) "Yerel tavsiyeler" else "Bulunan yerler",
                            if (food)
                                "İlk kart doğrulanmış/kaynaklı kayıt varsa onu, yoksa en güçlü yerel eşleşmeyi gösterir."
                            else
                                "Arama telefondaki Türkiye veritabanında yapıldı; internet beklemez."
                        )
                    }
                    itemsIndexed(results, key = { _, x -> x.name + x.lat + x.lon }) { index, item ->
                        PlaceCard(index, item, selectedKey)
                    }
                }
            }
        }
    }
}

@Composable
private fun Hero(dataset: String) {
    Box(
        Modifier
            .fillMaxWidth()
            .background(
                Brush.linearGradient(listOf(Deep, Sea)),
                RoundedCornerShape(bottomStart = 30.dp, bottomEnd = 30.dp)
            )
            .padding(horizontal = 20.dp, vertical = 24.dp)
    ) {
        Column {
            Text("DENİZ GİZEM", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
            Text("V13 • OFFLINE TÜRKİYE", color = Color.White.copy(.94f), fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(
                "İl veya ilçe yaz. Arama internette değil, telefondaki Türkiye veritabanında yapılır.",
                color = Color.White.copy(.84f),
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(6.dp))
            Text(dataset, color = Color.White.copy(.70f), style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun SearchCard(
    group: Group,
    selectedKey: String,
    onCategory: (String) -> Unit,
    region: String,
    onRegion: (String) -> Unit,
    loading: Boolean,
    onSearch: () -> Unit
) {
    Card(
        Modifier.fillMaxWidth().padding(16.dp),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(3.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("${group.emoji} ${group.title}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))

            OutlinedTextField(
                value = region,
                onValueChange = onRegion,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("İl / İlçe") },
                placeholder = { Text("Tarsus, Bodrum, Bursa…") },
                shape = RoundedCornerShape(16.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onSearch() })
            )

            Spacer(Modifier.height(12.dp))
            Categories.forGroup(group).chunked(2).forEach { row ->
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    row.forEach { c ->
                        FilterChip(
                            selected = selectedKey == c.key,
                            onClick = { onCategory(c.key) },
                            label = { Text("${c.emoji} ${c.title}") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
                Spacer(Modifier.height(6.dp))
            }

            Button(
                onClick = onSearch,
                enabled = !loading && region.isNotBlank(),
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                if (loading) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                    Spacer(Modifier.width(10.dp))
                    Text("ARANIYOR…")
                } else {
                    Text("⚡ OFFLINE ARA", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun StatusCard(
    loading: Boolean,
    resolvedRegion: RegionHit?,
    count: Int,
    categoryKey: String
) {
    val text = when {
        loading -> "Telefondaki veritabanı aranıyor…"
        resolvedRegion != null -> "✅ ${resolvedRegion.name} • $count sonuç"
        count > 0 -> "✅ Metin eşleşmesiyle $count sonuç"
        else -> "Bölge/veri eşleşmesi bulunamadı"
    }
    Surface(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp),
        shape = RoundedCornerShape(16.dp),
        color = if (count > 0) Color(0xFFE7F5F3) else Color(0xFFFFF5DE)
    ) {
        Text(text, Modifier.padding(14.dp), style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Color(0xFF607779))
    }
}

@Composable
private fun PlaceCard(index: Int, item: PlaceItem, selectedKey: String) {
    val context = LocalContext.current
    val food = Categories.byKey(selectedKey).group == Group.FOOD

    Card(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 7.dp),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (index == 0 && food) Color(0xFFFFFBEE) else Color.White
        ),
        elevation = CardDefaults.cardElevation(if (index == 0) 3.dp else 1.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            if (index == 0 && food) {
                Text(
                    if (item.curated) "⭐ KAYNAKLI / KÖKLÜ TAVSİYE" else "⭐ ÖNE ÇIKAN YEREL TAVSİYE",
                    color = Deep,
                    fontWeight = FontWeight.Black,
                    style = MaterialTheme.typography.labelLarge
                )
                Spacer(Modifier.height(6.dp))
            }

            Text(item.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

            val loc = listOf(item.locality, item.region).filter { it.isNotBlank() }.distinct().joinToString(", ")
            if (loc.isNotBlank()) {
                Text(loc, style = MaterialTheme.typography.bodySmall, color = Color(0xFF597173))
            }

            if (item.address.isNotBlank()) {
                Spacer(Modifier.height(5.dp))
                Text("📍 ${item.address}", style = MaterialTheme.typography.bodySmall)
            }

            if (item.detail.isNotBlank()) {
                Spacer(Modifier.height(9.dp))
                val prefix = if (selectedKey == "gizem") "📖 KISA ÖZET\n" else ""
                Text(prefix + item.detail, style = MaterialTheme.typography.bodyMedium)
            }

            if (item.matchNote.isNotBlank()) {
                Spacer(Modifier.height(7.dp))
                Text(item.matchNote, color = Deep, style = MaterialTheme.typography.labelMedium)
            }

            if (item.source.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text("Kaynak: ${item.source}", color = Color(0xFF6D8587), style = MaterialTheme.typography.labelSmall)
            }

            Spacer(Modifier.height(12.dp))
            FilledTonalButton(
                onClick = {
                    val q = item.routeQuery.ifBlank {
                        listOf(item.name, item.locality, item.region).filter { it.isNotBlank() }.joinToString(" ")
                    }
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=${Uri.encode(q)}"))
                    context.startActivity(Intent.createChooser(intent, "Yol tarifi"))
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("🧭 YOL TARİFİ")
            }
        }
    }
}

@Composable
private fun EmptyCard(text: String) {
    Surface(
        Modifier.fillMaxWidth().padding(16.dp),
        shape = RoundedCornerShape(20.dp),
        color = Color.White
    ) {
        Text(text, Modifier.padding(18.dp))
    }
}
