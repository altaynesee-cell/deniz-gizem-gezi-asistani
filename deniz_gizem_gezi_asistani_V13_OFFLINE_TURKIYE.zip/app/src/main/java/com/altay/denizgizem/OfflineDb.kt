package com.altay.denizgizem

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import java.io.File
import kotlin.math.*

object OfflineDb {
    private const val ASSET_DB = "turkey_poi.sqlite"
    private const val DB_VERSION_MARKER = "v13"

    private fun dbFile(context: Context): File =
        File(context.filesDir, "turkey_poi_v13.sqlite")

    @Synchronized
    private fun ensureDb(context: Context): File {
        val out = dbFile(context)
        val marker = File(context.filesDir, "turkey_poi_$DB_VERSION_MARKER.marker")
        if (out.exists() && marker.exists()) return out

        if (out.exists()) out.delete()
        context.assets.open(ASSET_DB).use { input ->
            out.outputStream().use { output -> input.copyTo(output) }
        }
        marker.writeText("ok")
        return out
    }

    private fun open(context: Context): SQLiteDatabase =
        SQLiteDatabase.openDatabase(
            ensureDb(context).absolutePath,
            null,
            SQLiteDatabase.OPEN_READONLY
        )

    fun metadata(context: Context): String {
        open(context).use { db ->
            db.rawQuery(
                "SELECT value FROM meta WHERE key='dataset_label' LIMIT 1",
                null
            ).use { c ->
                return if (c.moveToFirst()) c.getString(0) else "Türkiye çevrimdışı veri"
            }
        }
    }

    fun findRegion(context: Context, raw: String): RegionHit? {
        val q = TextNorm.norm(raw)
        if (q.isBlank()) return null

        open(context).use { db ->
            val sql = """
                SELECT name, subtype, lat, lon, south, west, north, east
                FROM regions
                WHERE name_norm = ?
                ORDER BY CASE subtype
                    WHEN 'region' THEN 0
                    WHEN 'county' THEN 1
                    WHEN 'localadmin' THEN 2
                    WHEN 'locality' THEN 3
                    ELSE 9 END
                LIMIT 1
            """.trimIndent()
            db.rawQuery(sql, arrayOf(q)).use { c ->
                if (c.moveToFirst()) return c.toRegionHit()
            }

            // Yazım küçük farklarında en yakın ada düş.
            db.rawQuery(
                """
                SELECT name, subtype, lat, lon, south, west, north, east
                FROM regions
                WHERE name_norm LIKE ?
                ORDER BY length(name_norm), CASE subtype
                    WHEN 'region' THEN 0 ELSE 1 END
                LIMIT 1
                """.trimIndent(),
                arrayOf("%$q%")
            ).use { c ->
                if (c.moveToFirst()) return c.toRegionHit()
            }
        }
        return null
    }

    fun search(
        context: Context,
        rawRegion: String,
        categoryKey: String,
        limit: Int = 30
    ): Pair<RegionHit?, List<PlaceItem>> {
        val region = findRegion(context, rawRegion)
        val regionNorm = TextNorm.norm(rawRegion)

        open(context).use { db ->
            val args = mutableListOf<String>()
            val where = StringBuilder("category_key = ?")
            args += categoryKey

            if (region != null && region.south != null && region.west != null &&
                region.north != null && region.east != null) {
                where.append(" AND lat BETWEEN ? AND ? AND lon BETWEEN ? AND ?")
                args += region.south.toString()
                args += region.north.toString()
                args += region.west.toString()
                args += region.east.toString()
            } else if (region != null) {
                // Geometri yoksa merkez çevresinde güvenli yarıçap.
                val dLat = 0.42
                val dLon = 0.55
                where.append(" AND lat BETWEEN ? AND ? AND lon BETWEEN ? AND ?")
                args += (region.lat - dLat).toString()
                args += (region.lat + dLat).toString()
                args += (region.lon - dLon).toString()
                args += (region.lon + dLon).toString()
            } else {
                // Bölge tablosunda bulunmazsa adres alanlarından Türkiye genelinde metin eşleşmesi.
                where.append(" AND (locality_norm = ? OR region_norm = ? OR locality_norm LIKE ?)")
                args += regionNorm
                args += regionNorm
                args += "%$regionNorm%"
            }

            val sql = """
                SELECT name, category_key, lat, lon, locality, region, address,
                       detail, source, confidence, rank_score, curated, match_note, route_query
                FROM poi
                WHERE $where
                ORDER BY curated DESC,
                         CASE WHEN locality_norm = ? THEN 1 ELSE 0 END DESC,
                         rank_score DESC,
                         confidence DESC,
                         name COLLATE NOCASE
                LIMIT ?
            """.trimIndent()
            args += regionNorm
            args += limit.toString()

            val out = mutableListOf<PlaceItem>()
            db.rawQuery(sql, args.toTypedArray()).use { c ->
                while (c.moveToNext()) {
                    out += PlaceItem(
                        name = c.getString(0),
                        categoryKey = c.getString(1),
                        lat = c.getDouble(2),
                        lon = c.getDouble(3),
                        locality = c.getString(4).orEmpty(),
                        region = c.getString(5).orEmpty(),
                        address = c.getString(6).orEmpty(),
                        detail = c.getString(7).orEmpty(),
                        source = c.getString(8).orEmpty(),
                        confidence = c.getDouble(9),
                        rankScore = c.getDouble(10),
                        curated = c.getInt(11) == 1,
                        matchNote = c.getString(12).orEmpty(),
                        routeQuery = c.getString(13).orEmpty()
                    )
                }
            }
            return region to dedupe(out)
        }
    }

    private fun android.database.Cursor.toRegionHit() = RegionHit(
        name = getString(0),
        subtype = getString(1),
        lat = getDouble(2),
        lon = getDouble(3),
        south = if (isNull(4)) null else getDouble(4),
        west = if (isNull(5)) null else getDouble(5),
        north = if (isNull(6)) null else getDouble(6),
        east = if (isNull(7)) null else getDouble(7)
    )

    private fun dedupe(items: List<PlaceItem>): List<PlaceItem> {
        val seen = mutableSetOf<String>()
        return items.filter {
            val k = TextNorm.norm(it.name) + "|" +
                (it.lat * 1000).roundToInt() + "|" + (it.lon * 1000).roundToInt()
            seen.add(k)
        }
    }
}
