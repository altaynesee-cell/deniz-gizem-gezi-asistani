#!/usr/bin/env python3
"""
V13 Türkiye çevrimdışı POI veritabanı oluşturucu.

Kaynaklar:
- Overture Maps 2026-07-22.0 Places + Divisions (sabitlenmiş sürüm)
- Geofabrik Turkey OpenStreetMap PBF (workflow tarafından indirilir)
- İsteğe bağlı Türkçe Wikipedia kısa özet zenginleştirmesi

Amaç: uygulama çalışma anında hiçbir arama sunucusuna ihtiyaç duymasın.
"""
from __future__ import annotations
import argparse, csv, json, math, os, re, sqlite3, subprocess, sys, tempfile, unicodedata, urllib.parse, urllib.request
from pathlib import Path

OVERTURE_RELEASE = "2026-07-22.0"
OVERTURE_ROOT = f"s3://overturemaps-us-west-2/release/{OVERTURE_RELEASE}"
TURKEY_BBOX = (25.45, 35.70, 45.05, 42.25)

def norm(s: str) -> str:
    s = (s or "").lower().replace("ı","i").replace("ğ","g").replace("ü","u").replace("ş","s").replace("ö","o").replace("ç","c")
    s = unicodedata.normalize("NFD", s)
    s = "".join(ch for ch in s if unicodedata.category(ch) != "Mn")
    return re.sub(r"[^a-z0-9]+", " ", s).strip()

def schema(c):
    c.executescript("""
    PRAGMA journal_mode=OFF;
    PRAGMA synchronous=OFF;
    PRAGMA temp_store=MEMORY;
    CREATE TABLE meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE TABLE regions(
        name TEXT NOT NULL,
        name_norm TEXT NOT NULL,
        subtype TEXT NOT NULL,
        lat REAL NOT NULL,
        lon REAL NOT NULL,
        south REAL, west REAL, north REAL, east REAL,
        parent_region TEXT DEFAULT ''
    );
    CREATE INDEX idx_regions_norm ON regions(name_norm);

    CREATE TABLE poi(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        source_id TEXT DEFAULT '',
        source TEXT NOT NULL,
        name TEXT NOT NULL,
        name_norm TEXT NOT NULL,
        category_key TEXT NOT NULL,
        lat REAL NOT NULL,
        lon REAL NOT NULL,
        locality TEXT DEFAULT '',
        locality_norm TEXT DEFAULT '',
        region TEXT DEFAULT '',
        region_norm TEXT DEFAULT '',
        address TEXT DEFAULT '',
        detail TEXT DEFAULT '',
        confidence REAL DEFAULT 0,
        rank_score REAL DEFAULT 0,
        curated INTEGER DEFAULT 0,
        match_note TEXT DEFAULT '',
        route_query TEXT DEFAULT '',
        wikipedia TEXT DEFAULT ''
    );
    CREATE UNIQUE INDEX uq_poi ON poi(category_key, name_norm, ROUND(lat,4), ROUND(lon,4));
    CREATE INDEX idx_poi_cat_geo ON poi(category_key, lat, lon);
    CREATE INDEX idx_poi_locality ON poi(locality_norm, category_key);
    CREATE INDEX idx_poi_region ON poi(region_norm, category_key);
    CREATE INDEX idx_poi_name ON poi(name_norm);
    """)

FOOD_KEYS = {"ciger","kofte","kebap","sulu","tavuk","esnaf","balik","kahvalti"}

def classify(name, taxonomy_primary="", hierarchy="", old_category="", tags=None):
    tags = tags or {}
    n = norm(name)
    tax = norm(" ".join([taxonomy_primary, hierarchy, old_category]))
    text = f"{n} {tax}"
    out = {}

    def put(k, note, boost=0):
        out[k] = (note, boost)

    # Yemek: isim + taksonomi. Generic restoranı zorla belirli yemeğe sokmuyoruz.
    if any(x in text for x in ("ciger", "arnavut ciger", "liver")):
        put("ciger","Ciğer eşleşmesi",22)
    if any(x in text for x in ("kofte", "kofteci", "meatball")):
        put("kofte","Köfte eşleşmesi",24)
    if any(x in text for x in ("kebap", "kebab", "ocakbasi", "grill kebab")):
        put("kebap","Kebap eşleşmesi",22)
    if any(x in text for x in ("ev yemek", "sulu yemek", "tabldot", "home cooking")):
        put("sulu","Sulu/günlük yemek eşleşmesi",18)
    if any(x in text for x in ("esnaf lokanta", "esnaf", "lokanta", "sofra")):
        put("esnaf","Esnaf/lokanta eşleşmesi",16)
    if any(x in text for x in ("tavuk", "pilic", "chicken")):
        put("tavuk","Tavuk eşleşmesi",20)
    if any(x in text for x in ("balik", "seafood", "fish restaurant", "fish_restaurant")):
        put("balik","Balık/deniz ürünü eşleşmesi",20)
    if any(x in text for x in ("kahvalti", "breakfast", "serpme")):
        put("kahvalti","Kahvaltı eşleşmesi",20)

    # Deniz / doğa.
    natural = norm(tags.get("natural",""))
    tourism = norm(tags.get("tourism",""))
    leisure = norm(tags.get("leisure",""))
    surface = norm(tags.get("surface",""))
    desc = norm(" ".join([tags.get("description",""), tags.get("note",""), tags.get("seabed",""), tags.get("shallow","")]))

    if "beach" in text or natural == "beach" or leisure in ("beach","beach resort"):
        put("plaj","Gerçek plaj/kumsal türü",18)
        sandy = ("sand" in surface or any(x in n for x in ("kum","kumsal")) or "sand" in desc)
        shallow = any(x in desc for x in ("sig","shallow","az derin")) or norm(tags.get("shallow","")) in ("yes","true")
        if sandy and shallow:
            put("kum","Sığ + kum bilgisi doğrulandı",28)
        elif sandy:
            # Kullanıcı boş ekran görmesin ama iddiayı da uydurmayalım.
            put("kum","Kumlu • sığlık açık veride doğrulanmadı",8)

    if "bay" in text or natural == "bay" or any(x in n for x in ("koyu","koy")):
        put("koy","Koy eşleşmesi",18)

    if natural in ("cave entrance","cave") or "cave" in text or "magara" in n:
        put("magara","Gerçek mağara/doğal oluşum eşleşmesi",22)

    # Keşfet.
    hist = norm(tags.get("historic",""))
    if any(x in text for x in ("archaeological", "archeological", "ruins", "ancient city", "ancient_site")) or hist in ("archaeological site","ruins"):
        put("antik","Arkeolojik/antik alan eşleşmesi",24)
    if any(x in text for x in ("castle","fortress","fort","city wall","city gate")) or hist in ("castle","fort","city gate","citywalls"):
        put("kale","Kale/hisar/sur eşleşmesi",24)
    if "museum" in text or tourism == "museum":
        put("muze","Müze eşleşmesi",20)
    if hist or any(x in text for x in ("historic site","monument","memorial","archaeological","castle","ruins")):
        put("tarihi","Tarihi yer eşleşmesi",12)

    # Konak.
    if any(x in text for x in ("guest house","guest_house","pension","pansiyon","hostel","bed and breakfast")):
        put("pansiyon","Pansiyon/konukevi eşleşmesi",18)
    if any(x in text for x in ("apartment hotel","serviced apartment","aparthotel","apart hotel","apartment")):
        put("apart","Apart eşleşmesi",18)
    if any(x in text for x in ("hotel","motel","resort")):
        put("otel","Otel eşleşmesi",16)
    if any(x in text for x in ("campground","camp site","camp_site","caravan site","caravan_site")):
        put("kamp","Kamp eşleşmesi",18)

    return out

def install_duckdb():
    try:
        import duckdb
        return duckdb
    except Exception as e:
        raise RuntimeError("duckdb Python paketi gerekli") from e

def export_overture(tmp: Path):
    duckdb = install_duckdb()
    con = duckdb.connect()
    con.execute("INSTALL spatial; LOAD spatial; INSTALL httpfs; LOAD httpfs; SET s3_region='us-west-2';")

    regions = tmp / "regions.tsv"
    places = tmp / "places.tsv"

    # Türkiye'nin idarî alanları: uygulama il/ilçe adını burada çözüyor.
    con.execute(f"""
    COPY (
      SELECT
        names.primary AS name,
        subtype,
        COALESCE(region,'') AS parent_region,
        ST_Y(ST_PointOnSurface(geometry)) AS lat,
        ST_X(ST_PointOnSurface(geometry)) AS lon,
        bbox.ymin AS south, bbox.xmin AS west, bbox.ymax AS north, bbox.xmax AS east
      FROM read_parquet('{OVERTURE_ROOT}/theme=divisions/type=division_area/*',
             filename=true, hive_partitioning=1)
      WHERE country='TR'
        AND subtype IN ('region','county','localadmin','locality')
        AND names.primary IS NOT NULL
    ) TO '{regions.as_posix()}' (HEADER, DELIMITER '\t');
    """)

    # Türkiye ülke poligonu ile gerçek mekânları kesiyoruz; komşu ülkeler bbox nedeniyle karışmıyor.
    con.execute(f"""
    COPY (
      WITH tr AS (
        SELECT geometry AS geom
        FROM read_parquet('{OVERTURE_ROOT}/theme=divisions/type=division_area/*',
             filename=true, hive_partitioning=1)
        WHERE country='TR' AND subtype='country'
        LIMIT 1
      )
      SELECT
        p.id,
        p.names.primary AS name,
        COALESCE(p.basic_category,'') AS basic_category,
        COALESCE(p.taxonomy.primary,'') AS taxonomy_primary,
        COALESCE(array_to_string(p.taxonomy.hierarchy,'|'),'') AS hierarchy,
        COALESCE(p.categories.primary,'') AS old_category,
        COALESCE(p.confidence,0.0) AS confidence,
        COALESCE(p.addresses[1].locality,'') AS locality,
        COALESCE(p.addresses[1].region,'') AS region,
        COALESCE(p.addresses[1].freeform,'') AS address,
        COALESCE(p.websites[1],'') AS website,
        ST_Y(p.geometry) AS lat,
        ST_X(p.geometry) AS lon
      FROM read_parquet('{OVERTURE_ROOT}/theme=places/type=place/*',
             filename=true, hive_partitioning=1) p, tr
      WHERE p.names.primary IS NOT NULL
        AND length(trim(p.names.primary)) >= 3
        AND COALESCE(p.confidence,0.0) >= 0.70
        AND p.bbox.xmin BETWEEN {TURKEY_BBOX[0]} AND {TURKEY_BBOX[2]}
        AND p.bbox.ymin BETWEEN {TURKEY_BBOX[1]} AND {TURKEY_BBOX[3]}
        AND ST_Within(p.geometry, tr.geom)
        AND (
          list_contains(p.taxonomy.hierarchy,'food_and_drink')
          OR list_contains(p.taxonomy.hierarchy,'lodging')
          OR list_contains(p.taxonomy.hierarchy,'cultural_and_historic')
          OR list_contains(p.taxonomy.hierarchy,'arts_and_entertainment')
          OR list_contains(p.taxonomy.hierarchy,'sports_and_recreation')
          OR list_contains(p.taxonomy.hierarchy,'geographic_entities')
          OR p.basic_category IN ('restaurant','cafe','hotel','museum','castle','beach')
        )
    ) TO '{places.as_posix()}' (HEADER, DELIMITER '\t');
    """)
    con.close()
    return regions, places

def run_osmium(osm_pbf: Path, tmp: Path):
    relevant = tmp / "relevant.osm.pbf"
    geo = tmp / "relevant.geojsonseq"
    filters = [
        "nwr/amenity=restaurant","nwr/amenity=fast_food","nwr/amenity=cafe",
        "nwr/natural=beach","nwr/natural=bay","nwr/natural=cave_entrance","nwr/natural=cave",
        "nwr/leisure=beach","nwr/leisure=beach_resort",
        "nwr/historic",
        "nwr/tourism=museum","nwr/tourism=attraction","nwr/tourism=hotel","nwr/tourism=motel",
        "nwr/tourism=resort","nwr/tourism=guest_house","nwr/tourism=hostel",
        "nwr/tourism=apartment","nwr/tourism=camp_site","nwr/tourism=caravan_site",
    ]
    subprocess.run(["osmium","tags-filter",str(osm_pbf),*filters,"-o",str(relevant),"--overwrite"],
                   check=True)
    subprocess.run(["osmium","export",str(relevant),"-f","geojsonseq","-o",str(geo),"--overwrite"],
                   check=True)
    return geo

def geometry_point(geom):
    try:
        from shapely.geometry import shape
        g = shape(geom)
        p = g.representative_point()
        return float(p.y), float(p.x)
    except Exception:
        return None

def insert_poi(db, row):
    try:
        db.execute("""
        INSERT OR IGNORE INTO poi(
          source_id,source,name,name_norm,category_key,lat,lon,
          locality,locality_norm,region,region_norm,address,detail,
          confidence,rank_score,curated,match_note,route_query,wikipedia
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, row)
    except sqlite3.IntegrityError:
        pass

def add_overture(db, places_tsv):
    count=0
    with places_tsv.open("r",encoding="utf-8",newline="") as f:
        for r in csv.DictReader(f, delimiter="\t"):
            name=(r.get("name") or "").strip()
            if len(norm(name)) < 3: continue
            conf=float(r.get("confidence") or 0)
            cats=classify(name, r.get("taxonomy_primary",""), r.get("hierarchy",""), r.get("old_category",""))
            if not cats: continue
            lat=float(r["lat"]); lon=float(r["lon"])
            locality=(r.get("locality") or "").strip()
            region=(r.get("region") or "").strip()
            address=(r.get("address") or "").strip()
            web=(r.get("website") or "").strip()
            for key,(note,boost) in cats.items():
                score=conf*100 + boost + (5 if web else 0)
                insert_poi(db, (
                    r.get("id",""),"Overture Maps",name,norm(name),key,lat,lon,
                    locality,norm(locality),region,norm(region),address,"",
                    conf,score,0,note,f"{name} {locality} {region}",""
                ))
                count+=1
    return count

def add_regions(db, regions_tsv):
    rows=0
    with regions_tsv.open("r",encoding="utf-8",newline="") as f:
        for r in csv.DictReader(f, delimiter="\t"):
            name=(r.get("name") or "").strip()
            if not name: continue
            db.execute("INSERT INTO regions VALUES(?,?,?,?,?,?,?,?,?,?)",(
                name,norm(name),r.get("subtype",""),
                float(r["lat"]),float(r["lon"]),
                float(r["south"]) if r.get("south") else None,
                float(r["west"]) if r.get("west") else None,
                float(r["north"]) if r.get("north") else None,
                float(r["east"]) if r.get("east") else None,
                r.get("parent_region","") or ""
            ))
            rows+=1
    return rows

def add_osm(db, geojsonseq):
    count=0
    wikipedia_titles=set()
    with geojsonseq.open("r",encoding="utf-8",errors="replace") as f:
        for line in f:
            line=line.strip().lstrip("\x1e")
            if not line: continue
            try:
                feat=json.loads(line)
            except Exception:
                continue
            props=feat.get("properties") or {}
            name=(props.get("name") or "").strip()
            if len(norm(name)) < 3: continue
            pt=geometry_point(feat.get("geometry"))
            if not pt: continue
            lat,lon=pt
            if not (TURKEY_BBOX[1] <= lat <= TURKEY_BBOX[3] and TURKEY_BBOX[0] <= lon <= TURKEY_BBOX[2]):
                continue

            tags={str(k):str(v) for k,v in props.items() if v is not None}
            taxonomy=" ".join([
                tags.get("amenity",""),tags.get("natural",""),tags.get("historic",""),
                tags.get("tourism",""),tags.get("leisure","")
            ])
            cats=classify(name,taxonomy,taxonomy,"",tags)
            if not cats: continue
            locality=tags.get("addr:city","") or tags.get("addr:district","") or tags.get("is_in:city","")
            region=tags.get("addr:province","") or tags.get("is_in:state","")
            address=" ".join(x for x in [tags.get("addr:street",""),tags.get("addr:housenumber","")] if x).strip()
            wiki=tags.get("wikipedia","")
            if wiki.startswith("tr:"):
                wikipedia_titles.add(wiki[3:].strip())

            source_id=tags.get("@id","") or tags.get("id","")
            for key,(note,boost) in cats.items():
                score=72 + boost + (15 if wiki else 0) + (5 if tags.get("website") else 0)
                insert_poi(db, (
                    source_id,"OpenStreetMap",name,norm(name),key,lat,lon,
                    locality,norm(locality),region,norm(region),address,
                    tags.get("description",""),0.80,score,0,note,
                    f"{name} {locality} {region}",wiki
                ))
                count+=1
    return count,wikipedia_titles

def ensure_critical_regions(db):
    critical=[
      ("Tarsus","localadmin",36.9177,34.8920,36.70,34.65,37.15,35.20,"Mersin"),
      ("Bodrum","localadmin",37.0344,27.4305,36.90,27.05,37.25,27.70,"Muğla"),
      ("Bursa","region",40.195,29.060,39.50,27.85,40.75,30.10,""),
    ]
    for name,sub,lat,lon,s,w,n,e,parent in critical:
        exists=db.execute("SELECT 1 FROM regions WHERE name_norm=? LIMIT 1",(norm(name),)).fetchone()
        if not exists:
            db.execute("INSERT INTO regions VALUES(?,?,?,?,?,?,?,?,?,?)",
                       (name,norm(name),sub,lat,lon,s,w,n,e,parent))

def seed_curated(db):
    # Küçük kritik çekirdek: tam veri build'ine destek olur, yerine geçmez.
    seed_path=Path(__file__).resolve().parent/"create_seed_db.py"
    tmp=Path(tempfile.mkdtemp())/"seed.sqlite"
    # Aynı bilgileri doğrudan burada kısa listeyle ekliyoruz.
    rows=[
      ("seed-tarsus-gozlukule","T.C. Kültür ve Turizm Bakanlığı","Gözlükule Höyüğü","antik",36.918,34.895,"Tarsus","Mersin","Tarsus merkez",
       "Tarsus merkezindeki höyükte arkeolojik yerleşim çok erken dönemlere uzanır.",.99,1100,1,"Arkeolojik alan","Gözlükule Höyüğü Tarsus",""),
      ("seed-tarsus-donuktas","T.C. Kültür ve Turizm Bakanlığı","Donuktaş Roma Tapınağı","antik",36.920,34.900,"Tarsus","Mersin","Tarsus",
       "Roma dönemine ait büyük anıtsal tapınak kalıntısı.",.99,1080,1,"Antik yapı / arkeoloji","Donuktaş Tarsus",""),
      ("seed-tarsus-roma","T.C. Kültür ve Turizm Bakanlığı","Tarsus Roma Yolu","antik",36.916,34.895,"Tarsus","Mersin","Tarsus merkez",
       "Antik Tarsus kent dokusundan günümüze ulaşan Roma yolu kalıntısı.",.99,1070,1,"Roma dönemi","Tarsus Roma Yolu",""),
      ("seed-tarsus-kofte","Güncel işletme kaydı","Köfteci","kofte",36.918,34.893,"Tarsus","Mersin","Şehitkerim, 3429. Sk. No:6, Tarsus/Mersin",
       "Köfte odaklı yerel işletme.",.99,1120,1,"⭐ Yerel köfteci","Köfteci Şehitkerim 3429 Sokak Tarsus",""),
      ("seed-bodrum-ciger","Yerel kaynaklarla doğrulanmış kayıt","Ciğerci Yasin","ciger",37.038,27.424,"Bodrum","Muğla","Yokuşbaşı, Bodrum",
       "Bodrum'da ciğer için yerel ve salaş adreslerden.",.99,1120,1,"⭐ Köklü/yerel tavsiye","Ciğerci Yasin Bodrum",""),
      ("seed-tarsus-eshab","Mersin kültür-turizm kaynakları","Eshab-ı Kehf / Yedi Uyurlar","gizem",37.017,34.895,"Tarsus","Mersin","Dedeler / Tarsus",
       "Rivayete göre inançlarını korumak için bir mağaraya sığınan gençler uzun yıllar uyur ve çok sonra uyanırlar. Tarsus'taki mağara bu anlatıyla ilişkilendirilen ziyaret yerlerinden biridir.",
       .99,1110,1,"Kaynaklı kısa efsane özeti","Eshab-ı Kehf Mağarası Tarsus","")
    ]
    for sid,src,name,key,lat,lon,loc,reg,addr,detail,conf,score,cur,note,route,wiki in rows:
        insert_poi(db,(sid,src,name,norm(name),key,lat,lon,loc,norm(loc),reg,norm(reg),addr,detail,conf,score,cur,note,route,wiki))

def first_sentences(text, max_chars=430):
    text=re.sub(r"\s+"," ",text or "").strip()
    parts=re.split(r"(?<=[.!?])\s+",text)
    out=" ".join(parts[:2]).strip()
    return out[:max_chars].rstrip()

def wikipedia_enrich(db, titles):
    # Sadece efsane/mit/rivayet işareti taşıyan özetleri gizem kategorisine ekler.
    titles=sorted(t for t in titles if t)[:600]
    keywords=("efsane","rivayet","mitoloji","mitolojik","söylence","mitos","destan")
    added=0
    for i in range(0,len(titles),40):
        batch=titles[i:i+40]
        params={
            "action":"query","format":"json","prop":"extracts","exintro":"1","explaintext":"1",
            "redirects":"1","titles":"|".join(batch)
        }
        url="https://tr.wikipedia.org/w/api.php?"+urllib.parse.urlencode(params)
        req=urllib.request.Request(url,headers={"User-Agent":"DenizGizemV13DataBuilder/1.0"})
        try:
            with urllib.request.urlopen(req,timeout=20) as r:
                payload=json.load(r)
        except Exception:
            continue
        pages=(payload.get("query") or {}).get("pages") or {}
        for page in pages.values():
            title=page.get("title","")
            extract=page.get("extract","") or ""
            nx=norm(extract)
            if not any(k in nx for k in keywords): continue
            # Aynı wikipedia etiketine sahip mevcut tarihi/doğal POI'yi bul.
            wiki="tr:"+title
            cur=db.execute("""
              SELECT source_id,name,lat,lon,locality,region,address,rank_score,route_query
              FROM poi WHERE wikipedia=? ORDER BY rank_score DESC LIMIT 1
            """,(wiki,)).fetchone()
            if not cur: continue
            sid,name,lat,lon,loc,reg,addr,score,route=cur
            insert_poi(db,(sid,"OpenStreetMap + Türkçe Wikipedia",name,norm(name),"gizem",lat,lon,
                           loc,norm(loc),reg,norm(reg),addr,first_sentences(extract),
                           .85,float(score)+20,0,"Wikipedia özetinde efsane/mit/rivayet bağlantısı",route,wiki))
            added+=1
    return added

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--osm-pbf",required=True)
    ap.add_argument("--output",required=True)
    ap.add_argument("--wikipedia",action="store_true")
    args=ap.parse_args()

    out=Path(args.output)
    osm=Path(args.osm_pbf)
    if not osm.exists() or osm.stat().st_size < 50_000_000:
        raise SystemExit("OSM PBF eksik veya beklenenden küçük.")

    with tempfile.TemporaryDirectory(prefix="v13data_") as td:
        tmp=Path(td)
        regions_tsv,places_tsv=export_overture(tmp)
        geo=run_osmium(osm,tmp)

        if out.exists(): out.unlink()
        db=sqlite3.connect(out)
        schema(db)
        db.executemany("INSERT INTO meta VALUES(?,?)",[
            ("dataset_label","V13 Offline Türkiye • Overture 2026-07-22 + OpenStreetMap Türkiye"),
            ("dataset_version","v13-full-2026-07"),
            ("overture_release",OVERTURE_RELEASE),
            ("osm_source","Geofabrik Turkey"),
        ])
        region_count=add_regions(db,regions_tsv)
        ensure_critical_regions(db)
        overture_count=add_overture(db,places_tsv)
        osm_count,wikis=add_osm(db,geo)
        seed_curated(db)
        wiki_count=wikipedia_enrich(db,wikis) if args.wikipedia else 0

        db.commit()
        db.execute("ANALYZE")
        db.execute("VACUUM")
        total=db.execute("SELECT count(*) FROM poi").fetchone()[0]
        cats=dict(db.execute("SELECT category_key,count(*) FROM poi GROUP BY category_key"))
        db.close()

        print(json.dumps({
            "regions":region_count,
            "overture_insert_attempts":overture_count,
            "osm_insert_attempts":osm_count,
            "wikipedia_gizem_added":wiki_count,
            "poi_rows":total,
            "categories":cats,
            "output_mb":round(out.stat().st_size/1024/1024,1),
        },ensure_ascii=False,indent=2))

if __name__=="__main__":
    main()
