import sqlite3, re, unicodedata
from pathlib import Path

OUT = Path(__file__).resolve().parents[1] / "app/src/main/assets/turkey_poi.sqlite"

def norm(s):
    s = s.lower().replace("ı","i").replace("ğ","g").replace("ü","u").replace("ş","s").replace("ö","o").replace("ç","c")
    s = unicodedata.normalize("NFD", s)
    s = "".join(ch for ch in s if unicodedata.category(ch) != "Mn")
    return re.sub(r"[^a-z0-9]+", " ", s).strip()

def schema(c):
    c.executescript("""
    PRAGMA journal_mode=OFF;
    PRAGMA synchronous=OFF;
    CREATE TABLE meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE TABLE regions(
        name TEXT NOT NULL,
        name_norm TEXT NOT NULL,
        subtype TEXT NOT NULL,
        lat REAL NOT NULL,
        lon REAL NOT NULL,
        south REAL, west REAL, north REAL, east REAL,
        parent_region TEXT DEFAULT ''
    );
    CREATE INDEX idx_regions_norm ON regions(name_norm);

    CREATE TABLE poi(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        source_id TEXT DEFAULT '',
        source TEXT NOT NULL,
        name TEXT NOT NULL,
        name_norm TEXT NOT NULL,
        category_key TEXT NOT NULL,
        lat REAL NOT NULL,
        lon REAL NOT NULL,
        locality TEXT DEFAULT '',
        locality_norm TEXT DEFAULT '',
        region TEXT DEFAULT '',
        region_norm TEXT DEFAULT '',
        address TEXT DEFAULT '',
        detail TEXT DEFAULT '',
        confidence REAL DEFAULT 0,
        rank_score REAL DEFAULT 0,
        curated INTEGER DEFAULT 0,
        match_note TEXT DEFAULT '',
        route_query TEXT DEFAULT '',
        wikipedia TEXT DEFAULT ''
    );
    CREATE INDEX idx_poi_cat_geo ON poi(category_key, lat, lon);
    CREATE INDEX idx_poi_locality ON poi(locality_norm, category_key);
    CREATE INDEX idx_poi_region ON poi(region_norm, category_key);
    CREATE INDEX idx_poi_name ON poi(name_norm);
    """)

def add_region(c, name, subtype, lat, lon, south, west, north, east, parent=""):
    c.execute("INSERT INTO regions VALUES(?,?,?,?,?,?,?,?,?,?)",
              (name,norm(name),subtype,lat,lon,south,west,north,east,parent))

def add(c, name, key, lat, lon, locality, region, address, detail, source,
        confidence=.99, rank=950, curated=1, note="", route=None):
    c.execute("""
      INSERT INTO poi(source_id,source,name,name_norm,category_key,lat,lon,
        locality,locality_norm,region,region_norm,address,detail,confidence,
        rank_score,curated,match_note,route_query,wikipedia)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, ("seed",source,name,norm(name),key,lat,lon,locality,norm(locality),
          region,norm(region),address,detail,confidence,rank,curated,note,
          route or f"{name} {locality} {region}",""))

def build():
    OUT.parent.mkdir(parents=True, exist_ok=True)
    if OUT.exists(): OUT.unlink()
    db=sqlite3.connect(OUT)
    schema(db)
    db.executemany("INSERT INTO meta VALUES(?,?)", [
        ("dataset_label","V13 seed • GitHub build tam Türkiye verisini oluşturacak"),
        ("dataset_version","seed-v13"),
        ("overture_release","2026-07-22.0"),
    ])

    # Seed bölge sınırları sadece kritik yerel testler için. Tam build bunları Overture divisions ile değiştirir.
    add_region(db,"Tarsus","localadmin",36.9177,34.8920,36.70,34.65,37.15,35.20,"Mersin")
    add_region(db,"Bodrum","localadmin",37.0344,27.4305,36.90,27.05,37.25,27.70,"Muğla")
    add_region(db,"Bursa","region",40.195,29.060,39.50,27.85,40.75,30.10,"")
    add_region(db,"Antalya","region",36.885,30.705,35.80,29.20,37.55,32.70,"")
    add_region(db,"İstanbul","region",41.015,28.980,40.75,27.95,41.60,29.95,"")
    add_region(db,"İzmir","region",38.420,27.140,37.80,26.20,39.45,28.60,"")

    # Tarsus kritik arkeoloji: "antik yok" hatası artık seed APK'da bile oluşmaz.
    add(db,"Gözlükule Höyüğü","antik",36.918,34.895,"Tarsus","Mersin","Tarsus merkez",
        "Tarsus merkezindeki höyükte arkeolojik yerleşim çok erken dönemlere uzanır.",
        "T.C. Kültür ve Turizm Bakanlığı", note="Arkeolojik alan")
    add(db,"Donuktaş Roma Tapınağı","antik",36.920,34.900,"Tarsus","Mersin","Tarsus",
        "Roma dönemine ait büyük anıtsal tapınak kalıntısı.",
        "T.C. Kültür ve Turizm Bakanlığı", rank=930, note="Antik yapı / arkeoloji")
    add(db,"Tarsus Roma Yolu","antik",36.916,34.895,"Tarsus","Mersin","Tarsus merkez",
        "Antik Tarsus kent dokusundan günümüze ulaşan Roma yolu kalıntısı.",
        "T.C. Kültür ve Turizm Bakanlığı", rank=920, note="Roma dönemi")
    add(db,"Donuktaş Roma Tapınağı","tarihi",36.920,34.900,"Tarsus","Mersin","Tarsus",
        "Roma dönemine ait anıtsal yapı kalıntısı.",
        "T.C. Kültür ve Turizm Bakanlığı", rank=930, note="Tarihi / arkeolojik")
    add(db,"Tarsus Roma Yolu","tarihi",36.916,34.895,"Tarsus","Mersin","Tarsus merkez",
        "Antik kent dokusundan korunmuş Roma yolu.",
        "T.C. Kültür ve Turizm Bakanlığı", rank=920, note="Roma dönemi")
    add(db,"Eshab-ı Kehf Mağarası","magara",37.017,34.895,"Tarsus","Mersin","Dedeler / Tarsus",
        "Yedi Uyurlar anlatısıyla ilişkilendirilen mağara ve ziyaret noktası.",
        "Mersin kültür-turizm kaynakları", rank=930, note="Gerçek mağara + kültürel anlatı")
    add(db,"Eshab-ı Kehf / Yedi Uyurlar","gizem",37.017,34.895,"Tarsus","Mersin","Dedeler / Tarsus",
        "Rivayete göre inançlarını korumak için bir mağaraya sığınan gençler uzun yıllar uyur ve çok sonra uyanırlar. Tarsus'taki mağara bu anlatıyla ilişkilendirilen ziyaret yerlerinden biridir.",
        "Mersin kültür-turizm kaynakları", rank=940, note="Kaynaklı kısa efsane özeti")

    # Tarsus yemek kritik seed. Tam Overture+OSM build daha çok işletme ekler.
    add(db,"Köfteci","kofte",36.918,34.893,"Tarsus","Mersin",
        "Şehitkerim, 3429. Sk. No:6, Tarsus/Mersin",
        "Köfte odaklı yerel işletme.",
        "Güncel işletme kaydı", rank=970, note="⭐ Yerel köfteci",
        route="Köfteci Şehitkerim 3429 Sokak Tarsus")
    add(db,"Kebapçı Eyüp","kebap",36.918,34.892,"Tarsus","Mersin",
        "Şehit Kerim Mah., Abdi İpekçi Cd. No:33, Tarsus",
        "Tarsus merkezde kebap odaklı yerel işletme.",
        "Güncel işletme kaydı", rank=960, note="⭐ Yerel kebap")
    add(db,"Bedii Usta Kebap Salonu","kebap",36.919,34.891,"Tarsus","Mersin",
        "Şehitkerim, 3415. Sk. No:1, Tarsus",
        "Tarsus'ta uzun süredir bilinen kebap seçeneklerinden.",
        "Güncel işletme kaydı", rank=950, note="Yerel kebap")
    add(db,"Gece Ciğercisi Tarsus","ciger",36.917,34.894,"Tarsus","Mersin",
        "Eski Ömerli, İstiklal Cd., Tarsus",
        "Ciğer/kebap odaklı yerel işletme.",
        "Güncel işletme kaydı", rank=955, note="⭐ Yerel ciğer")
    add(db,"Kent Lokantası","esnaf",36.918,34.895,"Tarsus","Mersin",
        "Kızılmurat, 2707. Sk. No:1/A, Tarsus",
        "Yerel lokanta tipi yemek seçeneği.",
        "Güncel işletme kaydı", rank=920, note="Lokanta")
    add(db,"Kent Lokantası","sulu",36.918,34.895,"Tarsus","Mersin",
        "Kızılmurat, 2707. Sk. No:1/A, Tarsus",
        "Lokanta tipi günlük yemek seçeneği.",
        "Güncel işletme kaydı", rank=915, note="Günlük yemek")

    # Bodrum/Bursa eski kritik örneklerin bir bölümü seed'de korunur.
    add(db,"Ciğerci Yasin","ciger",37.038,27.424,"Bodrum","Muğla",
        "Yokuşbaşı, Bodrum","Bodrum'da ciğer için yerel ve salaş adreslerden.",
        "Yerel kaynaklarla doğrulanmış kayıt",rank=990,note="⭐ Köklü/yerel tavsiye")
    add(db,"Pedasa Antik Kenti","antik",37.082,27.400,"Bodrum","Muğla",
        "Konacık / Gökçeler","Leleg yerleşimi; akropol, kutsal alan ve nekropol kalıntıları bulunur.",
        "Bodrum Belediyesi",rank=980,note="Antik kent")
    add(db,"Myndos Antik Kenti","antik",37.054,27.234,"Bodrum","Muğla",
        "Gümüşlük","Antik liman kenti; sur ve liman kalıntılarıyla bilinir.",
        "Bodrum Belediyesi",rank=975,note="Antik kent")
    add(db,"Bursa Kalesi ve Hisar Surları","kale",40.182,29.055,"Bursa","Bursa",
        "Osmangazi","Bursa'nın tarihî Hisar bölgesindeki savunma yapıları.",
        "Bursa Büyükşehir Belediyesi",rank=980,note="Kale / Hisar")
    add(db,"Eşkel Halk Plajı","plaj",40.370,28.420,"Mudanya","Bursa",
        "Eşkel, Mudanya","Bursa kıyılarındaki halk plajlarından.",
        "Bursa Büyükşehir Belediyesi",rank=950,note="Halk plajı")

    db.commit()
    db.execute("ANALYZE")
    db.close()
    print(OUT)

if __name__ == "__main__":
    build()
