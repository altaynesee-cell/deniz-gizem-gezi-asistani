#!/usr/bin/env python3
import argparse, sqlite3, sys, json, re, unicodedata

def norm(s):
    s=s.lower().replace("ı","i").replace("ğ","g").replace("ü","u").replace("ş","s").replace("ö","o").replace("ç","c")
    s=unicodedata.normalize("NFD",s)
    s="".join(ch for ch in s if unicodedata.category(ch)!="Mn")
    return re.sub(r"[^a-z0-9]+"," ",s).strip()

ap=argparse.ArgumentParser()
ap.add_argument("db")
ap.add_argument("--strict",action="store_true")
args=ap.parse_args()

db=sqlite3.connect(args.db)
total=db.execute("select count(*) from poi").fetchone()[0]
regions=db.execute("select count(*) from regions").fetchone()[0]
cats=dict(db.execute("select category_key,count(*) from poi group by category_key"))

def count_region(name,key):
    n=norm(name)
    r=db.execute("""
      select south,west,north,east from regions
      where name_norm=? order by case subtype when 'region' then 0 when 'county' then 1 when 'localadmin' then 2 else 3 end
      limit 1
    """,(n,)).fetchone()
    if not r: return 0
    s,w,nn,e=r
    return db.execute("""
      select count(*) from poi where category_key=? and lat between ? and ? and lon between ? and ?
    """,(key,s,nn,w,e)).fetchone()[0]

checks={
  "tarsus_antik":count_region("Tarsus","antik"),
  "tarsus_kofte":count_region("Tarsus","kofte"),
  "bodrum_antik":count_region("Bodrum","antik"),
  "bursa_kale":count_region("Bursa","kale"),
}
print(json.dumps({"total":total,"regions":regions,"categories":cats,"checks":checks},ensure_ascii=False,indent=2))

if args.strict:
    required=[
      "ciger","kofte","kebap","sulu","tavuk","esnaf","balik","kahvalti",
      "plaj","kum","koy","antik","kale","magara","muze","tarihi","gizem",
      "pansiyon","apart","otel","kamp"
    ]
    missing=[x for x in required if cats.get(x,0)==0]
    if missing:
        raise SystemExit("Eksik zorunlu kategori: "+",".join(missing))

if checks["tarsus_antik"] < 3:
    raise SystemExit("Tarsus antik testi başarısız")
if checks["tarsus_kofte"] < 1:
    raise SystemExit("Tarsus köfte testi başarısız")

if args.strict:
    if total < 5000:
        raise SystemExit(f"Tam Türkiye veri tabanı çok küçük: {total}")
    if regions < 150:
        raise SystemExit(f"Bölge tablosu çok küçük: {regions}")
db.close()
