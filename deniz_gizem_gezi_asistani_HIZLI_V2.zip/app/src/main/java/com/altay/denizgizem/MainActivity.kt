package com.altay.denizgizem

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.*

class MainActivity : Activity() {

    private lateinit var placeInput: EditText
    private lateinit var statusText: TextView
    private lateinit var resultText: TextView
    private lateinit var progress: ProgressBar

    private var currentPlace = ""
    private var lat = 0.0
    private var lon = 0.0

    private var beaches = listOf<Place>()
    private var food = listOf<Place>()
    private var discover = listOf<Place>()
    private var stay = listOf<Place>()

    data class Place(
        val name: String,
        val category: String,
        val lat: Double,
        val lon: Double,
        val extra: String = ""
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }

        root.addView(TextView(this).apply {
            text = "DENİZ GİZEM GEZİ ASİSTANI"
            textSize = 24f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(8))
        })

        root.addView(TextView(this).apply {
            text = "Gideceğin yeri yaz; deniz, lezzet, keşif ve konaklama noktalarını gör."
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(14))
        })

        placeInput = EditText(this).apply {
            hint = "Örn: Çıralı, Antalya"
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
        }
        root.addView(placeInput)

        root.addView(Button(this).apply {
            text = "BÖLGEYİ ARAŞTIR"
            setOnClickListener { startSearch() }
        })

        progress = ProgressBar(this).apply { visibility = View.GONE }
        root.addView(progress)

        statusText = TextView(this).apply {
            text = "Bir bölge yazarak başlayabilirsin."
            textSize = 14f
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(statusText)

        val tabsScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
        }
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        listOf(
            "ÖZET" to { showSummary() },
            "DENİZ" to { showList("🌊 DENİZ", beaches, "Yakındaki plajlar ve kıyı noktaları") },
            "LEZZET" to { showFood() },
            "KEŞFET" to { showList("🏛️ KEŞFET", discover, "Tarihi ve turistik noktalar") },
            "KONAK" to { showList("🛏️ KONAK", stay, "Yakındaki konaklama yerleri") }
        ).forEach { (label, action) ->
            tabs.addView(Button(this).apply {
                text = label
                setOnClickListener { action() }
            })
        }

        tabsScroll.addView(tabs)
        root.addView(tabsScroll)

        val scroll = ScrollView(this)
        resultText = TextView(this).apply {
            textSize = 16f
            setPadding(0, dp(12), 0, dp(30))
        }
        scroll.addView(resultText)
        root.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        setContentView(root)
    }

    private fun startSearch() {
        val q = placeInput.text.toString().trim()
        if (q.isEmpty()) {
            Toast.makeText(this, "Önce bir yer yaz hocam.", Toast.LENGTH_SHORT).show()
            return
        }

        currentPlace = q
        beaches = emptyList()
        food = emptyList()
        discover = emptyList()
        stay = emptyList()

        progress.visibility = View.VISIBLE
        statusText.text = "Bölge bulunuyor…"
        resultText.text = ""

        Thread {
            try {
                val geo = geocode(q)
                lat = geo.first
                lon = geo.second

                runOnUiThread {
                    statusText.text = "Bölge bulundu. Yakın çevre hızlı taranıyor…"
                }

                val pool = Executors.newFixedThreadPool(4)

                val beachFuture = pool.submit(Callable {
                    safeQuery(
                        """
                        nwr(around:15000,$lat,$lon)["natural"="beach"];
                        nwr(around:15000,$lat,$lon)["leisure"="beach_resort"];
                        """.trimIndent(),
                        "Plaj",
                        20
                    )
                })

                val foodFuture = pool.submit(Callable {
                    safeQuery(
                        """
                        nwr(around:5000,$lat,$lon)["amenity"="restaurant"]["name"];
                        nwr(around:5000,$lat,$lon)["amenity"="fast_food"]["name"];
                        """.trimIndent(),
                        "Yeme İçme",
                        25
                    )
                })

                val discoverFuture = pool.submit(Callable {
                    safeQuery(
                        """
                        nwr(around:15000,$lat,$lon)["historic"]["name"];
                        nwr(around:15000,$lat,$lon)["tourism"="attraction"]["name"];
                        nwr(around:15000,$lat,$lon)["historic"="archaeological_site"]["name"];
                        """.trimIndent(),
                        "Keşif",
                        25
                    )
                })

                val stayFuture = pool.submit(Callable {
                    safeQuery(
                        """
                        nwr(around:7000,$lat,$lon)["tourism"~"^(hotel|hostel|guest_house|motel|camp_site)$"]["name"];
                        """.trimIndent(),
                        "Konaklama",
                        25
                    )
                })

                beaches = try { beachFuture.get(15, TimeUnit.SECONDS) } catch (_: Exception) { emptyList() }
                food = try { foodFuture.get(15, TimeUnit.SECONDS) } catch (_: Exception) { emptyList() }
                discover = try { discoverFuture.get(15, TimeUnit.SECONDS) } catch (_: Exception) { emptyList() }
                stay = try { stayFuture.get(15, TimeUnit.SECONDS) } catch (_: Exception) { emptyList() }

                pool.shutdownNow()

                runOnUiThread {
                    progress.visibility = View.GONE
                    statusText.text = "$currentPlace için bulunan sonuçlar hazır."
                    showSummary()
                }

            } catch (e: Exception) {
                runOnUiThread {
                    progress.visibility = View.GONE
                    statusText.text = "Bölge bulunamadı veya bağlantı kurulamadı."
                    resultText.text = "Hata: ${e.message ?: "Bilinmeyen hata"}"
                }
            }
        }.start()
    }

    private fun geocode(query: String): Pair<Double, Double> {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val conn = (URL("https://nominatim.openstreetmap.org/search?format=json&limit=1&q=$encoded")
            .openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8000
            readTimeout = 8000
            setRequestProperty("User-Agent", "DenizGizemGeziAsistani/1.0.2")
            setRequestProperty("Accept-Language", "tr")
        }

        val code = conn.responseCode
        val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader()?.use { it.readText() }.orEmpty()
        conn.disconnect()

        if (code !in 200..299) error("Konum servisi HTTP $code")

        val arr = org.json.JSONArray(text)
        if (arr.length() == 0) error("Yazdığın bölge bulunamadı.")

        val first = arr.getJSONObject(0)
        return first.getString("lat").toDouble() to first.getString("lon").toDouble()
    }

    private fun safeQuery(body: String, category: String, takeCount: Int): List<Place> {
        return try {
            queryOverpass(body, category, takeCount)
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun queryOverpass(body: String, category: String, takeCount: Int): List<Place> {
        val query = """
            [out:json][timeout:9];
            (
            $body
            );
            out center qt 40;
        """.trimIndent()

        val endpoints = listOf(
            "https://overpass.kumi.systems/api/interpreter",
            "https://overpass-api.de/api/interpreter"
        )

        var lastError = "Veri servisine ulaşılamadı."

        for (endpoint in endpoints) {
            try {
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    connectTimeout = 7000
                    readTimeout = 10000
                    setRequestProperty("User-Agent", "DenizGizemGeziAsistani/1.0.2")
                    setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                    setRequestProperty("Accept", "application/json")
                }

                val payload = "data=" + URLEncoder.encode(query, "UTF-8")
                conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }

                val code = conn.responseCode
                val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.use { it.readText() }.orEmpty()
                conn.disconnect()

                if (code !in 200..299) {
                    lastError = "HTTP $code"
                    continue
                }

                val elements = JSONObject(text).getJSONArray("elements")
                val out = mutableListOf<Place>()

                for (i in 0 until elements.length()) {
                    val obj = elements.getJSONObject(i)
                    val tags = obj.optJSONObject("tags") ?: JSONObject()

                    val name = tags.optString("name:tr").ifBlank {
                        tags.optString("name").ifBlank {
                            when (category) {
                                "Plaj" -> "İsimsiz plaj / kıyı noktası"
                                "Yeme İçme" -> "İsimsiz işletme"
                                "Keşif" -> "İsimsiz tarihi / turistik nokta"
                                else -> "İsimsiz konaklama"
                            }
                        }
                    }

                    val pLat = if (obj.has("lat")) obj.optDouble("lat")
                    else obj.optJSONObject("center")?.optDouble("lat") ?: Double.NaN
                    val pLon = if (obj.has("lon")) obj.optDouble("lon")
                    else obj.optJSONObject("center")?.optDouble("lon") ?: Double.NaN

                    if (pLat.isNaN() || pLon.isNaN()) continue

                    val extras = mutableListOf<String>()
                    tags.optString("cuisine").takeIf { it.isNotBlank() }?.let {
                        extras.add("Mutfak: ${it.replace(';', ',')}")
                    }
                    tags.optString("surface").takeIf { it.isNotBlank() }?.let {
                        extras.add("Zemin: $it")
                    }
                    tags.optString("historic").takeIf { it.isNotBlank() }?.let {
                        extras.add("Tarihî tür: $it")
                    }
                    tags.optString("tourism").takeIf { it.isNotBlank() }?.let {
                        extras.add("Tür: $it")
                    }

                    out.add(Place(name, category, pLat, pLon, extras.joinToString(" • ")))
                }

                return out
                    .distinctBy { "${it.name.lowercase()}_${it.lat}_${it.lon}" }
                    .sortedBy { distanceKm(lat, lon, it.lat, it.lon) }
                    .take(takeCount)

            } catch (e: Exception) {
                lastError = e.message ?: "Veri servisi hatası"
            }
        }

        error(lastError)
    }

    private fun showSummary() {
        if (currentPlace.isBlank()) {
            resultText.text = "Henüz bölge seçilmedi."
            return
        }

        val total = beaches.size + food.size + discover.size + stay.size

        resultText.text = buildString {
            append("📍 $currentPlace\n\n")
            append("🌊 Deniz: ${beaches.size} sonuç\n")
            append("🍽️ Lezzet: ${food.size} sonuç\n")
            append("🏛️ Keşfet: ${discover.size} sonuç\n")
            append("🛏️ Konak: ${stay.size} sonuç\n\n")

            if (total == 0) {
                append("Harita servisi şu anda sonuç döndürmedi. Birkaç saniye sonra tekrar deneyebilir veya daha net bir bölge yazabilirsin.\n\n")
                append("Örnek: Antalya yerine Konyaaltı, Antalya veya Çıralı, Antalya.")
            } else {
                append("Sekmelerden ayrıntıları açabilirsin.\n\n")
                append("Not: Bir kategori geçici olarak boş kalırsa diğer kategoriler yine çalışır.")
            }
        }
    }

    private fun showFood() {
        if (food.isEmpty()) {
            showList("🍽️ LEZZET", food, "Yakındaki restoranlar")
            return
        }

        val kofte = food.filter {
            val x = (it.name + " " + it.extra).lowercase()
            x.contains("köfte") || x.contains("kofte") || x.contains("meatball")
        }
        val others = food.filterNot { it in kofte }

        resultText.text = buildString {
            append("🍽️ LEZZET\n\n")
            if (kofte.isNotEmpty()) {
                append("🥩 KÖFTECİ / KÖFTE SONUÇLARI\n\n")
                kofte.take(8).forEachIndexed { i, p -> appendPlace(i + 1, p, this) }
                append("\n")
            }
            append("YAKINDAKİ DİĞER İŞLETMELER\n\n")
            others.take(18).forEachIndexed { i, p -> appendPlace(i + 1, p, this) }
        }
    }

    private fun showList(title: String, list: List<Place>, intro: String) {
        if (currentPlace.isBlank()) {
            resultText.text = "Önce bir bölge ara."
            return
        }

        resultText.text = buildString {
            append("$title\n$intro\n\n")
            if (list.isEmpty()) {
                append("Bu kategori için şu anda sonuç alınamadı.")
            } else {
                list.forEachIndexed { i, p -> appendPlace(i + 1, p, this) }
            }
        }
    }

    private fun appendPlace(index: Int, p: Place, sb: StringBuilder) {
        val d = distanceKm(lat, lon, p.lat, p.lon)
        sb.append("$index. ${p.name}\n")
        sb.append("   Yaklaşık ${"%.1f".format(d)} km")
        if (p.extra.isNotBlank()) sb.append(" • ${p.extra}")
        sb.append("\n\n")
    }

    private fun distanceKm(aLat: Double, aLon: Double, bLat: Double, bLon: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(bLat - aLat)
        val dLon = Math.toRadians(bLon - aLon)
        val aa = sin(dLat / 2).pow(2) +
            cos(Math.toRadians(aLat)) * cos(Math.toRadians(bLat)) *
            sin(dLon / 2).pow(2)
        return 2 * r * asin(sqrt(aa))
    }

    private fun dp(v: Int): Int =
        (v * resources.displayMetrics.density).roundToInt()
}
