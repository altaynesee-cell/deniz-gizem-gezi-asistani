#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, math, re, sqlite3, subprocess, tempfile, unicodedata
from pathlib import Path
from difflib import SequenceMatcher

FOOD={"ciger","kofte","kebap","sulu","tavuk","esnaf","balik","kahvalti"}
PHRASES={
 "ciger":["ciger","arnavut ciger","liver"],
 "kofte":["kofte","kofteci","meatball","inegol kofte"],
 "kebap":["kebap","kebab","ocakbasi","doner","donerci"],
 "sulu":["sulu yemek","ev yemek","ev yemekleri","tabldot","lokanta","sofra"],
 "esnaf":["esnaf","lokanta","sofra","ev yemek","ev yemekleri"],
 "tavuk":["tavuk","pilic","chicken"],
 "balik":["balik","balikci","seafood","fish"],
 "kahvalti":["kahvalti","breakfast","serpme"],
}
GENERIC_LEGEND=("tanitim videosu","medya kutuphanesi","ana sayfa","anasayfa","video galerisi","foto galeri","fotograf galerisi","kultur portali","kultur atlasi ana")

def norm(s):
    s=(s or "").lower().replace("ı","i").replace("ğ","g").replace("ü","u").replace("ş","s").replace("ö","o").replace("ç","c")
    s=unicodedata.normalize("NFD",s);s="".join(ch for ch in s if unicodedata.category(ch)!="Mn")
    return re.sub(r"[^a-z0-9]+"," ",s).strip()

def has_phrase(text,phrases):
    n=" "+norm(text)+" "
    return any(re.search(r"(^|\s)"+re.escape(norm(p))+r"(\s|$)",n) for p in phrases)

def food_ok(key,name,detail=""):
    return has_phrase((name or "")+" "+(detail or ""),PHRASES.get(key,[]))

def parse_year(x):
    n=norm(x)
    m=re.search(r"\b(18\d{2}|19\d{2}|20[0-2]\d)\b",n)
    return int(m.group(1)) if m else None

def _unique_tokens(text):
    out=[]
    for tok in text.split():
        if tok not in out:
            out.append(tok)
    return ' '.join(out)

def canonical(name,key,province='',district=''):
    n=' '+norm(name)+' '
    rm={
      'magara':['magarasi','magara','cave entrance','cave','girisi','giris','entrance'],
      'antik':['antik kenti','antik kent','oren yeri','arkeolojik alani','arkeolojik alan','ruins'],
      'kale':['kalesi','kale','hisari','hisar','surlari','sur','fortress','castle'],
      'plaj':['halk plaji','plaji','plaj','beach'],
      'koy':['koyu','koy','bay'],
      'muze':['muzesi','muze','museum'],
    }.get(key,[])
    for phrase in sorted(rm,key=len,reverse=True):
        n=re.sub(r'(^|\s)'+re.escape(norm(phrase))+r'(\s|$)',' ',n)
    n=re.sub(r'\b(giris|girisi|entrance)\s*\d*\b',' ',n)
    n=re.sub(r'\s+',' ',n).strip()
    n=_unique_tokens(n)
    if key=='magara' and norm(province)=='mersin' and norm(district)=='tarsus' and n in ('taskaya','taskuyu'):
        n='taskuyu'
    return n

def edit_distance(a,b):
    a=norm(a); b=norm(b)
    if a==b: return 0
    if not a: return len(b)
    if not b: return len(a)
    prev=list(range(len(b)+1))
    for i,ca in enumerate(a,1):
        cur=[i]
        for j,cb in enumerate(b,1):
            cur.append(min(cur[-1]+1,prev[j]+1,prev[j-1]+(ca!=cb)))
        prev=cur
    return prev[-1]

def canonical_similar(a,b,key=''):
    a=norm(a); b=norm(b)
    if not a or not b: return False
    if a==b: return True
    if min(len(a),len(b))>=5 and (a in b or b in a): return True
    ratio=SequenceMatcher(None,a,b).ratio()
    dist=edit_distance(a,b)
    if key=='magara':
        return min(len(a),len(b))>=5 and ((dist<=2 and ratio>=0.68) or ratio>=0.86)
    return min(len(a),len(b))>=5 and ((dist<=1 and ratio>=0.82) or ratio>=0.90)

def hav(lat1,lon1,lat2,lon2):
    try:
        if not all(map(math.isfinite,[lat1,lon1,lat2,lon2])): return 1e9
    except Exception:
        return 1e9
    r=6371000; p1=math.radians(lat1);p2=math.radians(lat2);dp=math.radians(lat2-lat1);dl=math.radians(lon2-lon1)
    a=math.sin(dp/2)**2+math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return 2*r*math.asin(min(1,math.sqrt(a)))

def ensure_cols(db):
    cols={r[1] for r in db.execute("pragma table_info(poi)")}
    wanted={"canonical_norm":"TEXT DEFAULT ''","start_year":"INTEGER","branch_count":"INTEGER DEFAULT 1","is_chain":"INTEGER DEFAULT 0","brand_name":"TEXT DEFAULT ''","quality_rank":"REAL DEFAULT 0"}
    for c,t in wanted.items():
        if c not in cols: db.execute(f"ALTER TABLE poi ADD COLUMN {c} {t}")
    db.execute("CREATE INDEX IF NOT EXISTS idx_poi_canonical ON poi(category_key,province_norm,canonical_norm)")

def add_aydin_legends(db):
    rows=[
      ('Marsyas Efsanesi','Aydın','Çine','Çine Çayı, antik çağda Marsyas adıyla anılır. Anlatıda Athena’nın bıraktığı kavalı bulan Marsyas müzikte ustalaşır, Apollon ile yarışır ve sonunda Marsyas’ın bir ırmağa dönüştüğü aktarılır. Bu ırmak Çine Çayı ile özdeşleştirilir.','T.C. Çine Kaymakamlığı','https://www.cine.gov.tr/tarihce','Çine Çayı Marsyas Vadisi Çine Aydın',1400),
      ('Alabanda Kuruluş Efsanesi','Aydın','Çine','Alabanda’nın kuruluş anlatılarından birinde Kral Kar’ın oğluna bir at yarışı zaferiyle bağlantılı olarak Alabandos adını verdiği ve kentin bu adla anıldığı aktarılır.','T.C. Kültür ve Turizm Bakanlığı - Turkish Museums','https://turkishmuseums.kprod.kultur.gov.tr/museum/detail/1982-aydin-alabanda-orenyeri/1982/1','Alabanda Ören Yeri Çine Aydın',1380)
    ]
    for title,prov,dist,summary,src,url,place,score in rows:
        db.execute("""INSERT OR REPLACE INTO legends(title,title_norm,province,province_norm,district,district_norm,summary,source_title,source_url,place_query,rank_score,curated) VALUES(?,?,?,?,?,?,?,?,?,?,?,1)""",(title,norm(title),prov,norm(prov),dist,norm(dist),summary,src,url,place,score))

def clean_legends(db):
    deleted=0
    rows=db.execute("SELECT id,title,summary,source_url FROM legends").fetchall()
    for i,title,summary,url in rows:
        nt=norm(title); ns=norm(summary)
        generic=any(x in nt for x in GENERIC_LEGEND)
        hub=(url or '').rstrip('/').endswith('/kulturatlasi') or (url or '').rstrip('/').endswith('/turkiye/mugla')
        signal=any(x in ns or x in nt for x in ("efsane","rivayet","menkibe","soylence","mitoloji","keramet","anlatilir","inanisa gore"))
        if generic or (hub and not signal):
            db.execute("DELETE FROM legends WHERE id=?",(i,));deleted+=1
    return deleted


def legend_canonical(title,place_query,province='',district=''):
    raw=place_query or title or ''
    n=norm(raw)
    # Yedi Uyurlar / Eshab-ı Kehf yazım varyantları aynı fiziksel noktadır.
    if ('yedi uyurlar' in n) or (('eshab' in n or 'ashab' in n) and 'keh' in n):
        return 'eshab kehf'
    noise={
      'efsane','efsanesi','efsaneleri','rivayet','rivayeti','menkibe','menkibesi','soylence',
      'hikaye','hikayesi','anlati','anlatimi','magara','magarasi','cave','kale','kalesi','hisar',
      'hisari','turbe','turbesi','cami','camii','oren','yeri','muze','muzesi','museum','the','of'
    }
    loc=set(norm(province).split()+norm(district).split())
    out=[]
    for t in n.split():
        if len(t)<=1 or t in noise or t in loc: continue
        if t not in out: out.append(t)
    return ' '.join(out)

def legend_similar(a,b):
    a=norm(a);b=norm(b)
    if not a or not b:return False
    if a==b:return True
    if min(len(a),len(b))>=5 and (a in b or b in a):return True
    return edit_distance(a,b)<=2 and min(len(a),len(b))>=5

def dedupe_legends(db):
    rows=db.execute("""SELECT id,title,province,district,summary,source_title,source_url,place_query,rank_score,curated
                       FROM legends ORDER BY curated DESC,rank_score DESC,length(summary) DESC""").fetchall()
    keep=[];deleted=0
    for row in rows:
        rid,title,prov,dist,summary,src,url,place,rank,cur=row
        can=legend_canonical(title,place,prov,dist)
        dup=None
        for k in keep:
            krid,ktitle,kprov,kdist,kcan=k
            if norm(prov)!=norm(kprov):continue
            if norm(dist) and norm(kdist) and norm(dist)!=norm(kdist):continue
            tcan=legend_canonical(title,'',prov,dist)
            ktcan=legend_canonical(ktitle,'',kprov,kdist)
            if legend_similar(can,kcan) or legend_similar(tcan,ktcan) or legend_similar(can,ktcan) or legend_similar(tcan,kcan):
                dup=k;break
        if not dup:
            keep.append((rid,title,prov,dist,can));continue
        krid=dup[0]
        old=db.execute("SELECT summary,source_title,source_url,place_query,rank_score,curated,district FROM legends WHERE id=?",(krid,)).fetchone()
        osum,osrc,ourl,oplace,orank,ocur,odist=old
        sources=[]
        for x in ((osrc or '').split(' + ')+(src or '').split(' + ')):
            x=x.strip()
            if x and x not in sources:sources.append(x)
        # En iyi/kısa kaynaklı özeti koru; boş alanları diğer kayıttan tamamla.
        nsum=osum or summary or ''
        if not ocur and cur and summary: nsum=summary
        ndist=odist or dist or ''
        db.execute("""UPDATE legends SET summary=?,source_title=?,source_url=?,place_query=?,rank_score=?,curated=?,district=?,district_norm=? WHERE id=?""",
                   (nsum,' + '.join(sources),ourl or url or '',oplace or place or '',max(orank or 0,rank or 0),max(ocur or 0,cur or 0),ndist,norm(ndist),krid))
        db.execute("DELETE FROM legends WHERE id=?",(rid,));deleted+=1
    return deleted

def enrich_osm(db,pbf):
    if not pbf: return {"matched":0,"years":0,"brands":0}
    p=Path(pbf)
    if not p.exists(): return {"matched":0,"years":0,"brands":0}
    with tempfile.TemporaryDirectory(prefix='v15osm_') as td:
        td=Path(td);filt=td/'food.osm.pbf';geo=td/'food.geojsonseq'
        subprocess.run(['osmium','tags-filter',str(p),'nwr/amenity=restaurant','nwr/amenity=fast_food','nwr/amenity=cafe','-o',str(filt),'--overwrite'],check=True)
        subprocess.run(['osmium','export',str(filt),'-f','geojsonseq','-o',str(geo),'--overwrite'],check=True)
        matched=years=brands=0
        for line in geo.open('r',encoding='utf-8',errors='replace'):
            line=line.strip().lstrip('\x1e')
            if not line: continue
            try:
                feat=json.loads(line); pr=feat.get('properties') or {}; name=(pr.get('name') or '').strip(); coords=feat.get('geometry',{}).get('coordinates')
            except Exception:
                continue
            if not name: continue
            lat=lon=None
            if isinstance(coords,list) and len(coords)>=2 and isinstance(coords[0],(int,float)):
                lon=float(coords[0]);lat=float(coords[1])
            cuisine=pr.get('cuisine','') or ''
            desc=pr.get('description','') or ''
            start=pr.get('start_date','') or ''
            brand=pr.get('brand','') or pr.get('operator','') or ''
            evidence=' '.join([name,cuisine,desc])
            for key in FOOD:
                if not food_ok(key,evidence,''): continue
                nn=norm(name)
                candidates=db.execute("SELECT id,lat,lon,detail,start_year,brand_name FROM poi WHERE category_key=? AND name_norm=?",(key,nn)).fetchall()
                if not candidates: continue
                year=parse_year(start)
                for rid,rlat,rlon,old_detail,old_year,old_brand in candidates:
                    if lat is not None and abs(rlat)>0.01 and hav(lat,lon,rlat,rlon)>500: continue
                    extra=[]
                    if cuisine: extra.append('Mutfak: '+cuisine.replace(';',', '))
                    nd=(old_detail or '')
                    if extra and norm(extra[0]) not in norm(nd): nd=(nd+' • '+extra[0]).strip(' •')
                    db.execute("UPDATE poi SET detail=?,start_year=COALESCE(start_year,?),brand_name=CASE WHEN brand_name='' THEN ? ELSE brand_name END WHERE id=?",(nd,year,brand,rid))
                    matched+=1
                    if year and not old_year: years+=1
                    if brand and not old_brand: brands+=1
        return {"matched":matched,"years":years,"brands":brands}

def seed_bursa_old(db):
    rows=[
      ('Besler İnegöl Köftecisi 1893','kofte','Bursa','İnegöl','Cuma Mah., Belediye Cd., İnegöl','İnegöl köftesinin köklü adreslerinden; Bursa turizm kaynağı başlangıcı 1893’e dayandırır.','Rota Bursa / Besler 1893','https://rota.bursa.com.tr/mekanlar/besler-inegol-koftecisi-1893-776','Köfte • doğrulanmış kuruluş yılı','Besler İnegöl Köftecisi İnegöl Bursa',40.078,29.513,1893,1700),
      ('Rodop Köftecisi','kofte','Bursa','Osmangazi','','İşletmenin kendi tarihçesine göre Halil Şensoylu 1946’da Bursa Setbaşı’nda işe başladı.','Rodop Köftecisi resmi tarihçe','https://rodopkoftecisi.com.tr/tarihce/','Köfte • doğrulanmış kuruluş yılı','Rodop Köftecisi Bursa',40.195,29.060,1946,1650),
    ]
    for name,key,prov,dist,addr,detail,src,url,note,route,lat,lon,year,score in rows:
        nn=norm(name);can=canonical(name,key)
        hit=db.execute("SELECT id FROM poi WHERE category_key=? AND province_norm=? AND (name_norm=? OR name_norm LIKE ?) LIMIT 1",(key,norm(prov),nn,'%'+norm(name.split()[0])+'%')).fetchone()
        if hit:
            db.execute("UPDATE poi SET curated=1,start_year=?,rank_score=MAX(rank_score,?),quality_rank=MAX(quality_rank,?),source=?,source_url=?,detail=?,match_note=?,canonical_norm=? WHERE id=?",(year,score,score,src,url,detail,note,can,hit[0]))
        else:
            db.execute("""INSERT INTO poi(name,name_norm,category_key,province,province_norm,district,district_norm,address,detail,source,source_url,match_note,route_query,lat,lon,rank_score,source_count,curated,canonical_norm,start_year,branch_count,is_chain,brand_name,quality_rank) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(name,nn,key,prov,norm(prov),dist,norm(dist),addr,detail,src,url,note,route,lat,lon,score,2,1,can,year,1,0,'',score))

def clean_food(db):
    deleted=0
    rows=db.execute("SELECT id,category_key,name,detail,curated FROM poi WHERE category_key IN ('ciger','kofte','kebap','sulu','tavuk','esnaf','balik','kahvalti')").fetchall()
    for rid,key,name,detail,cur in rows:
        if cur: continue
        if not food_ok(key,name,detail):
            db.execute("DELETE FROM poi WHERE id=?",(rid,));deleted+=1
    return deleted

def fill_canon(db):
    for rid,name,key,prov,dist in db.execute("SELECT id,name,category_key,province,district FROM poi").fetchall():
        db.execute("UPDATE poi SET canonical_norm=? WHERE id=?",(canonical(name,key,prov,dist) or norm(name),rid))

def dedupe(db):
    thresholds={"magara":1300,"antik":650,"kale":500,"plaj":350,"koy":650,"muze":180,"tarihi":220,"pansiyon":80,"apart":80,"otel":80,"kamp":120}
    merged=0
    for key,thr in thresholds.items():
        groups=db.execute("SELECT province_norm,canonical_norm,count(*) FROM poi WHERE category_key=? AND canonical_norm<>'' GROUP BY province_norm,canonical_norm HAVING count(*)>1",(key,)).fetchall()
        for prov,can,cnt in groups:
            rows=db.execute("SELECT id,name,lat,lon,curated,source_count,rank_score,source,detail,address,match_note,route_query,district_norm FROM poi WHERE category_key=? AND province_norm=? AND canonical_norm=? ORDER BY curated DESC,source_count DESC,rank_score DESC",(key,prov,can)).fetchall()
            keep=[]
            for row in rows:
                rid,name,lat,lon,cur,sc,rank,src,detail,address,note,route,dist=row
                dup=None
                for k in keep:
                    krid,kname,klat,klon,kdist=k
                    near=hav(lat,lon,klat,klon)<=thr if abs(lat)>0.01 and abs(klat)>0.01 else (dist==kdist)
                    sim=SequenceMatcher(None,norm(name),norm(kname)).ratio()
                    if near and (can or sim>=.78): dup=k;break
                if dup:
                    krid=dup[0]
                    old=db.execute("SELECT source_count,source FROM poi WHERE id=?",(krid,)).fetchone()
                    osc,osrc=old
                    nsrc=osrc if src in (osrc or '') else ((osrc+' + '+src).strip(' +'))
                    db.execute("UPDATE poi SET source_count=?,source=?,detail=CASE WHEN detail='' THEN ? ELSE detail END,address=CASE WHEN address='' THEN ? ELSE address END,match_note=CASE WHEN match_note='' THEN ? ELSE match_note END WHERE id=?",(osc+sc,nsrc,detail,address,note,krid))
                    db.execute("DELETE FROM poi WHERE id=?",(rid,));merged+=1
                else:
                    keep.append((rid,name,lat,lon,dist))
    for key in FOOD:
        groups=db.execute("SELECT province_norm,canonical_norm,count(*) FROM poi WHERE category_key=? AND canonical_norm<>'' GROUP BY province_norm,canonical_norm HAVING count(*)>1",(key,)).fetchall()
        for prov,can,cnt in groups:
            rows=db.execute("SELECT id,name,lat,lon,curated,source_count,rank_score,source FROM poi WHERE category_key=? AND province_norm=? AND canonical_norm=? ORDER BY curated DESC,source_count DESC,rank_score DESC",(key,prov,can)).fetchall()
            keep=[]
            for rid,name,lat,lon,cur,sc,rank,src in rows:
                dup=next((k for k in keep if abs(lat)>0.01 and abs(k[2])>0.01 and hav(lat,lon,k[2],k[3])<=90),None)
                if dup:
                    krid=dup[0];osc,osrc=db.execute("SELECT source_count,source FROM poi WHERE id=?",(krid,)).fetchone();nsrc=osrc if src in (osrc or '') else ((osrc+' + '+src).strip(' +'))
                    db.execute("UPDATE poi SET source_count=?,source=? WHERE id=?",(osc+sc,nsrc,krid));db.execute("DELETE FROM poi WHERE id=?",(rid,));merged+=1
                else: keep.append((rid,name,lat,lon))
    return merged


def collapse_exact_physical_duplicates(db):
    """
    Son güvenlik katmanı: aynı ilde aynı fiziksel yer adı/canonical adı birden
    fazla kaynaktan farklı koordinatlarla gelmiş olsa bile tek karta indir.
    Özellikle mağara girişleri ve farklı harita kaynakları için gereklidir.
    """
    keys=("magara","antik","kale","plaj","koy","muze")
    merged=0
    for key in keys:
        groups=db.execute(
            "SELECT province_norm,canonical_norm,count(*) FROM poi "
            "WHERE category_key=? AND canonical_norm<>'' "
            "GROUP BY province_norm,canonical_norm HAVING count(*)>1",
            (key,)
        ).fetchall()
        for prov,can,cnt in groups:
            rows=db.execute(
                "SELECT id,name,lat,lon,curated,source_count,rank_score,source,detail,address,match_note,route_query,start_year,quality_rank "
                "FROM poi WHERE category_key=? AND province_norm=? AND canonical_norm=? "
                "ORDER BY curated DESC,source_count DESC,quality_rank DESC,rank_score DESC",
                (key,prov,can)
            ).fetchall()
            if len(rows)<2:
                continue
            keep=rows[0]
            krid=keep[0]
            for row in rows[1:]:
                rid,name,lat,lon,cur,sc,rank,src,detail,address,note,route,year,qrank=row
                old=db.execute(
                    "SELECT source_count,source,detail,address,match_note,route_query,start_year,curated,rank_score,quality_rank FROM poi WHERE id=?",
                    (krid,)
                ).fetchone()
                osc,osrc,odetail,oaddr,onote,oroute,oyear,ocur,orank,oqrank=old
                src_parts=[]
                for part in ((osrc or '').split(' + ')+(src or '').split(' + ')):
                    part=part.strip()
                    if part and part not in src_parts:
                        src_parts.append(part)
                nsrc=' + '.join(src_parts)
                nyear=min([x for x in (oyear,year) if x is not None],default=None)
                db.execute(
                    "UPDATE poi SET source_count=?,source=?,detail=?,address=?,match_note=?,route_query=?,start_year=?,curated=?,rank_score=?,quality_rank=? WHERE id=?",
                    (
                        (osc or 0)+(sc or 0), nsrc,
                        odetail or detail or '', oaddr or address or '', onote or note or '', oroute or route or '',
                        nyear, max(ocur or 0,cur or 0), max(orank or 0,rank or 0), max(oqrank or 0,qrank or 0), krid
                    )
                )
                db.execute("DELETE FROM poi WHERE id=?",(rid,))
                merged+=1
    return merged

def collapse_fuzzy_physical_duplicates(db):
    keys=('magara','antik','kale','plaj','koy','muze')
    merged=0
    for key in keys:
        groups=db.execute(
            "SELECT province_norm,district_norm FROM poi WHERE category_key=? GROUP BY province_norm,district_norm HAVING count(*)>1",
            (key,)
        ).fetchall()
        for prov,dist in groups:
            rows=db.execute(
                "SELECT id,name,canonical_norm,lat,lon,curated,source_count,rank_score,source,detail,address,match_note,route_query,quality_rank "
                "FROM poi WHERE category_key=? AND province_norm=? AND district_norm=? "
                "ORDER BY curated DESC,source_count DESC,quality_rank DESC,rank_score DESC",
                (key,prov,dist)
            ).fetchall()
            keep=[]
            for row in rows:
                rid,name,can,lat,lon,cur,sc,rank,src,detail,address,note,route,qrank=row
                dup=None
                for k in keep:
                    krid,kname,kcan,klat,klon=k
                    if not canonical_similar(can,kcan,key):
                        continue
                    valid_geo=abs(lat)>0.01 and abs(klat)>0.01
                    distance=hav(lat,lon,klat,klon) if valid_geo else 1e9
                    exact=(can==kcan)
                    geo_ok=distance <= (2500 if key=='magara' else 900)
                    typo_close=(key=='magara' and edit_distance(can,kcan)<=2 and SequenceMatcher(None,can,kcan).ratio()>=0.68)
                    if exact or geo_ok or typo_close:
                        dup=k; break
                if dup is None:
                    keep.append((rid,name,can,lat,lon)); continue
                krid=dup[0]
                old=db.execute(
                    "SELECT source_count,source,detail,address,match_note,route_query,curated,rank_score,quality_rank FROM poi WHERE id=?",
                    (krid,)
                ).fetchone()
                osc,osrc,odetail,oaddr,onote,oroute,ocur,orank,oqrank=old
                parts=[]
                for part in ((osrc or '').split(' + ')+(src or '').split(' + ')):
                    part=part.strip()
                    if part and part not in parts: parts.append(part)
                db.execute(
                    "UPDATE poi SET source_count=?,source=?,detail=?,address=?,match_note=?,route_query=?,curated=?,rank_score=?,quality_rank=? WHERE id=?",
                    ((osc or 0)+(sc or 0),' + '.join(parts),odetail or detail or '',oaddr or address or '',onote or note or '',oroute or route or '',max(ocur or 0,cur or 0),max(orank or 0,rank or 0),max(oqrank or 0,qrank or 0),krid)
                )
                db.execute("DELETE FROM poi WHERE id=?",(rid,))
                merged+=1
    return merged

def chain_rank(db):
    groups=db.execute("SELECT category_key,canonical_norm,count(*) FROM poi WHERE category_key IN ('ciger','kofte','kebap','sulu','tavuk','esnaf','balik','kahvalti') AND canonical_norm<>'' GROUP BY category_key,canonical_norm").fetchall()
    for key,can,cnt in groups:
        chain=1 if cnt>=5 else 0
        db.execute("UPDATE poi SET branch_count=?,is_chain=CASE WHEN brand_name<>'' OR ?=1 THEN 1 ELSE 0 END WHERE category_key=? AND canonical_norm=?",(cnt,chain,key,can))
    db.execute("""UPDATE poi SET quality_rank = rank_score + CASE WHEN curated=1 THEN 500 ELSE 0 END + CASE WHEN start_year IS NOT NULL THEN (2030-start_year)*3 ELSE 0 END + source_count*12 - CASE WHEN is_chain=1 THEN 350 ELSE 0 END""")

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--db',required=True);ap.add_argument('--osm-pbf');ap.add_argument('--self-test',action='store_true');a=ap.parse_args()
    if a.self_test:
        assert not has_phrase('delivery service',['liver'])
        assert has_phrase('liver restaurant',['liver'])
        assert canonical('Oylat Mağarası Girişi','magara')=='oylat'
        assert canonical('Oylat Cave Entrance','magara')=='oylat'
        assert canonical('Oylat Mağarası','magara')==canonical('Oylat Mağarası Girişi','magara')
        assert canonical('Taşkuyu Mağarası - Taskuyu Cave','magara','Mersin','Tarsus')=='taskuyu'
        assert canonical('Taşkaya Mağarası','magara','Mersin','Tarsus')=='taskuyu'
        assert canonical_similar('taskuyu','taskaya','magara')
        assert legend_canonical('Eshab-ı Kehf / Yedi Uyurlar','Eshab-ı Kehf Mağarası Tarsus','Mersin','Tarsus')=='eshab kehf'
        assert legend_canonical('Eshabı Kehf Mağarası - Mersin','Eshabı Kehf Mağarası Tarsus Mersin','Mersin','Tarsus')=='eshab kehf'
        print('V15_FIX3_SELF_TEST_OK');return
    db=sqlite3.connect(a.db)
    ensure_cols(db);add_aydin_legends(db)
    legend_deleted=clean_legends(db)
    legend_duplicates_deleted=dedupe_legends(db)
    osm_stats=enrich_osm(db,a.osm_pbf)
    seed_bursa_old(db)
    food_deleted=clean_food(db)
    fill_canon(db)
    merged=dedupe(db)
    exact_merged=collapse_exact_physical_duplicates(db)
    fuzzy_merged=collapse_fuzzy_physical_duplicates(db)
    fill_canon(db)
    chain_rank(db)
    db.execute("INSERT OR REPLACE INTO meta(key,value) VALUES('dataset_label','V15.3 Köklü + Temiz Türkiye • POI + efsane tekilleştirme • taze yerel DB')")
    db.commit();db.execute('ANALYZE');db.execute('VACUUM')
    stats={"legend_deleted":legend_deleted,"legend_duplicates_deleted":legend_duplicates_deleted,"food_false_deleted":food_deleted,"duplicates_merged":merged,"exact_physical_duplicates_merged":exact_merged,"fuzzy_physical_duplicates_merged":fuzzy_merged,"osm_enrich":osm_stats,"poi":db.execute('select count(*) from poi').fetchone()[0],"legends":db.execute('select count(*) from legends').fetchone()[0]}
    db.close();print(json.dumps(stats,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
