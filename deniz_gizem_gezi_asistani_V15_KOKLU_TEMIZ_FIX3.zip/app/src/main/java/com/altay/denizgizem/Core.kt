package com.altay.denizgizem

import java.text.Normalizer
import java.util.Locale

enum class Group(val title: String, val emoji: String) {
    FOOD("Lezzet","🍽"), SEA("Deniz","🌊"), DISCOVER("Keşfet","🏛"), STAY("Konak","🛏")
}
data class CategorySpec(val key:String,val title:String,val emoji:String,val group:Group)

object Categories {
    val all = listOf(
        CategorySpec("ciger","Ciğer / Arnavut","🥩",Group.FOOD),
        CategorySpec("kofte","Köfte","🧆",Group.FOOD),
        CategorySpec("kebap","Kebap","🔥",Group.FOOD),
        CategorySpec("sulu","Sulu Yemek","🍲",Group.FOOD),
        CategorySpec("tavuk","Tavuk","🍗",Group.FOOD),
        CategorySpec("esnaf","Esnaf Lokantası","🥘",Group.FOOD),
        CategorySpec("balik","Balık","🐟",Group.FOOD),
        CategorySpec("kahvalti","Kahvaltı","🍳",Group.FOOD),
        CategorySpec("plaj","Plaj","🏖",Group.SEA),
        CategorySpec("kum","Sığ + Kum","👣",Group.SEA),
        CategorySpec("koy","Koy","🌊",Group.SEA),
        CategorySpec("antik","Antik / Arkeolojik","🏺",Group.DISCOVER),
        CategorySpec("kale","Kale / Hisar / Sur","🏰",Group.DISCOVER),
        CategorySpec("magara","Mağara","🕳",Group.DISCOVER),
        CategorySpec("muze","Müze","🏛",Group.DISCOVER),
        CategorySpec("tarihi","Tarihi Yer","📜",Group.DISCOVER),
        CategorySpec("gizem","Gizem / Efsane","👁",Group.DISCOVER),
        CategorySpec("pansiyon","Pansiyon","🏡",Group.STAY),
        CategorySpec("apart","Apart","🏢",Group.STAY),
        CategorySpec("otel","Otel","🏨",Group.STAY),
        CategorySpec("kamp","Kamp","⛺",Group.STAY)
    )
    fun byKey(key:String)=all.first{it.key==key}
    fun forGroup(group:Group)=all.filter{it.group==group}
}

object TextNorm {
    fun norm(s:String):String {
        val x=s.lowercase(Locale.forLanguageTag("tr-TR"))
            .replace('ı','i').replace('ğ','g').replace('ü','u')
            .replace('ş','s').replace('ö','o').replace('ç','c')
        return Normalizer.normalize(x,Normalizer.Form.NFD)
            .replace("\\p{M}".toRegex(),"")
            .replace("[^a-z0-9]+".toRegex()," ").trim()
    }
}

data class RegionHit(
    val name:String,
    val kind:String,
    val province:String,
    val lat:Double,
    val lon:Double
)

data class ResultItem(
    val id:Long,
    val name:String,
    val categoryKey:String,
    val province:String,
    val district:String,
    val address:String,
    val detail:String,
    val source:String,
    val sourceUrl:String,
    val matchNote:String,
    val routeQuery:String,
    val rankScore:Double,
    val sourceCount:Int,
    val curated:Boolean,
    val isLegend:Boolean,
    val startYear:Int?,
    val branchCount:Int,
    val isChain:Boolean,
    val lat:Double?=null,
    val lon:Double?=null
)

object ResultDedupe {
    private val legendNoise = setOf(
        "efsane","efsanesi","efsaneleri","rivayet","rivayeti","menkibe","menkibesi",
        "soylence","hikaye","hikayesi","anlati","anlatimi","magara","magarasi","cave",
        "kale","kalesi","hisar","hisari","turbe","turbesi","cami","camii","oren","yeri",
        "museum","muzesi","muze","the","of"
    )

    private fun tokens(s:String):List<String> = TextNorm.norm(s).split(Regex("\\s+")).filter { it.isNotBlank() }

    private fun levenshtein(a:String,b:String):Int {
        if(a==b) return 0
        if(a.isEmpty()) return b.length
        if(b.isEmpty()) return a.length
        var prev=IntArray(b.length+1){it}
        for(i in 1..a.length){
            val cur=IntArray(b.length+1);cur[0]=i
            for(j in 1..b.length){
                val cost=if(a[i-1]==b[j-1]) 0 else 1
                cur[j]=minOf(cur[j-1]+1,prev[j]+1,prev[j-1]+cost)
            }
            prev=cur
        }
        return prev[b.length]
    }

    fun legendCore(text:String,province:String="",district:String=""):String {
        var n=TextNorm.norm(text)
        if(n.isBlank()) return ""

        // Yaygın aynı-yer adları: yazım ve dil varyantlarını tek kimliğe indir.
        if((n.contains("eshab") || n.contains("ashab") || n.contains("yedi uyurlar")) && n.contains("keh") || n.contains("yedi uyurlar")) {
            return "eshab kehf"
        }

        val locationNoise=(tokens(province)+tokens(district)).toSet()
        val out=mutableListOf<String>()
        for(t in tokens(n)) {
            if(t.length<=1) continue
            if(t in legendNoise) continue
            if(t in locationNoise) continue
            if(t !in out) out+=t
        }
        return out.joinToString(" ")
    }

    private fun similar(a:String,b:String):Boolean {
        if(a.isBlank() || b.isBlank()) return false
        if(a==b) return true
        if(a.length>=5 && b.length>=5 && (a.contains(b) || b.contains(a))) return true
        val d=levenshtein(a,b)
        return d<=2 && minOf(a.length,b.length)>=5
    }

    fun sameLegendPlace(a:ResultItem,b:ResultItem):Boolean {
        if(TextNorm.norm(a.province)!=TextNorm.norm(b.province)) return false
        val ad=TextNorm.norm(a.district); val bd=TextNorm.norm(b.district)
        if(ad.isNotBlank() && bd.isNotBlank() && ad!=bd) return false

        val ar=legendCore(a.routeQuery,a.province,a.district)
        val br=legendCore(b.routeQuery,b.province,b.district)
        if(similar(ar,br)) return true

        val an=legendCore(a.name,a.province,a.district)
        val bn=legendCore(b.name,b.province,b.district)
        return similar(an,bn) || similar(ar,bn) || similar(an,br)
    }

    fun dedupeLegends(input:List<ResultItem>,limit:Int):List<ResultItem> {
        val out=mutableListOf<ResultItem>()
        for(x in input) {
            if(out.none { sameLegendPlace(x,it) }) out+=x
            if(out.size>=limit) break
        }
        return out
    }
}

