package com.altay.denizgizem
import org.junit.Assert.*
import org.junit.Test
class CoreTest {
 @Test fun normalization(){assertEquals("sanliurfa",TextNorm.norm("ŞANLIURFA"));assertEquals("igdir",TextNorm.norm("Iğdır"))}
 @Test fun allButtons(){assertEquals(21,Categories.all.map{it.key}.toSet().size);assertNotNull(Categories.byKey("gizem"));assertNotNull(Categories.byKey("kum"))}

 @Test fun legendDuplicateCollapses(){
   val a=ResultItem(1,"Eshab-ı Kehf / Yedi Uyurlar","gizem","Mersin","Tarsus","","özet","Türkiye Kültür Portalı","","","Eshab-ı Kehf Mağarası Tarsus",1000.0,1,true,true,null,1,false)
   val b=ResultItem(2,"Eshabı Kehf Mağarası - Mersin","gizem","Mersin","Tarsus","","özet2","Wikipedia","","","Eshabı Kehf Mağarası Tarsus Mersin",900.0,1,false,true,null,1,false)
   assertTrue(ResultDedupe.sameLegendPlace(a,b))
   assertEquals(1,ResultDedupe.dedupeLegends(listOf(a,b),10).size)
 }
}
