package com.altay.denizgizem

import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import java.io.File

object OfflineDb {
    private const val ASSET = "turkey_v14.sqlite"
    private const val LOCAL = "turkey_v14.sqlite"

    @Synchronized
    private fun file(context: Context): File {
        val out=File(context.filesDir,LOCAL)
        if(!out.exists() || out.length()==0L) {
            context.assets.open(ASSET).use { input ->
                out.outputStream().use { output -> input.copyTo(output) }
            }
        }
        return out
    }

    private fun open(context:Context)=SQLiteDatabase.openDatabase(
        file(context).absolutePath,null,SQLiteDatabase.OPEN_READONLY
    )

    fun metadata(context:Context):String=open(context).use { db ->
        db.rawQuery("SELECT value FROM meta WHERE key='dataset_label' LIMIT 1",null).use { c ->
            if(c.moveToFirst()) c.getString(0) else "V14 Türkiye verisi"
        }
    }

    fun findRegion(context:Context, raw:String):RegionHit? {
        val q=TextNorm.norm(raw)
        if(q.isBlank()) return null
        open(context).use { db ->
            db.rawQuery("""
                SELECT r.name,r.kind,r.province,r.lat,r.lon
                FROM aliases a JOIN regions r ON r.name_norm=a.target_norm
                WHERE a.alias_norm=? LIMIT 1
            """.trimIndent(), arrayOf(q)).use { c ->
                if(c.moveToFirst()) return c.region()
            }
            db.rawQuery("""
                SELECT name,kind,province,lat,lon FROM regions
                WHERE name_norm=?
                ORDER BY CASE kind WHEN 'province' THEN 0 ELSE 1 END LIMIT 1
            """.trimIndent(), arrayOf(q)).use { c ->
                if(c.moveToFirst()) return c.region()
            }
        }
        return null
    }

    fun search(context:Context, rawRegion:String, categoryKey:String, limit:Int=40):Pair<RegionHit?,List<ResultItem>> {
        val region=findRegion(context,rawRegion) ?: return null to emptyList()
        return if(categoryKey=="gizem") region to searchLegends(context,region,limit)
        else region to searchPoi(context,region,categoryKey,limit)
    }

    private fun searchPoi(context:Context,r:RegionHit,key:String,limit:Int):List<ResultItem> =
        open(context).use { db ->
            val district = r.kind=="district"
            val sql = if(district) """
                SELECT id,name,category_key,province,district,address,detail,source,source_url,
                       match_note,route_query,rank_score,source_count,curated
                FROM poi WHERE category_key=? AND district_norm=?
                ORDER BY curated DESC, source_count DESC, rank_score DESC, name COLLATE NOCASE LIMIT ?
            """ else """
                SELECT id,name,category_key,province,district,address,detail,source,source_url,
                       match_note,route_query,rank_score,source_count,curated
                FROM poi WHERE category_key=? AND province_norm=?
                ORDER BY curated DESC, source_count DESC, rank_score DESC, name COLLATE NOCASE LIMIT ?
            """
            val norm=TextNorm.norm(if(district) r.name else r.province.ifBlank{r.name})
            db.rawQuery(sql.trimIndent(),arrayOf(key,norm,limit.toString())).use { c ->
                buildList { while(c.moveToNext()) add(c.poi(false)) }
            }
        }

    private fun searchLegends(context:Context,r:RegionHit,limit:Int):List<ResultItem> =
        open(context).use { db ->
            val district=r.kind=="district"
            val sql=if(district) """
                SELECT id,title,province,district,summary,source_title,source_url,place_query,rank_score,curated
                FROM legends
                WHERE district_norm=? OR (district_norm='' AND province_norm=?)
                ORDER BY CASE WHEN district_norm=? THEN 0 ELSE 1 END, curated DESC, rank_score DESC, title
                LIMIT ?
            """ else """
                SELECT id,title,province,district,summary,source_title,source_url,place_query,rank_score,curated
                FROM legends WHERE province_norm=?
                ORDER BY curated DESC, rank_score DESC, title LIMIT ?
            """
            val prov=TextNorm.norm(r.province.ifBlank{r.name})
            val args=if(district) arrayOf(TextNorm.norm(r.name),prov,TextNorm.norm(r.name),limit.toString())
                     else arrayOf(prov,limit.toString())
            db.rawQuery(sql.trimIndent(),args).use { c ->
                buildList {
                    while(c.moveToNext()) {
                        add(ResultItem(
                            id=c.getLong(0),name=c.getString(1),categoryKey="gizem",
                            province=c.getString(2).orEmpty(),district=c.getString(3).orEmpty(),
                            address="",detail=c.getString(4).orEmpty(),source=c.getString(5).orEmpty(),
                            sourceUrl=c.getString(6).orEmpty(),matchNote="Kaynaklı efsane / menkıbe / rivayet",
                            routeQuery=c.getString(7).orEmpty(),rankScore=c.getDouble(8),
                            sourceCount=1,curated=c.getInt(9)==1,isLegend=true
                        ))
                    }
                }
            }
        }

    private fun Cursor.region()=RegionHit(getString(0),getString(1),getString(2).orEmpty(),getDouble(3),getDouble(4))
    private fun Cursor.poi(isLegend:Boolean)=ResultItem(
        id=getLong(0),name=getString(1),categoryKey=getString(2),
        province=getString(3).orEmpty(),district=getString(4).orEmpty(),
        address=getString(5).orEmpty(),detail=getString(6).orEmpty(),
        source=getString(7).orEmpty(),sourceUrl=getString(8).orEmpty(),
        matchNote=getString(9).orEmpty(),routeQuery=getString(10).orEmpty(),
        rankScore=getDouble(11),sourceCount=getInt(12),curated=getInt(13)==1,isLegend=isLegend
    )
}
