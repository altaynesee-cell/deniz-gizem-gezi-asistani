package com.altay.denizgizem

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity:ComponentActivity(){
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{App()}}
}
private val Deep=Color(0xFF075E61)
private val Sea=Color(0xFF168F92)
private val Warm=Color(0xFFF4B942)
private val Bg=Color(0xFFF5F8F8)

@Composable
fun App(){
    val context=LocalContext.current
    var group by rememberSaveable{mutableStateOf(Group.DISCOVER)}
    var selectedKey by rememberSaveable{mutableStateOf("gizem")}
    var regionText by rememberSaveable{mutableStateOf("Tarsus")}
    var region by remember{mutableStateOf<RegionHit?>(null)}
    var results by remember{mutableStateOf<List<ResultItem>>(emptyList())}
    var searched by remember{mutableStateOf(false)}
    var loading by remember{mutableStateOf(false)}
    var serial by remember{mutableIntStateOf(0)}
    var dataset by remember{mutableStateOf("V14 Türkiye verisi")}

    LaunchedEffect(Unit){
        Thread{
            val x=runCatching{OfflineDb.metadata(context)}.getOrDefault("V14 Türkiye verisi")
            Handler(Looper.getMainLooper()).post{dataset=x}
        }.start()
    }

    fun invalidate(){serial++;loading=false;results=emptyList();searched=false}
    fun search(){
        if(regionText.isBlank()||loading)return
        val mySerial=serial+1;serial=mySerial
        val q=regionText.trim();val key=selectedKey
        loading=true;searched=true;results=emptyList()
        Thread{
            val pair=runCatching{OfflineDb.search(context,q,key,40)}.getOrElse{null to emptyList()}
            Handler(Looper.getMainLooper()).post{
                if(serial==mySerial&&regionText.trim()==q&&selectedKey==key){
                    region=pair.first;results=pair.second.filter{it.categoryKey==key};loading=false
                }
            }
        }.start()
    }

    MaterialTheme(colorScheme=lightColorScheme(primary=Deep,secondary=Sea,tertiary=Warm,background=Bg)){
        Scaffold(containerColor=Bg,bottomBar={
            NavigationBar(containerColor=Color.White){
                Group.entries.forEach{g->
                    NavigationBarItem(selected=group==g,onClick={
                        invalidate();group=g;selectedKey=Categories.forGroup(g).first().key
                    },icon={Text(g.emoji,fontSize=20.sp)},label={Text(g.title)})
                }
            }
        }){pad->
            LazyColumn(Modifier.fillMaxSize().padding(pad),contentPadding=PaddingValues(bottom=24.dp)){
                item{Hero(dataset);SearchCard(group,selectedKey,{invalidate();selectedKey=it},regionText,{invalidate();regionText=it},loading){search()}}
                if(searched)item{Status(loading,region,results.size)}
                if(!loading&&searched&&results.isEmpty())item{
                    Empty(
                        if(region==null)"İl/ilçe bulunamadı. Yazımı kontrol et."
                        else if(selectedKey=="gizem")
                            "Bu bölgede kaynaklı efsane/menkıbe kaydı bulunamadı. Uygulama hikâye uydurmuyor."
                        else "Bu kategori için doğrulanmış kayıt bulunamadı."
                    )
                }
                if(results.isNotEmpty()){
                    item{
                        val food=Categories.byKey(selectedKey).group==Group.FOOD
                        Title(if(selectedKey=="gizem")"Efsaneler ve yerel anlatılar" else if(food)"Yerel tavsiyeler" else "Bulunan yerler",
                            if(selectedKey=="gizem")"Kısa özet + kaynak. İlçe aramasında önce ilçeye ait anlatılar gösterilir."
                            else "Aynı bölge ve seçili kategori dışındaki sonuçlar ekrana giremez.")
                    }
                    itemsIndexed(results,key={_,x->"${x.id}-${x.categoryKey}"}){i,x->ResultCard(i,x,selectedKey)}
                }
            }
        }
    }
}

@Composable private fun Hero(dataset:String){
    Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Deep,Sea)),RoundedCornerShape(bottomStart=30.dp,bottomEnd=30.dp)).padding(20.dp)){
        Column{
            Text("DENİZ GİZEM",color=Color.White,fontSize=28.sp,fontWeight=FontWeight.Black)
            Text("V14 • 81 İL + İLÇELER",color=Color.White.copy(.95f),fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("Türkiye'nin neresini yazarsan o bölgenin kendi verisi aranır. Arama çevrimdışıdır.",color=Color.White.copy(.84f))
            Spacer(Modifier.height(5.dp));Text(dataset,color=Color.White.copy(.68f),style=MaterialTheme.typography.labelSmall)
        }
    }
}
@Composable private fun SearchCard(group:Group,key:String,onKey:(String)->Unit,region:String,onRegion:(String)->Unit,loading:Boolean,onSearch:()->Unit){
    Card(Modifier.fillMaxWidth().padding(16.dp),shape=RoundedCornerShape(24.dp),elevation=CardDefaults.cardElevation(3.dp)){
        Column(Modifier.padding(16.dp)){
            Text("${group.emoji} ${group.title}",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value=region,onValueChange=onRegion,modifier=Modifier.fillMaxWidth(),singleLine=true,
                label={Text("İl / İlçe")},placeholder={Text("Tarsus, Bursa, Denizli, Burdur…")},shape=RoundedCornerShape(16.dp),
                keyboardOptions=KeyboardOptions(imeAction=ImeAction.Search),keyboardActions=KeyboardActions(onSearch={onSearch()}))
            Spacer(Modifier.height(10.dp))
            Categories.forGroup(group).chunked(2).forEach{row->
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    row.forEach{c->FilterChip(selected=key==c.key,onClick={onKey(c.key)},label={Text("${c.emoji} ${c.title}")},modifier=Modifier.weight(1f))}
                    if(row.size==1)Spacer(Modifier.weight(1f))
                };Spacer(Modifier.height(5.dp))
            }
            Button(onClick=onSearch,enabled=!loading&&region.isNotBlank(),modifier=Modifier.fillMaxWidth().height(54.dp),shape=RoundedCornerShape(16.dp)){
                if(loading){CircularProgressIndicator(Modifier.size(19.dp),strokeWidth=2.dp,color=Color.White);Spacer(Modifier.width(8.dp));Text("ARANIYOR…")}
                else Text("⚡ TÜRKİYE VERİTABANINDA ARA",fontWeight=FontWeight.Bold)
            }
        }
    }
}
@Composable private fun Status(loading:Boolean,r:RegionHit?,count:Int){
    val s=when{loading->"Telefondaki veritabanı aranıyor…";r==null->"Bölge bulunamadı";else->"✅ ${r.name} • $count sonuç"}
    Surface(Modifier.fillMaxWidth().padding(horizontal=16.dp),shape=RoundedCornerShape(16.dp),color=if(r!=null)Color(0xFFE7F5F3)else Color(0xFFFFF5DE)){Text(s,Modifier.padding(14.dp))}
}
@Composable private fun Title(a:String,b:String){Column(Modifier.padding(horizontal=18.dp,vertical=14.dp)){Text(a,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);Text(b,style=MaterialTheme.typography.bodySmall,color=Color(0xFF607779))}}
@Composable private fun Empty(s:String){Surface(Modifier.fillMaxWidth().padding(16.dp),shape=RoundedCornerShape(20.dp)){Text(s,Modifier.padding(18.dp))}}

@Composable private fun ResultCard(index:Int,x:ResultItem,key:String){
    val context=LocalContext.current
    val food=Categories.byKey(key).group==Group.FOOD
    Card(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=7.dp),shape=RoundedCornerShape(22.dp),
        colors=CardDefaults.cardColors(containerColor=if(index==0&&food)Color(0xFFFFFBEE)else Color.White)){
        Column(Modifier.padding(16.dp)){
            if(index==0&&food){
                Text(if(x.curated||x.sourceCount>=2)"⭐ KAYNAKLARLA ÖNE ÇIKAN TAVSİYE" else "⭐ ÖNE ÇIKAN YEREL TAVSİYE",color=Deep,fontWeight=FontWeight.Black)
                Spacer(Modifier.height(5.dp))
            }
            Text(x.name,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
            val loc=listOf(x.district,x.province).filter{it.isNotBlank()}.distinct().joinToString(", ")
            if(loc.isNotBlank())Text(loc,style=MaterialTheme.typography.bodySmall,color=Color(0xFF5E7476))
            if(x.address.isNotBlank()){Spacer(Modifier.height(5.dp));Text("📍 ${x.address}",style=MaterialTheme.typography.bodySmall)}
            if(x.detail.isNotBlank()){Spacer(Modifier.height(9.dp));Text((if(x.isLegend)"📖 KISA ÖZET\n" else "")+x.detail)}
            if(x.matchNote.isNotBlank()){Spacer(Modifier.height(7.dp));Text(x.matchNote,color=Deep,style=MaterialTheme.typography.labelMedium)}
            if(x.source.isNotBlank()){Spacer(Modifier.height(6.dp));Text("Kaynak: ${x.source}",style=MaterialTheme.typography.labelSmall,color=Color(0xFF6D8587))}
            if(x.routeQuery.isNotBlank()){
                Spacer(Modifier.height(12.dp))
                FilledTonalButton(onClick={
                    val i=Intent(Intent.ACTION_VIEW,Uri.parse("geo:0,0?q=${Uri.encode(x.routeQuery)}"))
                    context.startActivity(Intent.createChooser(i,"Yol tarifi"))
                },modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){Text("🧭 YOL TARİFİ")}
            }
        }
    }
}
