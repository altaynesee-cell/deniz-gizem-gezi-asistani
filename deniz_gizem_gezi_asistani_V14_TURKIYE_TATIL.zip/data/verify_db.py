#!/usr/bin/env python3
import argparse,json,re,sqlite3,unicodedata
from pathlib import Path
HERE=Path(__file__).resolve().parent
M=json.loads((HERE/"provinces.json").read_text(encoding="utf-8"))
PROVS=M["provinces"]
def norm(s):
    s=(s or "").lower().replace("ı","i").replace("ğ","g").replace("ü","u").replace("ş","s").replace("ö","o").replace("ç","c")
    s=unicodedata.normalize("NFD",s);s="".join(ch for ch in s if unicodedata.category(ch)!="Mn")
    return re.sub(r"[^a-z0-9]+"," ",s).strip()
ap=argparse.ArgumentParser();ap.add_argument("db");ap.add_argument("--strict",action="store_true");a=ap.parse_args()
db=sqlite3.connect(a.db)
regions=db.execute("select count(*) from regions").fetchone()[0]
province_names={r[0] for r in db.execute("select name from regions where kind='province'")}
missing_prov=[p for p in PROVS if p not in province_names]
districts=db.execute("select count(*) from regions where kind='district'").fetchone()[0]
poi=db.execute("select count(*) from poi").fetchone()[0]
cats=dict(db.execute("select category_key,count(*) from poi group by category_key"))
legends=db.execute("select count(*) from legends").fetchone()[0]
leg_prov=db.execute("select count(distinct province_norm) from legends").fetchone()[0]
bad_names=db.execute("""select count(*) from poi where length(trim(name))<3 or lower(trim(name)) in ('restaurant','restoran','cafe','kafe','hotel','otel','market','unnamed','isimsiz')""").fetchone()[0]
tarsus_antik=db.execute("select count(*) from poi where category_key='antik' and district_norm=?",(norm("Tarsus"),)).fetchone()[0]
tarsus_kofte=db.execute("select count(*) from poi where category_key='kofte' and district_norm=?",(norm("Tarsus"),)).fetchone()[0]
sah=db.execute("select count(*) from legends where province_norm=? and (district_norm=? or district_norm='') and title_norm like '%sahmaran%'",(norm("Mersin"),norm("Tarsus"))).fetchone()[0]
bursa_leg=db.execute("select count(*) from legends where province_norm=?",(norm("Bursa"),)).fetchone()[0]
required=["ciger","kofte","kebap","sulu","tavuk","esnaf","balik","kahvalti","plaj","kum","koy","antik","kale","magara","muze","tarihi","pansiyon","apart","otel","kamp"]
missing_cat=[x for x in required if cats.get(x,0)==0]
summary={"provinces":len(province_names),"missing_provinces":missing_prov,"districts":districts,"poi":poi,"categories":cats,"legends":legends,"legend_province_coverage":leg_prov,"bad_names":bad_names,"tarsus_antik":tarsus_antik,"tarsus_kofte":tarsus_kofte,"tarsus_sahmaran":sah,"bursa_legends":bursa_leg}
print(json.dumps(summary,ensure_ascii=False,indent=2))
if missing_prov:raise SystemExit("81 il tam değil: "+",".join(missing_prov))
if tarsus_antik<3:raise SystemExit("Tarsus antik regresyonu")
if tarsus_kofte<1:raise SystemExit("Tarsus köfte regresyonu")
if sah<1:raise SystemExit("Tarsus Şahmaran regresyonu")
if bursa_leg<2:raise SystemExit("Bursa gizem/efsane regresyonu")
if a.strict:
    if len(province_names)!=81:raise SystemExit("İl sayısı 81 değil")
    if districts<900:raise SystemExit(f"İlçe kapsamı yetersiz: {districts}")
    if poi<20000:raise SystemExit(f"POI veritabanı çok küçük: {poi}")
    if missing_cat:raise SystemExit("Boş ana kategori: "+",".join(missing_cat))
    if bad_names>0:raise SystemExit(f"İsimsiz/generic sonuç var: {bad_names}")
    if legends<150:raise SystemExit(f"Efsane/kültür indeksi küçük: {legends}")
    if leg_prov<55:raise SystemExit(f"Efsane il kapsamı yetersiz: {leg_prov}/81")
db.close()
