OpenAI anahtarını Android APK'ya koymayın. Sunucuda OPENAI_API_KEY secret olarak tanımlayın.
