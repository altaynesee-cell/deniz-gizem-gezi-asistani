import http from "node:http";
const PORT=Number(process.env.PORT||8787), KEY=process.env.OPENAI_API_KEY, MODEL=process.env.OPENAI_MODEL||"gpt-5.6";
const ALLOWED=new Set(["ciger","kofte","kebap","sulu yemek","tavuk","esnaf lokantası","balık","kahvaltı","plaj","kumlu sığ plaj","sakin koy","antik kent","kale hisar sur","mağara","müze","tarihi yer","gizem efsane","pansiyon","apart","otel","kamp"]);
const send=(r,c,o)=>{r.writeHead(c,{"content-type":"application/json; charset=utf-8","access-control-allow-origin":"*"});r.end(JSON.stringify(o));};
async function body(req){let s="";for await(const x of req)s+=x;return JSON.parse(s||"{}");}
function outText(x){for(const i of x.output||[])if(i.type==="message")for(const c of i.content||[])if(c.type==="output_text")return c.text||"";return "";}
function extract(s){s=s.trim().replace(/^```json/i,"").replace(/```$/,"").trim();return JSON.parse(s.slice(s.indexOf("{"),s.lastIndexOf("}")+1));}
function prompt(region,cat){return `Türkiye yerel gezi araştırmacısısın. Bölge: ${region}. Kategori: ${cat}.
Canlı web'de geniş araştırma yap. Harita puanı tek kriter olmasın.
YEMEK: yerel halk/esnafın bildiği, köklü, meşhur, salaş, zincir olmayan ve makul fiyatlı yerleri öne çıkar. "En eski/köklü/meşhur" iddiası için mümkünse 2 bağımsız kaynak kullan; doğrulanmıyorsa kuruluş yılı uydurma.
BÖLGE KİLİDİ: kullanıcı il yazdıysa o ilin ilçeleri dahil, başka il yasak. Bursa+plaj için Mudanya/Gemlik/Karacabey gibi Bursa kıyılarını araştır; Alanya/Antalya yasak.
KALE: kale/hisar/sur/fort/castle semantik olarak araştır.
MAĞARA: gerçek mağara/doğal oluşum; mağara adlı kafe/otel yasak.
PLAJ: gerçek plaj/koy/yüzme noktası; market/banka/otel/restoran yasak.
GİZEM: fiziksel yer + doğrulanabilir efsane/tarih bağlantısı.
Bodrum+ciğer aramasında Ciğerci Yasin gibi yerel adayları web kaynakları doğruluyorsa değerlendir; tek sağlayıcıda görünmüyor diye eleme.
Daha az ama doğru sonuç daha iyi. En iyi 5-8 sonucu ver.
SADECE JSON:
{"summary":"kısa özet","places":[{"name":"","area":"","address":"","why":"","evidence":"","established":"","price":"","route_query":"","confidence":0.0,"sources":[""]}]}`;}
async function search(region,cat){if(!KEY)throw new Error("OPENAI_API_KEY eksik");const r=await fetch("https://api.openai.com/v1/responses",{method:"POST",headers:{authorization:`Bearer ${KEY}`,"content-type":"application/json"},body:JSON.stringify({model:MODEL,reasoning:{effort:"medium"},tools:[{type:"web_search",search_context_size:"medium"}],tool_choice:"required",input:prompt(region,cat)})});const d=await r.json();if(!r.ok)throw new Error(d?.error?.message||`OpenAI HTTP ${r.status}`);const j=extract(outText(d));j.places=(j.places||[]).slice(0,8);return j;}
http.createServer(async(req,res)=>{if(req.method==="GET"&&req.url==="/health")return send(res,200,{ok:true,model:MODEL});if(req.method==="POST"&&req.url==="/search"){try{const b=await body(req),region=String(b.region||"").trim(),cat=String(b.category||"").trim();if(region.length<2)return send(res,400,{error:"Bölge geçersiz"});if(!ALLOWED.has(cat))return send(res,400,{error:"Kategori geçersiz"});return send(res,200,await search(region,cat));}catch(e){return send(res,500,{error:e.message||"hata"});}}return send(res,404,{error:"yok"});}).listen(PORT,"0.0.0.0",()=>console.log("V8 AI server",PORT));
