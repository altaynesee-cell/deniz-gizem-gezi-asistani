plugins { id("com.android.application") }
android {
    namespace = "com.altay.denizgizem"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.altay.denizgizem"
        minSdk = 26
        targetSdk = 35
        versionCode = 30
        versionName = "8.0-ai-web"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
