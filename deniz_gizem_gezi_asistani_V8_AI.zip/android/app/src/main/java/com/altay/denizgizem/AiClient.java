package com.altay.denizgizem;
import java.io.*;import java.net.*;import java.nio.charset.StandardCharsets;import java.util.*;
public final class AiClient{
 public static final class Place{public String name="",area="",address="",why="",evidence="",established="",price="",routeQuery="";public double confidence;public List<String>sources=new ArrayList<>();}
 public static final class Result{public String summary="";public List<Place>places=new ArrayList<>();}
 public static Result search(String base,String region,String category)throws Exception{
   String u=base.trim();if(u.endsWith("/"))u=u.substring(0,u.length()-1);u+="/search";
   HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setRequestMethod("POST");c.setDoOutput(true);c.setConnectTimeout(15000);c.setReadTimeout(65000);c.setRequestProperty("Content-Type","application/json");
   String b="{\"region\":"+qq(region)+",\"category\":"+qq(category)+"}";try(OutputStream o=c.getOutputStream()){o.write(b.getBytes(StandardCharsets.UTF_8));}
   int code=c.getResponseCode();String t=read(code>=200&&code<300?c.getInputStream():c.getErrorStream());c.disconnect();if(code<200||code>=300)throw new IOException("HTTP "+code+" "+t);return parse(t);
 }
 @SuppressWarnings("unchecked") public static Result parse(String t){Map<String,Object>m=(Map<String,Object>)MiniJson.parse(t);Result r=new Result();r.summary=s(m.get("summary"));Object a=m.get("places");if(a instanceof List)for(Object o:(List<Object>)a){Map<String,Object>x=(Map<String,Object>)o;Place p=new Place();p.name=s(x.get("name"));p.area=s(x.get("area"));p.address=s(x.get("address"));p.why=s(x.get("why"));p.evidence=s(x.get("evidence"));p.established=s(x.get("established"));p.price=s(x.get("price"));p.routeQuery=s(x.get("route_query"));Object cf=x.get("confidence");if(cf instanceof Number)p.confidence=((Number)cf).doubleValue();if(!p.name.isEmpty())r.places.add(p);}return r;}
 private static String read(InputStream in)throws IOException{if(in==null)return "";try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){StringBuilder b=new StringBuilder();String l;while((l=r.readLine())!=null)b.append(l);return b.toString();}}
 private static String qq(String s){return "\""+s.replace("\\","\\\\").replace("\"","\\\"")+"\"";}private static String s(Object o){return o==null?"":String.valueOf(o);}
}
