package com.altay.denizgizem;
import java.util.*;
public final class MiniJson{
 private final String s;private int p;private MiniJson(String s){this.s=s;}
 public static Object parse(String s){return new MiniJson(s).v();}
 private Object v(){w();char c=s.charAt(p);if(c=='{')return o();if(c=='[')return a();if(c=='"')return q();if(c=='t'){p+=4;return true;}if(c=='f'){p+=5;return false;}if(c=='n'){p+=4;return null;}return n();}
 private Map<String,Object>o(){Map<String,Object>m=new LinkedHashMap<>();p++;w();if(s.charAt(p)=='}'){p++;return m;}while(true){String k=q();w();p++;m.put(k,v());w();char c=s.charAt(p++);if(c=='}')return m;w();}}
 private List<Object>a(){List<Object>x=new ArrayList<>();p++;w();if(s.charAt(p)==']'){p++;return x;}while(true){x.add(v());w();char c=s.charAt(p++);if(c==']')return x;w();}}
 private String q(){w();p++;StringBuilder b=new StringBuilder();while(true){char c=s.charAt(p++);if(c=='"')return b.toString();if(c=='\\'){char e=s.charAt(p++);if(e=='n')b.append('\n');else if(e=='r')b.append('\r');else if(e=='t')b.append('\t');else if(e=='u'){b.append((char)Integer.parseInt(s.substring(p,p+4),16));p+=4;}else b.append(e);}else b.append(c);}}
 private Number n(){int st=p;while(p<s.length()&&"-+.eE0123456789".indexOf(s.charAt(p))>=0)p++;String x=s.substring(st,p);return x.contains(".")?Double.parseDouble(x):Long.parseLong(x);}
 private void w(){while(p<s.length()&&Character.isWhitespace(s.charAt(p)))p++;}
}
