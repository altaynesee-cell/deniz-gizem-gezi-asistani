package com.altay.denizgizem

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DenizGizemApp() }
    }
}

private val DeepTeal = Color(0xFF075E61)
private val Sea = Color(0xFF0E8B8F)
private val Warm = Color(0xFFF4B942)
private val SoftBg = Color(0xFFF4F8F8)
private val Ink = Color(0xFF14282A)

@Composable
fun DenizGizemApp() {
    var group by remember { mutableStateOf(Group.FOOD) }
    var region by rememberSaveable { mutableStateOf("Bodrum") }
    var selectedKey by rememberSaveable { mutableStateOf("ciger") }
    var bundle by remember { mutableStateOf<SearchBundle?>(null) }
    var loading by remember { mutableStateOf(false) }
    var hasSearched by remember { mutableStateOf(false) }
    var requestSerial by remember { mutableIntStateOf(0) }

    val selected = remember(selectedKey) { Categories.byKey(selectedKey) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = DeepTeal,
            secondary = Sea,
            tertiary = Warm,
            background = SoftBg,
            surface = Color.White,
            onPrimary = Color.White,
            onBackground = Ink,
            onSurface = Ink
        )
    ) {
        Scaffold(
            containerColor = SoftBg,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    Group.entries.forEach { g ->
                        NavigationBarItem(
                            selected = group == g,
                            onClick = {
                                requestSerial += 1
                                loading = false
                                group = g
                                val first = Categories.forGroup(g).first()
                                selectedKey = first.key
                                bundle = null
                                hasSearched = false
                            },
                            icon = { Text(g.emoji, fontSize = 20.sp) },
                            label = { Text(g.title) }
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                item {
                    HeroHeader()
                    SearchPanel(
                        region = region,
                        onRegionChange = {
                            requestSerial += 1
                            loading = false
                            region = it
                            bundle = null
                            hasSearched = false
                        },
                        group = group,
                        selectedKey = selectedKey,
                        onCategory = {
                            requestSerial += 1
                            loading = false
                            selectedKey = it
                            bundle = null
                            hasSearched = false
                        },
                        loading = loading,
                        onSearch = {
                            if (region.isNotBlank() && !loading) {
                                val searchRegion = region.trim()
                                val cat = Categories.byKey(selectedKey)
                                val myRequest = requestSerial + 1
                                requestSerial = myRequest

                                bundle = PlaceRepository.offline(searchRegion, cat)
                                hasSearched = true
                                loading = true
                                Thread {
                                    val enriched = PlaceRepository.enrich(searchRegion, cat)
                                    Handler(Looper.getMainLooper()).post {
                                        if (
                                            requestSerial == myRequest &&
                                            enriched.regionKey == TextNorm.norm(region.trim()) &&
                                            enriched.categoryKey == selectedKey
                                        ) {
                                            bundle = enriched
                                            loading = false
                                        }
                                    }
                                }.start()
                            }
                        }
                    )
                }

                val visibleBundle = bundle?.takeIf {
                    it.regionKey == TextNorm.norm(region.trim()) &&
                    it.categoryKey == selectedKey
                }

                item {
                    AnimatedVisibility(visible = loading || visibleBundle != null) {
                        StatusCard(visibleBundle, loading)
                    }
                }

                val data = visibleBundle?.items.orEmpty()
                    .filter { it.categoryKey == selectedKey }

                if (hasSearched && data.isEmpty() && !loading) {
                    item {
                        EmptyCard(
                            "Bu bölge/kategori için güvenilir sonuç bulamadım. " +
                            "Yanlış işletme göstermek yerine boş bırakıyorum."
                        )
                    }
                }

                if (data.isNotEmpty()) {
                    item {
                        SectionTitle(
                            title = if (data.any { it.verified }) "Akıllı sıralama" else "Canlı sonuçlar",
                            subtitle = "Doğrulanmış yerel kayıtlar önce; sonra güvenli canlı eşleşmeler"
                        )
                    }

                    itemsIndexed(data, key = { _, item -> item.name + item.area }) { index, item ->
                        PlaceCard(index + 1, item)
                    }
                }

                item {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Ücretsiz mod • Kart yok • API anahtarı yok • © OpenStreetMap katkıcıları",
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF668082)
                    )
                }
            }
        }
    }
}

@Composable
private fun HeroHeader() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.linearGradient(listOf(DeepTeal, Sea)),
                RoundedCornerShape(bottomStart = 30.dp, bottomEnd = 30.dp)
            )
            .padding(horizontal = 20.dp, vertical = 26.dp)
    ) {
        Column {
            Text(
                "DENİZ GİZEM",
                color = Color.White,
                fontSize = 27.sp,
                fontWeight = FontWeight.Black
            )
            Text(
                "Gezi Asistanı • V10.4 STABİL",
                color = Color.White.copy(alpha = .92f),
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Önce doğrulanmış yerel favoriler. İnternet varsa canlı ek sonuçlar. " +
                    "Servis bozulsa bile temel sonuçlar kaybolmaz.",
                color = Color.White.copy(alpha = .82f),
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
private fun SearchPanel(
    region: String,
    onRegionChange: (String) -> Unit,
    group: Group,
    selectedKey: String,
    onCategory: (String) -> Unit,
    loading: Boolean,
    onSearch: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                "${group.emoji} ${group.title}",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(10.dp))

            OutlinedTextField(
                value = region,
                onValueChange = onRegionChange,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Bölge") },
                placeholder = { Text("Bodrum, Bursa, Antalya…") },
                shape = RoundedCornerShape(16.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onSearch() })
            )

            Spacer(Modifier.height(12.dp))
            Text("Ne arıyorsun?", style = MaterialTheme.typography.labelLarge)

            Spacer(Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Categories.forGroup(group).chunked(2).forEach { row ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        row.forEach { c ->
                            FilterChip(
                                selected = selectedKey == c.key,
                                onClick = { onCategory(c.key) },
                                label = { Text("${c.emoji} ${c.title}") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            Button(
                onClick = onSearch,
                enabled = region.isNotBlank() && !loading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                if (loading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp,
                        color = Color.White
                    )
                    Spacer(Modifier.width(10.dp))
                    Text("Canlı sonuçlar ekleniyor…")
                } else {
                    Text("AKILLI ARA", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun StatusCard(bundle: SearchBundle?, loading: Boolean) {
    val text = when {
        loading && bundle != null -> "${bundle.status}. Canlı kaynaklar güvenli şekilde kontrol ediliyor…"
        loading -> "Arama hazırlanıyor…"
        bundle != null -> bundle.status
        else -> ""
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 2.dp),
        shape = RoundedCornerShape(16.dp),
        color = if (bundle?.liveOk == false && !loading) Color(0xFFFFF5DE) else Color(0xFFE8F5F4)
    ) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(if (loading) "⏳" else if (bundle?.liveOk == false) "🛡️" else "✅")
            Spacer(Modifier.width(10.dp))
            Text(text, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Color(0xFF607779))
    }
}

@Composable
private fun PlaceCard(rank: Int, item: PlaceItem) {
    val context = LocalContext.current

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 7.dp),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (item.verified) Color(0xFFFFFCF3) else Color.White
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (item.verified) 3.dp else 1.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            if (rank == 1 && item.group == Group.FOOD) {
                Text(
                    "⭐ EN MEŞHUR / KÖKLÜ TAVSİYE",
                    color = DeepTeal,
                    fontWeight = FontWeight.Black,
                    style = MaterialTheme.typography.labelLarge
                )
                Spacer(Modifier.height(8.dp))
            }
            if (item.group == Group.DISCOVER && item.categoryKey == "gizem") {
                Text(
                    "📖 KISA HİKÂYE",
                    color = DeepTeal,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelLarge
                )
                Spacer(Modifier.height(8.dp))
            }
            Row(verticalAlignment = Alignment.Top) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (rank == 1) Warm else Color(0xFFE2EEEE)
                ) {
                    Text(
                        if (rank == 1) "🏆" else "#$rank",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(item.area, style = MaterialTheme.typography.bodySmall, color = Color(0xFF5A7173))
                }
            }

            if (item.established.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text("📅 ${item.established}", fontWeight = FontWeight.SemiBold, color = DeepTeal)
            }

            Spacer(Modifier.height(8.dp))
            if (item.why.isNotBlank()) {
                Text(item.why, style = MaterialTheme.typography.bodyMedium)
            }

            if (item.tags.isNotEmpty()) {
                Spacer(Modifier.height(9.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    item.tags.take(3).forEach { tag ->
                        SuggestionChip(onClick = {}, label = { Text(tag) })
                    }
                }
            }

            if (item.sourceLabel.isNotBlank()) {
                Spacer(Modifier.height(7.dp))
                Text(
                    "Kaynak: ${item.sourceLabel}",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF6E8587)
                )
            }

            item.distanceKm?.let {
                Spacer(Modifier.height(4.dp))
                Text(
                    String.format(Locale.getDefault(), "Merkezden yaklaşık %.1f km", it),
                    style = MaterialTheme.typography.labelMedium
                )
            }

            Spacer(Modifier.height(12.dp))
            FilledTonalButton(
                onClick = {
                    val q = if (item.routeQuery.isNotBlank()) item.routeQuery else "${item.name} ${item.area}"
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=${Uri.encode(q)}"))
                    context.startActivity(Intent.createChooser(intent, "Yol tarifi"))
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("🧭 YOL TARİFİ")
            }
        }
    }
}

@Composable
private fun EmptyCard(text: String) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(20.dp),
        color = Color.White
    ) {
        Text(text, modifier = Modifier.padding(18.dp))
    }
}
