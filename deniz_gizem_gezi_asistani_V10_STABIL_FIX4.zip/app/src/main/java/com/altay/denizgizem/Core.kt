package com.altay.denizgizem

import java.text.Normalizer
import java.util.Locale
import kotlin.math.max

enum class Group(val title: String, val emoji: String) {
    FOOD("Lezzet", "🍽"),
    SEA("Deniz", "🌊"),
    DISCOVER("Keşfet", "🏛"),
    STAY("Konak", "🛏")
}

data class CategorySpec(
    val key: String,
    val title: String,
    val emoji: String,
    val group: Group,
    val strictType: String
)

data class PlaceItem(
    val name: String,
    val categoryKey: String,
    val group: Group,
    val area: String,
    val address: String = "",
    val why: String = "",
    val tags: List<String> = emptyList(),
    val established: String = "",
    val sourceLabel: String = "",
    val routeQuery: String = "",
    val verified: Boolean = false,
    val fameScore: Int = 0,
    val localScore: Int = 0,
    val typeScore: Int = 0,
    val distanceKm: Double? = null,
    val lat: Double? = null,
    val lon: Double? = null,
    val live: Boolean = false
) {
    fun smartScore(): Int {
        val verifiedBoost = if (verified) 80 else 0
        val fame = fameScore * 4
        val local = localScore * 3
        val type = typeScore * 5
        val history = if (established.isNotBlank()) 20 else 0
        val livePenalty = if (live) 2 else 0
        val recommendation = if (tags.any { it.contains("İlk tavsiye", ignoreCase = true) }) 50 else 0
        return verifiedBoost + fame + local + type + history + recommendation - livePenalty
    }
}

data class RegionBounds(
    val canonical: String,
    val south: Double,
    val west: Double,
    val north: Double,
    val east: Double,
    val centerLat: Double,
    val centerLon: Double
) {
    fun contains(lat: Double, lon: Double): Boolean =
        lat in south..north && lon in west..east
}

object TextNorm {
    fun norm(s: String): String {
        val lower = s.lowercase(Locale.forLanguageTag("tr-TR"))
            .replace('ı', 'i').replace('ğ', 'g').replace('ü', 'u')
            .replace('ş', 's').replace('ö', 'o').replace('ç', 'c')
        return Normalizer.normalize(lower, Normalizer.Form.NFD)
            .replace("\\p{M}".toRegex(), "")
            .replace("[^a-z0-9]+".toRegex(), " ")
            .trim()
    }
}

object Categories {
    val all = listOf(
        CategorySpec("ciger", "Ciğer / Arnavut", "🥩", Group.FOOD, "food"),
        CategorySpec("kofte", "Köfte", "🧆", Group.FOOD, "food"),
        CategorySpec("kebap", "Kebap", "🔥", Group.FOOD, "food"),
        CategorySpec("sulu", "Sulu Yemek", "🍲", Group.FOOD, "food"),
        CategorySpec("tavuk", "Tavuk", "🍗", Group.FOOD, "food"),
        CategorySpec("esnaf", "Esnaf Lokantası", "🥘", Group.FOOD, "food"),
        CategorySpec("balik", "Balık", "🐟", Group.FOOD, "food"),
        CategorySpec("kahvalti", "Kahvaltı", "🍳", Group.FOOD, "food"),

        CategorySpec("plaj", "Plaj", "🏖", Group.SEA, "beach"),
        CategorySpec("kum", "Kumlu / Sığ", "👣", Group.SEA, "beach"),
        CategorySpec("koy", "Koy", "🌊", Group.SEA, "bay"),

        CategorySpec("antik", "Antik Kent", "🏺", Group.DISCOVER, "archaeological"),
        CategorySpec("kale", "Kale / Hisar", "🏰", Group.DISCOVER, "castle"),
        CategorySpec("magara", "Mağara", "🕳", Group.DISCOVER, "cave"),
        CategorySpec("muze", "Müze", "🏛", Group.DISCOVER, "museum"),
        CategorySpec("tarihi", "Tarihi Yer", "📜", Group.DISCOVER, "historic"),
        CategorySpec("gizem", "Gizem / Efsane", "👁", Group.DISCOVER, "curated"),

        CategorySpec("pansiyon", "Pansiyon", "🏡", Group.STAY, "guest_house"),
        CategorySpec("apart", "Apart", "🏢", Group.STAY, "apartment"),
        CategorySpec("otel", "Otel", "🏨", Group.STAY, "hotel"),
        CategorySpec("kamp", "Kamp", "⛺", Group.STAY, "camp")
    )

    fun byKey(key: String): CategorySpec = all.first { it.key == key }
    fun forGroup(group: Group): List<CategorySpec> = all.filter { it.group == group }
}

object OfflineCatalog {
    private fun p(
        name: String, key: String, group: Group, area: String,
        why: String, tags: List<String>, source: String,
        established: String = "", fame: Int = 7, local: Int = 8, type: Int = 10,
        address: String = "", route: String = ""
    ) = PlaceItem(
        name = name, categoryKey = key, group = group, area = area,
        address = address, why = why, tags = tags, established = established,
        sourceLabel = source, routeQuery = if (route.isBlank()) "$name $area" else route,
        verified = true, fameScore = fame, localScore = local, typeScore = type
    )

    private val items = listOf(
        // BURSA / PLAJ — official municipal sources, so it works offline and doesn't return Alanya.
        p("Kurşunlu Halk Plajı", "plaj", Group.SEA, "Karacabey, Bursa",
            "Bursa Büyükşehir'in sahil ve Mavi Bayrak çalışmalarında öne çıkan halk plajı.",
            listOf("Doğrulanmış", "Bursa", "Halk plajı"), "Bursa Büyükşehir Belediyesi", fame=9, local=9),
        p("Malkara Halk Plajı", "plaj", Group.SEA, "Karacabey, Bursa",
            "Bursa kıyılarında belediye tarafından düzenlenen ve öne çıkarılan plajlardan.",
            listOf("Doğrulanmış", "Bursa", "Plaj"), "Bursa Büyükşehir Belediyesi", fame=8, local=9),
        p("Eşkel Halk Plajı", "plaj", Group.SEA, "Mudanya, Bursa",
            "Mudanya sahil hattında uzun kumsalıyla bilinen halk plajlarından.",
            listOf("Doğrulanmış", "Mudanya", "Kumsal"), "Bursa Büyükşehir Belediyesi", fame=8, local=10),
        p("Eğerce Plajı", "plaj", Group.SEA, "Mudanya, Bursa",
            "Bursa Büyükşehir'in sezon hazırlıklarında adı geçen Mudanya plajlarından.",
            listOf("Doğrulanmış", "Mudanya"), "Bursa Büyükşehir Belediyesi", fame=7, local=9),
        p("Mesudiye Plajı", "plaj", Group.SEA, "Mudanya, Bursa",
            "Mudanya kıyı şeridindeki bilinen plajlardan.",
            listOf("Doğrulanmış", "Mudanya"), "Bursa Büyükşehir Belediyesi", fame=7, local=9),
        p("Kumsaz Plajı", "plaj", Group.SEA, "Gemlik, Bursa",
            "Gemlik sahilindeki uzun ve geniş kumsallı plajlardan.",
            listOf("Doğrulanmış", "Gemlik", "Kumsal"), "Bursa Büyükşehir Belediyesi", fame=8, local=9),
        p("Narlı Halk Plajı", "plaj", Group.SEA, "Gemlik, Bursa",
            "Gemlik kıyısındaki halk plajlarından.",
            listOf("Doğrulanmış", "Gemlik"), "Bursa Büyükşehir Belediyesi", fame=7, local=9),
        p("Mudanya Plajı", "plaj", Group.SEA, "Mudanya, Bursa",
            "Mudanya merkezde belediye tesisiyle hizmet veren plaj.",
            listOf("Doğrulanmış", "Mudanya", "Merkez"), "Bursa Büyükşehir Belediyesi", fame=8, local=8),

        p("Eşkel Halk Plajı", "kum", Group.SEA, "Mudanya, Bursa",
            "Uzun kumsalı nedeniyle kumlu plaj seçeneğinde öne çıkar.",
            listOf("Kumlu", "Mudanya"), "Bursa Büyükşehir Belediyesi", fame=8, local=10),
        p("Kumsaz Plajı", "kum", Group.SEA, "Gemlik, Bursa",
            "Adı ve kıyı yapısıyla kumlu seçenekler arasında öne çıkar.",
            listOf("Kumlu", "Gemlik"), "Bursa Büyükşehir Belediyesi", fame=8, local=9),

        // BURSA / KALE — one result instead of five was a specific complaint.
        p("Bursa Kalesi ve Hisar Surları", "kale", Group.DISCOVER, "Osmangazi, Bursa",
            "Bursa'nın en eski yerleşim alanı Hisar çevresindeki ana savunma yapısı.",
            listOf("Kale", "Hisar", "Tarihi"), "Bursa Büyükşehir Belediyesi",
            established="MÖ 2. yüzyıl kökenli", fame=10, local=10),
        p("Saltanat Kapı (Hisar Kapı)", "kale", Group.DISCOVER, "Osmangazi, Bursa",
            "Bursa sur sisteminin anıtsal kapılarından.",
            listOf("Sur kapısı", "Hisar"), "Bursa Büyükşehir Belediyesi", fame=8, local=10),
        p("Zindan Kapı", "kale", Group.DISCOVER, "Osmangazi, Bursa",
            "Bursa surlarının tarihî kapı ve savunma noktalarından.",
            listOf("Sur kapısı", "Tarihi"), "Bursa Büyükşehir Belediyesi", fame=8, local=9),
        p("Yer Kapı", "kale", Group.DISCOVER, "Osmangazi, Bursa",
            "Tarihî Bursa sur sisteminin kapılarından.",
            listOf("Sur kapısı"), "Bursa Büyükşehir Belediyesi", fame=7, local=9),
        p("Pınarbaşı Kapı", "kale", Group.DISCOVER, "Osmangazi, Bursa",
            "Hisar çevresindeki tarihî sur kapılarından.",
            listOf("Sur kapısı"), "Bursa Büyükşehir Belediyesi", fame=7, local=9),

        // BODRUM / LEZZET — ilk kart, seçilen kategorinin köklü/meşhur yerel tavsiyesi.
        p("Ciğerci Yasin", "ciger", Group.FOOD, "Bodrum, Muğla",
            "Bodrum'da ciğer denince öne çıkan yerel ve salaş adreslerden; ilk tavsiye olarak sabitlendi.",
            listOf("⭐ İlk tavsiye", "Yerel meşhur", "Salaş"), "Güncel işletme kaydı + yerel yayınlar",
            fame=10, local=10, type=10, address="Yokuşbaşı, Reisoğlu Hacı Halil Efendi Sk No:44, Bodrum"),
        p("Milas Sofrası Ciğerci Durmuş Usta", "ciger", Group.FOOD, "Bodrum, Muğla",
            "Ciğer ve esnaf lokantası çizgisinde bilinen yerel seçenek.",
            listOf("Yerel", "Esnaf", "Ciğer"), "İşletme kayıtları",
            established="2000'den beri olarak tanıtılıyor", fame=8, local=9, type=10),

        p("Bilal'in Yeri Köfteci & Restaurant", "kofte", Group.FOOD, "Bodrum, Muğla",
            "Eski Bodrum esnaf lokantası çizgisinde, şiş köftesiyle anılan köklü adres; köftede ilk tavsiye.",
            listOf("⭐ İlk tavsiye", "Köklü", "Uygun/salaş"), "İşletme sosyal kaydı + Tripadvisor",
            established="1945/1946'dan beri olarak tanıtılıyor", fame=10, local=10, type=10,
            address="Çarşı, Yeni Çarşı 4. Sk. No:12, Bodrum"),
        p("Liman Köftecisi", "kofte", Group.FOOD, "Bodrum, Muğla",
            "Bodrum merkezde uzun süredir bilinen köfte odaklı seçenek.",
            listOf("Köfte", "Merkez"), "Güncel işletme kayıtları", fame=8, local=9, type=10,
            address="Eskiçeşme, Neyzen Tevfik Cd. 180/2, Bodrum"),
        p("Meşhur Çine Köftecisi (Kamil Usta)", "kofte", Group.FOOD, "Bodrum, Muğla",
            "Sanayi Sitesi çevresinde köfte odaklı yerel seçenek.",
            listOf("Köfte", "Yerel", "Sanayi"), "Güncel işletme kayıtları", fame=8, local=9, type=10,
            address="Sanayi Sitesi No:7, Hasan Reşat Öncü Cd., Bodrum"),

        p("Fiko Ocakbaşı", "kebap", Group.FOOD, "Yalıkavak, Bodrum, Muğla",
            "Yalıkavak'ta yıllardır kebap/ocakbaşı denince adı geçen yerel adreslerden; sezonluk çalışabildiği için gitmeden açık olduğuna bak.",
            listOf("⭐ İlk tavsiye", "Ocakbaşı", "Yerel meşhur"), "Bodrum yerel restoran rehberleri",
            fame=10, local=9, type=10),
        p("Kebapçım Ali", "kebap", Group.FOOD, "Yalıkavak, Bodrum, Muğla",
            "Salaş, sıcak ve samimi ocakbaşı tarzıyla öne çıkan yerel kebap alternatifi.",
            listOf("Salaş", "Ocakbaşı", "Yerel"), "2026 Bodrum yerel restoran rehberi",
            fame=8, local=10, type=10),
        p("Otantik Ocakbaşı", "kebap", Group.FOOD, "Bodrum, Muğla",
            "Bodrum merkezde kebap ve açık ateş ızgaralarıyla tanınan köklü seçenek.",
            listOf("Ocakbaşı", "Merkez"), "MICHELIN Guide + işletme kayıtları",
            fame=9, local=7, type=10, address="Çarşı, Atatürk Cd. No:46, Bodrum"),

        p("Sakallı Restaurant", "sulu", Group.FOOD, "Bodrum, Muğla",
            "1945'e uzanan esnaf lokantası geçmişi; kuru fasulye ve tencere yemekleriyle sulu yemekte ilk tavsiye.",
            listOf("⭐ İlk tavsiye", "1945", "Tencere yemeği"), "Sakallı Restaurant resmi sitesi",
            established="1945", fame=10, local=10, type=10),
        p("Nazik Ana Restaurant", "sulu", Group.FOOD, "Bodrum, Muğla",
            "Ev yemeği ve sulu yemek arayanların yıllardır bildiği Bodrum merkez adreslerinden.",
            listOf("Ev yemeği", "Sulu yemek", "Yerel"), "Güncel işletme kayıtları + gezgin yorumları",
            fame=9, local=9, type=10, address="Çarşı, Eski Hükümet Sk. No:5, Bodrum"),
        p("Kısmet Lokantası", "sulu", Group.FOOD, "Çırkan, Bodrum, Muğla",
            "Yerel lokanta çizgisinde günlük yemekleriyle bilinen seçenek.",
            listOf("Lokanta", "Günlük yemek"), "Güncel işletme kayıtları", fame=8, local=9, type=9),

        p("Sakallı Restaurant", "esnaf", Group.FOOD, "Bodrum, Muğla",
            "1945'ten gelen esnaf lokantası kökü nedeniyle esnaf lokantasında ilk tavsiye.",
            listOf("⭐ İlk tavsiye", "Köklü", "Esnaf lokantası"), "Sakallı Restaurant resmi sitesi",
            established="1945", fame=10, local=10, type=10),
        p("Bilal'in Yeri Köfteci & Restaurant", "esnaf", Group.FOOD, "Bodrum, Muğla",
            "Köfte yanında sulu yemekleriyle de anılan eski Bodrum esnaf lokantası.",
            listOf("Köklü", "Esnaf", "Köfte"), "İşletme sosyal kaydı + Tripadvisor",
            established="1945/1946'dan beri olarak tanıtılıyor", fame=9, local=10, type=9),
        p("Nazik Ana Restaurant", "esnaf", Group.FOOD, "Bodrum, Muğla",
            "Bodrum merkezde ev yemeği ve esnaf lokantası tarzında bilinen yerel seçenek.",
            listOf("Ev yemeği", "Yerel"), "Güncel işletme kayıtları + gezgin yorumları",
            fame=9, local=9, type=9),

        p("Közden Tavuk", "tavuk", Group.FOOD, "Bodrum, Muğla",
            "Bodrum sanayi çevresinde tavuk odaklı, yerel ve uygun fiyat bandında öne çıkan seçenek.",
            listOf("⭐ İlk tavsiye", "Tavuk", "Yerel"), "Güncel işletme kayıtları",
            fame=8, local=9, type=10, address="Hasan Reşat Öncü Cd. Sanayi Sitesi No:13/1, Bodrum"),
        p("Bodrum Kanatçısı", "tavuk", Group.FOOD, "Bodrum, Muğla",
            "Kanat ve tavuk ağırlıklı yerel alternatif.",
            listOf("Kanat", "Yerel"), "Güncel işletme kayıtları", fame=7, local=9, type=10,
            address="Çarşı, Türk Kuyusu Cd. 34/A, Bodrum"),

        p("Bodrum Balık Ekmek", "balik", Group.FOOD, "Bodrum, Muğla",
            "Merkezde daha salaş ve ulaşılabilir balık seçeneği; fiyat/yerellik dengesi nedeniyle ilk tavsiye.",
            listOf("⭐ İlk tavsiye", "Salaş", "Balık ekmek"), "Güncel işletme kayıtları + gezgin yorumları",
            fame=10, local=10, type=10, address="Çarşı, Belediye Meydanı No:10, Bodrum"),
        p("Bayram Balık Restoranı", "balik", Group.FOOD, "Bodrum, Muğla",
            "Bodrum merkezde balık odaklı bilinen seçenek.",
            listOf("Balık", "Merkez"), "Güncel işletme kayıtları", fame=8, local=8, type=10),

        p("Meşhur Aktur Simitçisi / Aktur Fırın", "kahvalti", Group.FOOD, "Bitez, Bodrum, Muğla",
            "Bitez'de simitli, sade ve yerel kahvaltı klasiği olarak anılıyor; kahvaltıda ilk tavsiye.",
            listOf("⭐ İlk tavsiye", "Bitez klasiği", "Simit"), "Bodrum kahvaltı rehberi + işletme sosyal kaydı",
            established="1989 adıyla işletme kaydı", fame=10, local=10, type=10),
        p("Kuytu Bahçe Bodrum", "kahvalti", Group.FOOD, "Konacık, Bodrum, Muğla",
            "Bodrum'da kahvaltı için uzun süredir bilinen bahçe seçeneklerinden.",
            listOf("Kahvaltı", "Bahçe"), "Güncel işletme kayıtları + yerel rehber", fame=8, local=8, type=10),

        // BODRUM / MAGARA
        p("Peynir Çiçeği Mağarası", "magara", Group.DISCOVER, "Gündoğan, Bodrum, Muğla",
            "Gündoğan çevresinde gerçek mağara ve tarihöncesi buluntularla ilişkilendirilen doğal/tarihî nokta.",
            listOf("Gerçek mağara", "Arkeoloji", "Gündoğan"), "Bodrum yerel gezi kaynakları",
            fame=9, local=9, type=10),

        // BODRUM / other dependable offline core
        p("Bodrum Kalesi", "kale", Group.DISCOVER, "Bodrum, Muğla",
            "Bodrum'un simge tarihî savunma yapısı.",
            listOf("Kale", "Simge"), "Kültür turizmi kaynakları", fame=10, local=10),
        p("Pedasa Antik Kenti", "antik", Group.DISCOVER, "Konacık / Gökçeler, Bodrum, Muğla",
            "Yaklaşık 3 bin yıllık Leleg yerleşimi; akropol, Athena kutsal alanı, nekropol ve taş yapılarıyla Bodrum'un en güçlü antik kent duraklarından.",
            listOf("Antik kent", "Leleg", "Kazı alanı"), "Bodrum Belediyesi • Pedasa",
            established="MÖ 12/11. yüzyıl", fame=10, local=10, type=10),
        p("Myndos Antik Kenti", "antik", Group.DISCOVER, "Gümüşlük, Bodrum, Muğla",
            "Gümüşlük Limanı ve çevresine kesin olarak lokalize edilen antik kent; liman, sur ve Tavşan/Asar Ada çevresinde kalıntılar bulunuyor.",
            listOf("Antik kent", "Gümüşlük", "Liman"), "Bodrum Belediyesi • Myndos",
            fame=10, local=10, type=10),
        p("Termera Antik Kenti", "antik", Group.DISCOVER, "Akyarlar kuzeyi / Mandıra-Asarlık, Bodrum, Muğla",
            "Herodotos ve antik vergi listelerinde adı geçen güçlü Karia-Leleg yerleşimi; kalıntılar Akyarlar'ın kuzeyindeki Asarlık çevresiyle ilişkilendiriliyor.",
            listOf("Antik kent", "Leleg", "Akyarlar"), "Bodrum Belediyesi • Termera",
            established="MÖ 5. yüzyılda belgeli", fame=8, local=9, type=10),
        p("Ouranion / Uranium Antik Yerleşimi", "antik", Group.DISCOVER, "Geriş / Yalıkavak, Bodrum, Muğla",
            "Antik kaynaklarda adı geçen gizemli Leleg kenti; kalıntılar Geriş çevresindeki Burgaz, Tilki ve Karain tepeleriyle ilişkilendiriliyor.",
            listOf("Antik kent", "Leleg", "Yalıkavak"), "Bodrum Belediyesi • Ouranion/Uranium",
            fame=8, local=9, type=10),
        p("Telmissos Antik Yerleşimi", "antik", Group.DISCOVER, "Gürece / Ortakent, Bodrum, Muğla",
            "Bodrum'daki Leleg kentlerinden; Gürece Kaletepe'de iç-dış sur, kaya mezarı, tarım terasları ve yapılar belgelenmiş.",
            listOf("Antik kent", "Leleg", "Gürece"), "Bodrum Belediyesi • Telmissos",
            fame=7, local=9, type=10),
        p("Madnasa Antik Yerleşimi", "antik", Group.DISCOVER, "Türkbükü-Gölköy çevresi, Bodrum, Muğla",
            "Antik kaynaklardaki sekiz Leleg kentinden biri; kesin konumu tartışmalı, Kaleyıkığı Tepesi çevresiyle ilişkilendiriliyor.",
            listOf("Antik kent", "Leleg", "Konumu tartışmalı"), "Bodrum Belediyesi • Madnasa",
            fame=7, local=9, type=10),
        p("Side / Sibde Leleg Yerleşimi", "antik", Group.DISCOVER, "Karadağ-Girel çevresi, Bodrum, Muğla",
            "Kaynaklarda adı geçen en gizemli Leleg kentlerinden; kesin lokalizasyonu yok, Karadağ/Girel çevresi olası alan olarak öneriliyor.",
            listOf("Antik kent", "Leleg", "Konumu belirsiz"), "Bodrum Belediyesi • Side/Sibde",
            fame=7, local=8, type=10),
        p("Syangela / Theangela", "antik", Group.DISCOVER, "Etrim / Alazeytin çevresi, Bodrum, Muğla",
            "Halikarnassos'un doğusunda yer alan Leleg kenti; Alazeytin ve Etrim-Kaledağ çevresiyle ilişkilendirilen surlu yerleşimler var.",
            listOf("Antik kent", "Leleg", "Doğu Bodrum"), "Bodrum Belediyesi • Syangela/Theangela",
            fame=7, local=8, type=10),
        p("Halikarnassos Antik Kenti", "antik", Group.DISCOVER, "Bodrum merkez, Muğla",
            "Bugünkü Bodrum merkezinin altında ve çevresinde yaşayan antik Karia başkenti; Mausoleion, tiyatro, sur ve Myndos Kapısı kentin parçalarıdır.",
            listOf("Antik kent", "Karia", "Halikarnassos"), "Bodrum Belediyesi + Müze kaynakları",
            fame=10, local=10, type=10),
        p("Bodrum Sualtı Arkeoloji Müzesi", "muze", Group.DISCOVER, "Bodrum Kalesi, Muğla",
            "Sualtı arkeolojisi koleksiyonlarıyla bilinen müze.",
            listOf("Müze", "Arkeoloji"), "Kültür turizmi kaynakları", fame=10, local=9),
        p("Halikarnassos Mausoleion", "tarihi", Group.DISCOVER, "Bodrum, Muğla",
            "Antik Dünyanın Yedi Harikası arasında anılan anıt mezar.",
            listOf("Tarih", "Antik"), "Kültür turizmi kaynakları", fame=10, local=9),
        p("Salmakis (Bardakçı) Koyu — Salmakis & Hermaphroditos", "gizem", Group.DISCOVER, "Bardakçı, Bodrum, Muğla",
            "EFSANE ÖZETİ: Anlatıya göre su perisi Salmakis, Hermaphroditos'a âşık olur. Tanrılardan hiç ayrılmamalarını diler ve ikisinin tek bedende birleştiği söylenir. Efsanenin mekânı antik Salmakis kaynağı ve bugünkü Bardakçı çevresiyle ilişkilendirilir.",
            listOf("Efsane", "Salmakis", "Bardakçı"), "Antik anlatı geleneği + Bodrum yerel kaynakları",
            fame=10, local=10, type=10),
        p("Pedasa — Sakalı Uzayan Athena Rahibesi", "gizem", Group.DISCOVER, "Konacık / Gökçeler, Bodrum, Muğla",
            "EFSANE ÖZETİ: Herodotos'un aktardığı eski inanışa göre Pedasalılara büyük bir felaket yaklaşınca Athena rahibesinin sakalı uzardı. Bu olağanüstü işaretin kent tarihinde üç kez görüldüğü anlatılır.",
            listOf("Efsane", "Herodotos", "Pedasa"), "Bodrum Belediyesi • Pedasa / Herodotos anlatısı",
            fame=9, local=10, type=10),
        p("Mausoleion — Artemisia'nın Yas Efsanesi", "gizem", Group.DISCOVER, "Bodrum merkez, Muğla",
            "EFSANE ÖZETİ: Artemisia II'nin Mausolos'un ölümünden sonra büyük yas tuttuğu tarihsel olarak bilinir. Sonraki sanat ve anlatı geleneğinde, onun Mausolos'un küllerini içeceğine karıştırıp içerek 'yaşayan mezarı' olmak istediği söylenir; bunu tarihsel kesinlik değil efsane olarak gösteriyoruz.",
            listOf("Efsane", "Artemisia", "Mausoleion"), "National Gallery anlatı geleneği + Bodrum Belediyesi",
            fame=9, local=9, type=10),
        p("Ouranion / Uranium — Kayıp Leleg Kenti Gizemi", "gizem", Group.DISCOVER, "Geriş / Yalıkavak, Bodrum, Muğla",
            "GİZEM ÖZETİ: Antik kaynaklarda adı var ama kentin kesin yeri hâlâ tartışmalı. Geriş çevresindeki Burgaz, Tilki Tepe ve Karain Tepe kalıntıları Ouranion için öne çıkan aday alanlar.",
            listOf("Gizem", "Kayıp kent", "Leleg"), "Bodrum Belediyesi • Ouranion/Uranium",
            fame=8, local=9, type=10),
        p("Side / Sibde — Yeri Bilinmeyen Leleg Kenti", "gizem", Group.DISCOVER, "Karadağ-Girel çevresi, Bodrum, Muğla",
            "GİZEM ÖZETİ: Antik metinlerde adı geçen Side/Sibde'nin kesin konumu bulunmuş değil. Araştırmacılar Karadağ ve Girel çevresindeki Leleg kalıntılarını olası yer olarak tartışıyor.",
            listOf("Gizem", "Kayıp kent", "Leleg"), "Bodrum Belediyesi • Side/Sibde",
            fame=7, local=8, type=10),

        p("Ortakent Yahşi Plajı", "plaj", Group.SEA, "Bodrum, Muğla",
            "Bodrum yarımadasında bilinen uzun plajlardan.",
            listOf("Plaj", "Yerel"), "Yerel gezi kaynakları", fame=9, local=9),
        // BODRUM / KUMLU - SIĞ — OSM etiketleri eksik olsa bile çevrimdışı zengin sonuç.
        p("Bitez Plajı", "kum", Group.SEA, "Bitez, Bodrum, Muğla",
            "İnce kumlu, sığ ve genellikle sakin deniziyle aileler için öne çıkan Bodrum plajlarından.",
            listOf("Sığ", "İnce kum", "Aile"), "Bodrum.com.tr + Enuygun + Go Bodrum",
            fame=10, local=10, type=10),
        p("Ortakent-Yahşi Plajı", "kum", Group.SEA, "Ortakent-Yahşi, Bodrum, Muğla",
            "Uzun kumsalı ve yavaş derinleşen/sığ deniz yapısıyla öne çıkan aile dostu seçenek.",
            listOf("Sığ", "Kumsal", "Aile"), "Go Bodrum + yerel/ziyaretçi kaynakları",
            fame=9, local=10, type=10),
        p("Camel Beach / Kargı Koyu", "kum", Group.SEA, "Ortakent-Yahşi, Bodrum, Muğla",
            "Kum tabanlı ve belirgin şekilde sığ deniziyle Bodrum'un en bilinen sığ plaj seçeneklerinden.",
            listOf("Çok sığ", "Kum", "Kargı Koyu"), "Bodrum plaj rehberleri + ziyaretçi kayıtları",
            fame=9, local=9, type=10),
        p("Karaincir Halk Plajı", "kum", Group.SEA, "Akyarlar, Bodrum, Muğla",
            "İnce kumlu, sakin ve sığ deniziyle özellikle çocuklu ailelerin tercih ettiği koylardan.",
            listOf("Sığ", "İnce kum", "Sakin"), "Bodrum Belediyesi + güncel plaj rehberleri",
            fame=9, local=9, type=10),
        p("Gümbet Mavi Bayraklı Halk Plajı", "kum", Group.SEA, "Gümbet, Bodrum, Muğla",
            "İnce kumlu kıyısı ve sığ deniziyle merkeze yakın seçeneklerden.",
            listOf("Sığ", "İnce kum", "Halk plajı"), "Bodrum Belediyesi + güncel plaj rehberleri",
            fame=8, local=9, type=10),
        p("Turgutreis Halk Plajı", "kum", Group.SEA, "Turgutreis, Bodrum, Muğla",
            "Geniş ince kumlu sahili ve sığ bölümleriyle yüzme bilmeyenler ve aileler için uygun seçeneklerden.",
            listOf("Sığ", "İnce kum", "Turgutreis"), "Güncel Bodrum plaj rehberleri",
            fame=8, local=9, type=10),
        p("Akyarlar Halk Plajı", "kum", Group.SEA, "Akyarlar, Bodrum, Muğla",
            "Yumuşak kumlu kıyısı ve korunaklı/sakin deniz yapısıyla kumlu plaj aramasında güçlü seçenek.",
            listOf("Kumlu", "Sakin", "Halk plajı"), "Bodrum Belediyesi + Go Bodrum",
            fame=8, local=9, type=10),
        p("Bitez Koyu", "koy", Group.SEA, "Bodrum, Muğla",
            "Korunaklı koy yapısıyla bilinen Bodrum kıyılarından.",
            listOf("Koy", "Bodrum"), "Yerel gezi kaynakları", fame=9, local=9)
    )

    fun find(region: String, categoryKey: String): List<PlaceItem> {
        val r = TextNorm.norm(region)
        return items
            .filter { it.categoryKey == categoryKey }
            .filter {
                val area = TextNorm.norm(it.area)
                when {
                    r == "bursa" -> area.contains("bursa")
                    r == "bodrum" -> area.contains("bodrum")
                    r == "mugla" -> area.contains("mugla")
                    else -> area.contains(r) || r.contains(area)
                }
            }
            .sortedByDescending { it.smartScore() }
    }
}

object RegionCatalog {
    private val regions = mapOf(
        "bursa" to RegionBounds("Bursa", 39.50, 27.85, 40.75, 30.10, 40.195, 29.060),
        "bodrum" to RegionBounds("Bodrum", 36.90, 27.05, 37.25, 27.70, 37.035, 27.430),
        "mugla" to RegionBounds("Muğla", 36.05, 27.00, 37.60, 29.85, 37.215, 28.365),
        "antalya" to RegionBounds("Antalya", 35.80, 29.20, 37.55, 32.70, 36.885, 30.705),
        "istanbul" to RegionBounds("İstanbul", 40.75, 27.95, 41.60, 29.95, 41.015, 28.980),
        "izmir" to RegionBounds("İzmir", 37.80, 26.20, 39.45, 28.60, 38.420, 27.140),
        "mersin" to RegionBounds("Mersin", 36.00, 32.50, 37.30, 35.10, 36.800, 34.630)
    )

    fun known(region: String): RegionBounds? = regions[TextNorm.norm(region)]
}

object SafetyRules {
    private val badSeaWords = listOf(
        "market","banka","bank","akbank","otel","hotel","cafe","kafe","restoran",
        "restaurant","eczane","mobilya","emlak","magaza","store","shop","petrol"
    )
    private val badDiscoverWords = listOf(
        "market","cafe","kafe","restoran","restaurant","otel","hotel","magaza","shop","store"
    )

    fun acceptLive(name: String, category: CategorySpec, osmType: String, brand: String = ""): Boolean {
        val n = TextNorm.norm(name)
        val t = TextNorm.norm(osmType)
        val b = TextNorm.norm(brand)

        if (category.group == Group.FOOD && b.isNotBlank()) return false

        if (category.group == Group.SEA && badSeaWords.any { n.contains(it) }) return false
        if (category.group == Group.DISCOVER && badDiscoverWords.any { n.contains(it) }) return false

        return when (category.strictType) {
            "beach" -> t.contains("beach")
            "bay" -> t.contains("bay")
            "cave" -> t.contains("cave")
            "museum" -> t.contains("museum")
            "castle" -> t.contains("castle") || t.contains("fort")
            "archaeological" -> t.contains("archaeological") || t.contains("ruins")
            "historic" -> t.contains("historic")
            "hotel" -> t.contains("hotel") || t.contains("motel") || t.contains("resort")
            "guest_house" -> t.contains("guest house") || t.contains("hostel") || t.contains("bed and breakfast")
            "apartment" -> t.contains("apartment")
            "camp" -> t.contains("camp")
            "food" -> t.contains("restaurant") || t.contains("fast food") || t.contains("cafe")
            "curated" -> false
            else -> false
        }
    }

    fun dedupe(items: List<PlaceItem>): List<PlaceItem> {
        val seen = mutableSetOf<String>()
        return items.filter {
            val key = TextNorm.norm(it.name) + "|" + TextNorm.norm(it.area)
            seen.add(key)
        }
    }

    fun mergeAndRank(offline: List<PlaceItem>, live: List<PlaceItem>): List<PlaceItem> =
        dedupe(offline + live).sortedByDescending { it.smartScore() }
}
