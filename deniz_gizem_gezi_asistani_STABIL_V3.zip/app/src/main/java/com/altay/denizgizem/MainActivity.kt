package com.altay.denizgizem

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private lateinit var placeInput: EditText
    private lateinit var statusText: TextView
    private lateinit var content: LinearLayout
    private var currentPlace: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(12))
        }

        outer.addView(TextView(this).apply {
            text = "DENİZ GİZEM\nGEZİ ASİSTANI"
            textSize = 25f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(6))
        })

        outer.addView(TextView(this).apply {
            text = "Gideceğin yeri yaz. Sana deniz, lezzet, keşif ve konaklama için hazır aramalar oluştursun."
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(dp(8), 0, dp(8), dp(16))
        })

        placeInput = EditText(this).apply {
            hint = "Örn: Çıralı, Antalya"
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
            textSize = 19f
        }
        outer.addView(placeInput, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        outer.addView(Button(this).apply {
            text = "BÖLGEYİ HAZIRLA"
            setOnClickListener { preparePlace() }
        })

        statusText = TextView(this).apply {
            text = "Bir bölge yazarak başlayabilirsin."
            textSize = 14f
            setPadding(0, dp(8), 0, dp(8))
        }
        outer.addView(statusText)

        val quickScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
        }
        val quickRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        listOf(
            "🌊 DENİZ" to "deniz",
            "🍽️ LEZZET" to "lezzet",
            "🏛️ KEŞFET" to "kesfet",
            "🛏️ KONAK" to "konak"
        ).forEach { (label, tag) ->
            quickRow.addView(Button(this).apply {
                text = label
                setOnClickListener {
                    if (ensurePlace()) showCategory(tag)
                }
            })
        }

        quickScroll.addView(quickRow)
        outer.addView(quickScroll)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(32))
        }
        scroll.addView(content)

        outer.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            0,
            1f
        ))

        setContentView(outer)
        showWelcome()
    }

    private fun preparePlace() {
        val q = placeInput.text.toString().trim()

        if (q.isEmpty()) {
            Toast.makeText(this, "Önce bir yer yaz hocam.", Toast.LENGTH_SHORT).show()
            return
        }

        currentPlace = q
        statusText.text = "$currentPlace için arama seçenekleri hazır."
        showHome()
    }

    private fun ensurePlace(): Boolean {
        val typed = placeInput.text.toString().trim()

        if (typed.isNotEmpty()) {
            currentPlace = typed
        }

        if (currentPlace.isBlank()) {
            Toast.makeText(this, "Önce bir bölge yaz.", Toast.LENGTH_SHORT).show()
            return false
        }

        return true
    }

    private fun clearContent() {
        content.removeAllViews()
    }

    private fun showWelcome() {
        clearContent()
        addHeadline("Nasıl kullanılır?")
        addText(
            "Örneğin “Antalya”, “Çıralı, Antalya”, “Datça” veya “Ayvalık” yaz. " +
            "Bölgeyi hazırla dediğinde aşağıdaki başlıklardan istediğini aç."
        )
        addText(
            "Bu sürüm ücretsiz harita sunucularını taramadığı için uzun bekleme ve timeout sorunu yaşamaz. " +
            "Seçtiğin aramayı doğrudan harita veya tarayıcıda açar."
        )
    }

    private fun showHome() {
        clearContent()

        addHeadline("📍 $currentPlace")
        addText("Ne aramak istediğini seç:")

        addBigCategoryButton("🌊 DENİZ", "Sığ kum plajı, sakin koy ve iyi plaj aramaları") {
            showCategory("deniz")
        }

        addBigCategoryButton("🍽️ LEZZET", "Meşhur yemek, köfteci, yerel restoran ve eski işletme") {
            showCategory("lezzet")
        }

        addBigCategoryButton("🏛️ KEŞFET", "Antik kent, tarih, mağara, efsane ve gizemli yerler") {
            showCategory("kesfet")
        }

        addBigCategoryButton("🛏️ KONAK", "Otel, pansiyon, kamp ve uygun konaklama aramaları") {
            showCategory("konak")
        }

        addHeadline("Hızlı genel arama")
        addAction(
            "📍 Google Haritalar'da $currentPlace",
            "Bölgeyi genel olarak haritada aç"
        ) {
            openMap(currentPlace)
        }
    }

    private fun showCategory(category: String) {
        if (!ensurePlace()) return
        clearContent()

        when (category) {
            "deniz" -> showSea()
            "lezzet" -> showFood()
            "kesfet" -> showDiscover()
            "konak" -> showStay()
        }

        addBackButton()
    }

    private fun showSea() {
        addHeadline("🌊 DENİZ — $currentPlace")

        addAction("🏖️ Sığ kum plajları", "Google Haritalar'da ara") {
            openMap("sığ kum plajı $currentPlace")
        }

        addAction("🌊 Dalgasız / sakin koylar", "Google'da bölgeye özel ara") {
            openWeb("dalgasız sakin koylar $currentPlace")
        }

        addAction("🏝️ En iyi plajlar", "Google Haritalar'da ara") {
            openMap("en iyi plajlar $currentPlace")
        }

        addAction("👣 Çocuklu aile için sığ deniz", "Google'da ara") {
            openWeb("çocuklu aile için sığ kum deniz plaj $currentPlace")
        }

        addAction("🧭 Gizli koylar ve az bilinen plajlar", "Google'da ara") {
            openWeb("az bilinen gizli koylar plajlar $currentPlace")
        }
    }

    private fun showFood() {
        addHeadline("🍽️ LEZZET — $currentPlace")

        addAction("🍲 Bölgenin meşhur yemeği", "Google'da ara") {
            openWeb("$currentPlace meşhur yöresel yemek ne yenir")
        }

        addAction("🥩 Köfteciler", "Google Haritalar'da ara") {
            openMap("köfteci $currentPlace")
        }

        addAction("🍽️ Yerel restoranlar", "Google Haritalar'da ara") {
            openMap("yerel restoran $currentPlace")
        }

        addAction("🏺 En eski işletmeler", "Google'da tarih ve işletme geçmişi ara") {
            openWeb("$currentPlace en eski restoran lokanta işletme tarihi")
        }

        addAction("⭐ En çok yorum alan yemek yerleri", "Google Haritalar'da ara") {
            openMap("restoran $currentPlace")
        }
    }

    private fun showDiscover() {
        addHeadline("🏛️ KEŞFET — $currentPlace")

        addAction("🏺 Antik kentler", "Google Haritalar'da ara") {
            openMap("antik kent $currentPlace")
        }

        addAction("🏛️ Tarihi yerler", "Google Haritalar'da ara") {
            openMap("tarihi yerler $currentPlace")
        }

        addAction("🕳️ Mağara ve yeraltı yapıları", "Google Haritalar'da ara") {
            openMap("mağara yeraltı şehri $currentPlace")
        }

        addAction("📜 Efsaneler ve mitolojik anlatılar", "Google'da ara") {
            openWeb("$currentPlace efsanesi mitoloji antik hikaye")
        }

        addAction("👁️ Gizemli / paranormal yerler", "Google'da ara") {
            openWeb("$currentPlace gizemli paranormal esrarengiz yerler efsane")
        }

        addAction("🗿 Arkeolojik alanlar", "Google Haritalar'da ara") {
            openMap("arkeolojik alan $currentPlace")
        }

        addAction("📷 Görülmesi gereken yerler", "Google Haritalar'da ara") {
            openMap("gezilecek yerler $currentPlace")
        }
    }

    private fun showStay() {
        addHeadline("🛏️ KONAK — $currentPlace")

        addAction("🏨 Uygun oteller", "Google Haritalar'da ara") {
            openMap("uygun otel $currentPlace")
        }

        addAction("🏡 Pansiyonlar", "Google Haritalar'da ara") {
            openMap("pansiyon $currentPlace")
        }

        addAction("⛺ Kamp alanları", "Google Haritalar'da ara") {
            openMap("kamp alanı $currentPlace")
        }

        addAction("💰 Uygun konaklama fiyatları", "Google'da güncel fiyat ara") {
            openWeb("$currentPlace uygun konaklama otel pansiyon fiyatları")
        }

        addAction("🌊 Denize yakın konaklama", "Google Haritalar'da ara") {
            openMap("denize yakın otel pansiyon $currentPlace")
        }
    }

    private fun addHeadline(text: String) {
        content.addView(TextView(this).apply {
            this.text = text
            textSize = 21f
            setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(12), 0, dp(8))
        })
    }

    private fun addText(text: String) {
        content.addView(TextView(this).apply {
            this.text = text
            textSize = 16f
            setPadding(0, dp(4), 0, dp(10))
        })
    }

    private fun addBigCategoryButton(title: String, subtitle: String, action: () -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4), 0, dp(4))
        }

        box.addView(Button(this).apply {
            text = title
            textSize = 18f
            setOnClickListener { action() }
        })

        box.addView(TextView(this).apply {
            text = subtitle
            textSize = 14f
            setPadding(dp(8), 0, dp(8), dp(8))
        })

        content.addView(box)
    }

    private fun addAction(title: String, subtitle: String, action: () -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4), 0, dp(6))
        }

        row.addView(Button(this).apply {
            text = title
            textSize = 16f
            isAllCaps = false
            setOnClickListener { action() }
        })

        row.addView(TextView(this).apply {
            text = subtitle
            textSize = 13f
            setPadding(dp(8), 0, dp(8), dp(4))
        })

        content.addView(row)
    }

    private fun addBackButton() {
        content.addView(Button(this).apply {
            text = "← ANA MENÜYE DÖN"
            setOnClickListener { showHome() }
        })
    }

    private fun openMap(query: String) {
        try {
            val encoded = Uri.encode(query)
            val geoIntent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$encoded"))
            startActivity(geoIntent)
        } catch (_: ActivityNotFoundException) {
            openWeb(query)
        } catch (_: Exception) {
            openWeb(query)
        }
    }

    private fun openWeb(query: String) {
        try {
            val encoded = URLEncoder.encode(query, StandardCharsets.UTF_8.toString())
            val url = "https://www.google.com/search?q=$encoded"
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            Toast.makeText(this, "Tarayıcı açılamadı.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun dp(v: Int): Int =
        (v * resources.displayMetrics.density).roundToInt()
}
