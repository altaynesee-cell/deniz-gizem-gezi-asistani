plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.altay.denizgizem"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.altay.denizgizem"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "3.0-stabil"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
