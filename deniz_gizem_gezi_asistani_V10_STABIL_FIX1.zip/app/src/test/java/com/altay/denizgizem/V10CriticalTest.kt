package com.altay.denizgizem

import org.junit.Assert.*
import org.junit.Test

class V10CriticalTest {
    @Test
    fun bursaPlajOfflineIsRichAndSafe() {
        val x = OfflineCatalog.find("Bursa", "plaj")
        assertTrue("Bursa plaj sayısı", x.size >= 8)
        assertTrue(x.all { TextNorm.norm(it.area).contains("bursa") })
        assertTrue(x.none { TextNorm.norm(it.name).contains("alanya") })
        assertTrue(x.none { TextNorm.norm(it.name).contains("market") })
        assertTrue(x.first().verified)
    }

    @Test
    fun bursaKaleReturnsMultipleVerifiedPlaces() {
        val x = OfflineCatalog.find("Bursa", "kale")
        assertTrue("Bursa kale/hisar seçenekleri", x.size >= 5)
        assertEquals("Bursa Kalesi ve Hisar Surları", x.first().name)
        assertTrue(x.all { it.verified })
    }

    @Test
    fun bodrumCigerciYasinIsFirst() {
        val x = OfflineCatalog.find("Bodrum", "ciger")
        assertTrue(x.isNotEmpty())
        assertEquals("Ciğerci Yasin", x.first().name)
        assertTrue(x.first().tags.any { it.contains("meşhur", ignoreCase = true) })
    }

    @Test
    fun bodrumMagaraIsRealCaveNotCafe() {
        val x = OfflineCatalog.find("Bodrum", "magara")
        assertTrue(x.any { it.name == "Peynir Çiçeği Mağarası" })
        assertTrue(x.none { TextNorm.norm(it.name).contains("cafe") || TextNorm.norm(it.name).contains("kafe") })
    }

    @Test
    fun safetyRejectsBadSeaBusinesses() {
        val plaj = Categories.byKey("plaj")
        assertFalse(SafetyRules.acceptLive("Deniz Market", plaj, "Beach / Plaj"))
        assertFalse(SafetyRules.acceptLive("Akbank", plaj, "Beach / Plaj"))
        assertTrue(SafetyRules.acceptLive("Eşkel Halk Plajı", plaj, "Beach / Plaj"))
    }

    @Test
    fun safetyRejectsCaveCafe() {
        val cave = Categories.byKey("magara")
        assertFalse(SafetyRules.acceptLive("Mağara Cafe", cave, "Cafe"))
        assertTrue(SafetyRules.acceptLive("Karain Mağarası", cave, "Cave / Mağara"))
    }

    @Test
    fun bursaBoundsRejectAlanya() {
        val b = RegionCatalog.known("Bursa")!!
        assertFalse(b.contains(36.54, 31.99))
        assertTrue(b.contains(40.38, 28.88))
    }

    @Test
    fun curatedResultsBeatLiveResults() {
        val local = PlaceItem(
            "Yerel Meşhur", "ciger", Group.FOOD, "Bodrum",
            verified = true, fameScore = 10, localScore = 10, typeScore = 10
        )
        val live = PlaceItem(
            "Canlı Sonuç", "ciger", Group.FOOD, "Bodrum",
            verified = false, fameScore = 5, localScore = 6, typeScore = 10, live = true
        )
        assertTrue(local.smartScore() > live.smartScore())
    }
}
