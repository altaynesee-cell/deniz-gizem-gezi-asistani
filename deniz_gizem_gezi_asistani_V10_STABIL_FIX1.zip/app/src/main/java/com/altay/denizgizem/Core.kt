package com.altay.denizgizem

import java.text.Normalizer
import java.util.Locale
import kotlin.math.max

enum class Group(val title: String, val emoji: String) {
    FOOD("Lezzet", "🍽"),
    SEA("Deniz", "🌊"),
    DISCOVER("Keşfet", "🏛"),
    STAY("Konak", "🛏")
}

data class CategorySpec(
    val key: String,
    val title: String,
    val emoji: String,
    val group: Group,
    val strictType: String
)

data class PlaceItem(
    val name: String,
    val categoryKey: String,
    val group: Group,
    val area: String,
    val address: String = "",
    val why: String = "",
    val tags: List<String> = emptyList(),
    val established: String = "",
    val sourceLabel: String = "",
    val routeQuery: String = "",
    val verified: Boolean = false,
    val fameScore: Int = 0,
    val localScore: Int = 0,
    val typeScore: Int = 0,
    val distanceKm: Double? = null,
    val lat: Double? = null,
    val lon: Double? = null,
    val live: Boolean = false
) {
    fun smartScore(): Int {
        val verifiedBoost = if (verified) 80 else 0
        val fame = fameScore * 4
        val local = localScore * 3
        val type = typeScore * 5
        val history = if (established.isNotBlank()) 8 else 0
        val livePenalty = if (live) 2 else 0
        return verifiedBoost + fame + local + type + history - livePenalty
    }
}

data class RegionBounds(
    val canonical: String,
    val south: Double,
    val west: Double,
    val north: Double,
    val east: Double,
    val centerLat: Double,
    val centerLon: Double
) {
    fun contains(lat: Double, lon: Double): Boolean =
        lat in south..north && lon in west..east
}

object TextNorm {
    fun norm(s: String): String {
        val lower = s.lowercase(Locale.forLanguageTag("tr-TR"))
            .replace('ı', 'i').replace('ğ', 'g').replace('ü', 'u')
            .replace('ş', 's').replace('ö', 'o').replace('ç', 'c')
        return Normalizer.normalize(lower, Normalizer.Form.NFD)
            .replace("\\p{M}".toRegex(), "")
            .replace("[^a-z0-9]+".toRegex(), " ")
            .trim()
    }
}

object Categories {
    val all = listOf(
        CategorySpec("ciger", "Ciğer / Arnavut", "🥩", Group.FOOD, "food"),
        CategorySpec("kofte", "Köfte", "🧆", Group.FOOD, "food"),
        CategorySpec("kebap", "Kebap", "🔥", Group.FOOD, "food"),
        CategorySpec("sulu", "Sulu Yemek", "🍲", Group.FOOD, "food"),
        CategorySpec("tavuk", "Tavuk", "🍗", Group.FOOD, "food"),
        CategorySpec("esnaf", "Esnaf Lokantası", "🥘", Group.FOOD, "food"),
        CategorySpec("balik", "Balık", "🐟", Group.FOOD, "food"),
        CategorySpec("kahvalti", "Kahvaltı", "🍳", Group.FOOD, "food"),

        CategorySpec("plaj", "Plaj", "🏖", Group.SEA, "beach"),
        CategorySpec("kum", "Kumlu / Sığ", "👣", Group.SEA, "beach"),
        CategorySpec("koy", "Koy", "🌊", Group.SEA, "bay"),

        CategorySpec("antik", "Antik Kent", "🏺", Group.DISCOVER, "archaeological"),
        CategorySpec("kale", "Kale / Hisar", "🏰", Group.DISCOVER, "castle"),
        CategorySpec("magara", "Mağara", "🕳", Group.DISCOVER, "cave"),
        CategorySpec("muze", "Müze", "🏛", Group.DISCOVER, "museum"),
        CategorySpec("tarihi", "Tarihi Yer", "📜", Group.DISCOVER, "historic"),
        CategorySpec("gizem", "Gizem / Efsane", "👁", Group.DISCOVER, "curated"),

        CategorySpec("pansiyon", "Pansiyon", "🏡", Group.STAY, "guest_house"),
        CategorySpec("apart", "Apart", "🏢", Group.STAY, "apartment"),
        CategorySpec("otel", "Otel", "🏨", Group.STAY, "hotel"),
        CategorySpec("kamp", "Kamp", "⛺", Group.STAY, "camp")
    )

    fun byKey(key: String): CategorySpec = all.first { it.key == key }
    fun forGroup(group: Group): List<CategorySpec> = all.filter { it.group == group }
}

object OfflineCatalog {
    private fun p(
        name: String, key: String, group: Group, area: String,
        why: String, tags: List<String>, source: String,
        established: String = "", fame: Int = 7, local: Int = 8, type: Int = 10,
        address: String = "", route: String = ""
    ) = PlaceItem(
        name = name, categoryKey = key, group = group, area = area,
        address = address, why = why, tags = tags, established = established,
        sourceLabel = source, routeQuery = if (route.isBlank()) "$name $area" else route,
        verified = true, fameScore = fame, localScore = local, typeScore = type
    )

    private val items = listOf(
        // BURSA / PLAJ — official municipal sources, so it works offline and doesn't return Alanya.
        p("Kurşunlu Halk Plajı", "plaj", Group.SEA, "Karacabey, Bursa",
            "Bursa Büyükşehir'in sahil ve Mavi Bayrak çalışmalarında öne çıkan halk plajı.",
            listOf("Doğrulanmış", "Bursa", "Halk plajı"), "Bursa Büyükşehir Belediyesi", fame=9, local=9),
        p("Malkara Halk Plajı", "plaj", Group.SEA, "Karacabey, Bursa",
            "Bursa kıyılarında belediye tarafından düzenlenen ve öne çıkarılan plajlardan.",
            listOf("Doğrulanmış", "Bursa", "Plaj"), "Bursa Büyükşehir Belediyesi", fame=8, local=9),
        p("Eşkel Halk Plajı", "plaj", Group.SEA, "Mudanya, Bursa",
            "Mudanya sahil hattında uzun kumsalıyla bilinen halk plajlarından.",
            listOf("Doğrulanmış", "Mudanya", "Kumsal"), "Bursa Büyükşehir Belediyesi", fame=8, local=10),
        p("Eğerce Plajı", "plaj", Group.SEA, "Mudanya, Bursa",
            "Bursa Büyükşehir'in sezon hazırlıklarında adı geçen Mudanya plajlarından.",
            listOf("Doğrulanmış", "Mudanya"), "Bursa Büyükşehir Belediyesi", fame=7, local=9),
        p("Mesudiye Plajı", "plaj", Group.SEA, "Mudanya, Bursa",
            "Mudanya kıyı şeridindeki bilinen plajlardan.",
            listOf("Doğrulanmış", "Mudanya"), "Bursa Büyükşehir Belediyesi", fame=7, local=9),
        p("Kumsaz Plajı", "plaj", Group.SEA, "Gemlik, Bursa",
            "Gemlik sahilindeki uzun ve geniş kumsallı plajlardan.",
            listOf("Doğrulanmış", "Gemlik", "Kumsal"), "Bursa Büyükşehir Belediyesi", fame=8, local=9),
        p("Narlı Halk Plajı", "plaj", Group.SEA, "Gemlik, Bursa",
            "Gemlik kıyısındaki halk plajlarından.",
            listOf("Doğrulanmış", "Gemlik"), "Bursa Büyükşehir Belediyesi", fame=7, local=9),
        p("Mudanya Plajı", "plaj", Group.SEA, "Mudanya, Bursa",
            "Mudanya merkezde belediye tesisiyle hizmet veren plaj.",
            listOf("Doğrulanmış", "Mudanya", "Merkez"), "Bursa Büyükşehir Belediyesi", fame=8, local=8),

        p("Eşkel Halk Plajı", "kum", Group.SEA, "Mudanya, Bursa",
            "Uzun kumsalı nedeniyle kumlu plaj seçeneğinde öne çıkar.",
            listOf("Kumlu", "Mudanya"), "Bursa Büyükşehir Belediyesi", fame=8, local=10),
        p("Kumsaz Plajı", "kum", Group.SEA, "Gemlik, Bursa",
            "Adı ve kıyı yapısıyla kumlu seçenekler arasında öne çıkar.",
            listOf("Kumlu", "Gemlik"), "Bursa Büyükşehir Belediyesi", fame=8, local=9),

        // BURSA / KALE — one result instead of five was a specific complaint.
        p("Bursa Kalesi ve Hisar Surları", "kale", Group.DISCOVER, "Osmangazi, Bursa",
            "Bursa'nın en eski yerleşim alanı Hisar çevresindeki ana savunma yapısı.",
            listOf("Kale", "Hisar", "Tarihi"), "Bursa Büyükşehir Belediyesi",
            established="MÖ 2. yüzyıl kökenli", fame=10, local=10),
        p("Saltanat Kapı (Hisar Kapı)", "kale", Group.DISCOVER, "Osmangazi, Bursa",
            "Bursa sur sisteminin anıtsal kapılarından.",
            listOf("Sur kapısı", "Hisar"), "Bursa Büyükşehir Belediyesi", fame=8, local=10),
        p("Zindan Kapı", "kale", Group.DISCOVER, "Osmangazi, Bursa",
            "Bursa surlarının tarihî kapı ve savunma noktalarından.",
            listOf("Sur kapısı", "Tarihi"), "Bursa Büyükşehir Belediyesi", fame=8, local=9),
        p("Yer Kapı", "kale", Group.DISCOVER, "Osmangazi, Bursa",
            "Tarihî Bursa sur sisteminin kapılarından.",
            listOf("Sur kapısı"), "Bursa Büyükşehir Belediyesi", fame=7, local=9),
        p("Pınarbaşı Kapı", "kale", Group.DISCOVER, "Osmangazi, Bursa",
            "Hisar çevresindeki tarihî sur kapılarından.",
            listOf("Sur kapısı"), "Bursa Büyükşehir Belediyesi", fame=7, local=9),

        // BODRUM / CİĞER — user explicitly wanted Ciğerci Yasin to surface.
        p("Ciğerci Yasin", "ciger", Group.FOOD, "Bodrum, Muğla",
            "Yerel Bodrum esnafı ve müdavimleriyle anılan, ciğer ve et kavurmasıyla bilinen mütevazı yer.",
            listOf("Yerel meşhur", "Salaş", "Ciğer"), "Diken + işletme/harita kayıtları",
            fame=10, local=10, type=10, address="Reisoğlu Hacı Halil Efendi Sokak, Bodrum"),
        p("Milas Sofrası Ciğerci Durmuş Usta", "ciger", Group.FOOD, "Bodrum, Muğla",
            "Ciğer ve esnaf lokantası çizgisinde bilinen yerel seçenek.",
            listOf("Yerel", "Esnaf", "Ciğer"), "İşletme kayıtları",
            established="2000'den beri olarak tanıtılıyor", fame=8, local=9, type=10),

        p("Milas Sofrası Ciğerci Durmuş Usta", "sulu", Group.FOOD, "Bodrum, Muğla",
            "Ciğer yanında sulu yemek/esnaf lokantası tarzı seçenekler sunan yerel mekan.",
            listOf("Yerel", "Esnaf"), "İşletme kayıtları",
            established="2000'den beri olarak tanıtılıyor", fame=8, local=9, type=9),

        // BODRUM / MAGARA
        p("Peynir Çiçeği Mağarası", "magara", Group.DISCOVER, "Gündoğan, Bodrum, Muğla",
            "Gündoğan çevresinde gerçek mağara ve tarihöncesi buluntularla ilişkilendirilen doğal/tarihî nokta.",
            listOf("Gerçek mağara", "Arkeoloji", "Gündoğan"), "Bodrum yerel gezi kaynakları",
            fame=9, local=9, type=10),

        // BODRUM / other dependable offline core
        p("Bodrum Kalesi", "kale", Group.DISCOVER, "Bodrum, Muğla",
            "Bodrum'un simge tarihî savunma yapısı.",
            listOf("Kale", "Simge"), "Kültür turizmi kaynakları", fame=10, local=10),
        p("Myndos Antik Kenti", "antik", Group.DISCOVER, "Gümüşlük, Bodrum, Muğla",
            "Antik Myndos yerleşiminin kalıntıları.",
            listOf("Antik kent", "Arkeoloji"), "Kültür turizmi kaynakları", fame=9, local=9),
        p("Bodrum Sualtı Arkeoloji Müzesi", "muze", Group.DISCOVER, "Bodrum Kalesi, Muğla",
            "Sualtı arkeolojisi koleksiyonlarıyla bilinen müze.",
            listOf("Müze", "Arkeoloji"), "Kültür turizmi kaynakları", fame=10, local=9),
        p("Halikarnassos Mausoleion", "tarihi", Group.DISCOVER, "Bodrum, Muğla",
            "Antik Dünyanın Yedi Harikası arasında anılan anıt mezar.",
            listOf("Tarih", "Antik"), "Kültür turizmi kaynakları", fame=10, local=9),
        p("Salmakis (Bardakçı) Koyu", "gizem", Group.DISCOVER, "Bodrum, Muğla",
            "Salmakis–Hermaphroditos efsanesiyle ilişkilendirilen fiziksel yer.",
            listOf("Efsane", "Tarih"), "Bodrum yerel tarih kaynakları", fame=8, local=8),

        p("Ortakent Yahşi Plajı", "plaj", Group.SEA, "Bodrum, Muğla",
            "Bodrum yarımadasında bilinen uzun plajlardan.",
            listOf("Plaj", "Yerel"), "Yerel gezi kaynakları", fame=9, local=9),
        p("Akyarlar Sahili", "kum", Group.SEA, "Bodrum, Muğla",
            "Kumlu kıyı ve yüzme için bilinen yarımada noktalarından.",
            listOf("Kumlu", "Plaj"), "Yerel gezi kaynakları", fame=8, local=9),
        p("Bitez Koyu", "koy", Group.SEA, "Bodrum, Muğla",
            "Korunaklı koy yapısıyla bilinen Bodrum kıyılarından.",
            listOf("Koy", "Bodrum"), "Yerel gezi kaynakları", fame=9, local=9)
    )

    fun find(region: String, categoryKey: String): List<PlaceItem> {
        val r = TextNorm.norm(region)
        return items
            .filter { it.categoryKey == categoryKey }
            .filter {
                val area = TextNorm.norm(it.area)
                when {
                    r == "bursa" -> area.contains("bursa")
                    r == "bodrum" -> area.contains("bodrum")
                    r == "mugla" -> area.contains("mugla")
                    else -> area.contains(r) || r.contains(area)
                }
            }
            .sortedByDescending { it.smartScore() }
    }
}

object RegionCatalog {
    private val regions = mapOf(
        "bursa" to RegionBounds("Bursa", 39.50, 27.85, 40.75, 30.10, 40.195, 29.060),
        "bodrum" to RegionBounds("Bodrum", 36.90, 27.05, 37.25, 27.70, 37.035, 27.430),
        "mugla" to RegionBounds("Muğla", 36.05, 27.00, 37.60, 29.85, 37.215, 28.365),
        "antalya" to RegionBounds("Antalya", 35.80, 29.20, 37.55, 32.70, 36.885, 30.705),
        "istanbul" to RegionBounds("İstanbul", 40.75, 27.95, 41.60, 29.95, 41.015, 28.980),
        "izmir" to RegionBounds("İzmir", 37.80, 26.20, 39.45, 28.60, 38.420, 27.140),
        "mersin" to RegionBounds("Mersin", 36.00, 32.50, 37.30, 35.10, 36.800, 34.630)
    )

    fun known(region: String): RegionBounds? = regions[TextNorm.norm(region)]
}

object SafetyRules {
    private val badSeaWords = listOf(
        "market","banka","bank","akbank","otel","hotel","cafe","kafe","restoran",
        "restaurant","eczane","mobilya","emlak","magaza","store","shop","petrol"
    )
    private val badDiscoverWords = listOf(
        "market","cafe","kafe","restoran","restaurant","otel","hotel","magaza","shop","store"
    )

    fun acceptLive(name: String, category: CategorySpec, osmType: String, brand: String = ""): Boolean {
        val n = TextNorm.norm(name)
        val t = TextNorm.norm(osmType)
        val b = TextNorm.norm(brand)

        if (category.group == Group.FOOD && b.isNotBlank()) return false

        if (category.group == Group.SEA && badSeaWords.any { n.contains(it) }) return false
        if (category.group == Group.DISCOVER && badDiscoverWords.any { n.contains(it) }) return false

        return when (category.strictType) {
            "beach" -> t.contains("beach")
            "bay" -> t.contains("bay")
            "cave" -> t.contains("cave")
            "museum" -> t.contains("museum")
            "castle" -> t.contains("castle") || t.contains("fort")
            "archaeological" -> t.contains("archaeological") || t.contains("ruins")
            "historic" -> t.contains("historic")
            "hotel" -> t.contains("hotel") || t.contains("motel") || t.contains("resort")
            "guest_house" -> t.contains("guest house") || t.contains("hostel") || t.contains("bed and breakfast")
            "apartment" -> t.contains("apartment")
            "camp" -> t.contains("camp")
            "food" -> t.contains("restaurant") || t.contains("fast food") || t.contains("cafe")
            "curated" -> false
            else -> false
        }
    }

    fun dedupe(items: List<PlaceItem>): List<PlaceItem> {
        val seen = mutableSetOf<String>()
        return items.filter {
            val key = TextNorm.norm(it.name) + "|" + TextNorm.norm(it.area)
            seen.add(key)
        }
    }

    fun mergeAndRank(offline: List<PlaceItem>, live: List<PlaceItem>): List<PlaceItem> =
        dedupe(offline + live).sortedByDescending { it.smartScore() }
}
