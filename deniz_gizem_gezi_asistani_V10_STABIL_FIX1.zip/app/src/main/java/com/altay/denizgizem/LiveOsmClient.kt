package com.altay.denizgizem

import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.Locale
import kotlin.math.*

object LiveOsmClient {
    private const val USER_AGENT = "DenizGizemGeziAsistani/10.0 Android personal-use"
    private const val NOMINATIM = "https://nominatim.openstreetmap.org/search"
    private val overpass = listOf(
        "https://overpass-api.de/api/interpreter",
        "https://overpass.private.coffee/api/interpreter"
    )
    private val geocodeCache = mutableMapOf<String, RegionBounds>()
    private var lastNominatim = 0L

    @Synchronized
    fun resolveRegion(region: String): RegionBounds {
        RegionCatalog.known(region)?.let { return it }

        val key = TextNorm.norm(region)
        geocodeCache[key]?.let { return it }

        val wait = 1100 - (System.currentTimeMillis() - lastNominatim)
        if (wait > 0) Thread.sleep(wait)

        val q = if (key.contains("turkiye") || key.contains("turkey")) region else "$region, Türkiye"
        val url = "$NOMINATIM?format=jsonv2&limit=1&countrycodes=tr&accept-language=tr&q=${enc(q)}"

        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "GET"
        c.connectTimeout = 9000
        c.readTimeout = 11000
        c.setRequestProperty("User-Agent", USER_AGENT)
        c.setRequestProperty("Accept", "application/json")

        val code = c.responseCode
        val body = read(if (code in 200..299) c.inputStream else c.errorStream)
        c.disconnect()
        lastNominatim = System.currentTimeMillis()
        if (code !in 200..299) error("Bölge servisi HTTP $code")

        val root = MiniJson.parse(body) as? List<*> ?: error("Bölge cevabı okunamadı")
        val first = root.firstOrNull() as? Map<*, *> ?: error("Bölge bulunamadı")
        val bb = first["boundingbox"] as? List<*> ?: error("Bölge sınırı yok")

        val g = RegionBounds(
            canonical = first["display_name"]?.toString() ?: region,
            south = bb[0].toString().toDouble(),
            north = bb[1].toString().toDouble(),
            west = bb[2].toString().toDouble(),
            east = bb[3].toString().toDouble(),
            centerLat = first["lat"].toString().toDouble(),
            centerLon = first["lon"].toString().toDouble()
        )
        geocodeCache[key] = g
        return g
    }

    fun search(bounds: RegionBounds, category: CategorySpec): List<PlaceItem> {
        if (category.strictType == "curated") return emptyList()
        val query = buildQuery(bounds, category)
        var last: Throwable? = null

        for (endpoint in overpass) {
            try {
                val body = post(endpoint, query)
                return parseResults(body, bounds, category)
            } catch (t: Throwable) {
                last = t
            }
        }
        throw last ?: IllegalStateException("Canlı harita servisi erişilemiyor")
    }

    fun buildQuery(b: RegionBounds, c: CategorySpec): String {
        val box = "${b.south},${b.west},${b.north},${b.east}"
        fun nwr(filters: String) = "nwr$filters($box);"
        val q = StringBuilder("[out:json][timeout:20];(")

        when (c.key) {
            "plaj" -> {
                q.append(nwr("[\"natural\"=\"beach\"][\"name\"]"))
                q.append(nwr("[\"leisure\"~\"^(beach|beach_resort)$\"][\"name\"]"))
            }
            "kum" -> {
                q.append(nwr("[\"natural\"=\"beach\"][\"surface\"~\"^(sand|fine_sand|sandy)$\",i][\"name\"]"))
                q.append(nwr("[\"natural\"=\"beach\"][\"name\"~\"kum|kumsal|sand\",i]"))
            }
            "koy" -> q.append(nwr("[\"natural\"=\"bay\"][\"name\"]"))
            "magara" -> q.append(nwr("[\"natural\"=\"cave_entrance\"][\"name\"]"))
            "muze" -> q.append(nwr("[\"tourism\"=\"museum\"][\"name\"]"))
            "kale" -> q.append(nwr("[\"historic\"~\"^(castle|fort)$\"][\"name\"]"))
            "antik" -> {
                q.append(nwr("[\"historic\"=\"archaeological_site\"][\"name\"]"))
                q.append(nwr("[\"historic\"=\"ruins\"][\"name\"]"))
            }
            "tarihi" -> q.append(nwr("[\"historic\"][\"name\"]"))
            "otel" -> q.append(nwr("[\"tourism\"~\"^(hotel|motel|resort)$\"][\"name\"]"))
            "pansiyon" -> q.append(nwr("[\"tourism\"~\"^(guest_house|hostel|bed_and_breakfast)$\"][\"name\"]"))
            "apart" -> q.append(nwr("[\"tourism\"=\"apartment\"][\"name\"]"))
            "kamp" -> q.append(nwr("[\"tourism\"~\"^(camp_site|caravan_site)$\"][\"name\"]"))
            else -> {
                val food = "[\"amenity\"~\"^(restaurant|fast_food|cafe)$\"]"
                when (c.key) {
                    "ciger" -> q.append(nwr(food + "[\"name\"~\"ciğer|ciger|arnavut|liver\",i]"))
                    "kofte" -> {
                        q.append(nwr(food + "[\"name\"~\"köfte|kofte|meatball\",i]"))
                        q.append(nwr(food + "[\"cuisine\"~\"meatball\",i][\"name\"]"))
                    }
                    "kebap" -> {
                        q.append(nwr(food + "[\"name\"~\"kebap|kebab|ocakbaşı|ocakbasi\",i]"))
                        q.append(nwr(food + "[\"cuisine\"~\"kebab\",i][\"name\"]"))
                    }
                    "sulu", "esnaf" -> q.append(nwr(food + "[\"name\"~\"lokanta|sofra|ev yemek|esnaf\",i]"))
                    "tavuk" -> {
                        q.append(nwr(food + "[\"name\"~\"tavuk|piliç|pilic|chicken\",i]"))
                        q.append(nwr(food + "[\"cuisine\"~\"chicken\",i][\"name\"]"))
                    }
                    "balik" -> {
                        q.append(nwr(food + "[\"name\"~\"balık|balik|fish|seafood\",i]"))
                        q.append(nwr(food + "[\"cuisine\"~\"fish|seafood\",i][\"name\"]"))
                    }
                    "kahvalti" -> {
                        q.append(nwr(food + "[\"name\"~\"kahvaltı|kahvalti|breakfast|serpme\",i]"))
                        q.append(nwr(food + "[\"breakfast\"=\"yes\"][\"name\"]"))
                    }
                }
            }
        }
        return q.append(");out center tags;").toString()
    }

    @Suppress("UNCHECKED_CAST")
    fun parseResults(body: String, bounds: RegionBounds, category: CategorySpec): List<PlaceItem> {
        val root = MiniJson.parse(body) as? Map<String, Any?> ?: return emptyList()
        val elements = root["elements"] as? List<Any?> ?: return emptyList()
        val out = mutableListOf<PlaceItem>()

        for (e0 in elements) {
            val e = e0 as? Map<String, Any?> ?: continue
            val tags = e["tags"] as? Map<String, Any?> ?: continue
            val name = tags["name"]?.toString()?.trim().orEmpty()
            if (name.isBlank()) continue

            var lat = (e["lat"] as? Number)?.toDouble()
            var lon = (e["lon"] as? Number)?.toDouble()
            if (lat == null || lon == null) {
                val center = e["center"] as? Map<String, Any?>
                lat = (center?.get("lat") as? Number)?.toDouble()
                lon = (center?.get("lon") as? Number)?.toDouble()
            }
            if (lat == null || lon == null || !bounds.contains(lat, lon)) continue

            val osmType = typeLabel(tags)
            val brand = tags["brand"]?.toString().orEmpty()
            if (!SafetyRules.acceptLive(name, category, osmType, brand)) continue

            val area = listOfNotNull(
                tags["addr:district"]?.toString(),
                tags["addr:city"]?.toString(),
                tags["addr:province"]?.toString()
            ).filter { it.isNotBlank() }.distinct().joinToString(", ").ifBlank { bounds.canonical }

            out += PlaceItem(
                name = name,
                categoryKey = category.key,
                group = category.group,
                area = area,
                address = listOfNotNull(
                    tags["addr:street"]?.toString(),
                    tags["addr:neighbourhood"]?.toString(),
                    tags["addr:suburb"]?.toString()
                ).filter { it.isNotBlank() }.joinToString(", "),
                why = "Canlı açık harita verisinde doğru mekân türüyle eşleşti.",
                tags = listOf("Canlı", osmType),
                sourceLabel = "OpenStreetMap",
                routeQuery = "$name $area",
                verified = false,
                fameScore = if (tags["wikipedia"] != null || tags["wikidata"] != null) 7 else 3,
                localScore = if (brand.isBlank()) 7 else 2,
                typeScore = 10,
                distanceKm = haversine(bounds.centerLat, bounds.centerLon, lat, lon),
                lat = lat,
                lon = lon,
                live = true
            )
        }

        return out.sortedByDescending { it.smartScore() }.take(25)
    }

    private fun typeLabel(t: Map<String, Any?>): String {
        return when {
            t["natural"]?.toString() == "beach" -> "Beach / Plaj"
            t["natural"]?.toString() == "bay" -> "Bay / Koy"
            t["natural"]?.toString() == "cave_entrance" -> "Cave / Mağara"
            t["tourism"]?.toString() == "museum" -> "Museum / Müze"
            !t["historic"]?.toString().isNullOrBlank() -> "Historic / ${t["historic"]}"
            !t["tourism"]?.toString().isNullOrBlank() -> "Konaklama / ${t["tourism"]}"
            !t["amenity"]?.toString().isNullOrBlank() -> {
                val a = t["amenity"]!!.toString()
                when (a) {
                    "restaurant" -> "Restaurant"
                    "fast_food" -> "Fast Food"
                    "cafe" -> "Cafe"
                    else -> a
                }
            }
            else -> "OpenStreetMap"
        }
    }

    private fun post(endpoint: String, query: String): String {
        val data = ("data=" + enc(query)).toByteArray(StandardCharsets.UTF_8)
        val c = URL(endpoint).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 11000
        c.readTimeout = 24000
        c.setRequestProperty("User-Agent", USER_AGENT)
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
        c.outputStream.use { it.write(data) }
        val code = c.responseCode
        val body = read(if (code in 200..299) c.inputStream else c.errorStream)
        c.disconnect()
        if (code !in 200..299) error("Harita servisi HTTP $code")
        return body
    }

    private fun read(input: InputStream?): String {
        if (input == null) return ""
        return BufferedReader(InputStreamReader(input, StandardCharsets.UTF_8)).use { r ->
            buildString {
                while (true) {
                    val line = r.readLine() ?: break
                    append(line)
                }
            }
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, StandardCharsets.UTF_8)

    private fun haversine(a: Double, o: Double, b: Double, p: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(b - a)
        val dLon = Math.toRadians(p - o)
        val q = sin(dLat / 2).pow(2) +
            cos(Math.toRadians(a)) * cos(Math.toRadians(b)) * sin(dLon / 2).pow(2)
        return r * 2 * atan2(sqrt(q), sqrt(1 - q))
    }
}
