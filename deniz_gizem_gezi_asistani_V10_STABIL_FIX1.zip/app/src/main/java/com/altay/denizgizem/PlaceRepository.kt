package com.altay.denizgizem

data class SearchBundle(
    val items: List<PlaceItem>,
    val offlineCount: Int,
    val liveCount: Int,
    val liveOk: Boolean,
    val status: String
)

object PlaceRepository {
    fun offline(region: String, category: CategorySpec): SearchBundle {
        val local = OfflineCatalog.find(region, category.key)
        return SearchBundle(
            items = local,
            offlineCount = local.size,
            liveCount = 0,
            liveOk = false,
            status = if (local.isNotEmpty())
                "${local.size} doğrulanmış çevrimdışı sonuç hazır"
            else
                "Çevrimdışı doğrulanmış kayıt yok; canlı arama denenecek"
        )
    }

    fun enrich(region: String, category: CategorySpec): SearchBundle {
        val local = OfflineCatalog.find(region, category.key)

        if (category.strictType == "curated") {
            return SearchBundle(
                items = local,
                offlineCount = local.size,
                liveCount = 0,
                liveOk = true,
                status = "Gizem/Efsane yalnız doğrulanmış kayıtları gösterir"
            )
        }

        return try {
            val bounds = LiveOsmClient.resolveRegion(region)
            val live = LiveOsmClient.search(bounds, category)
            val merged = SafetyRules.mergeAndRank(local, live)
            SearchBundle(
                items = merged,
                offlineCount = local.size,
                liveCount = live.size,
                liveOk = true,
                status = if (live.isEmpty())
                    "Canlı güvenli eşleşme yok; doğrulanmış sonuçlar korunuyor"
                else
                    "${local.size} doğrulanmış + ${live.size} canlı güvenli sonuç"
            )
        } catch (t: Throwable) {
            SearchBundle(
                items = local,
                offlineCount = local.size,
                liveCount = 0,
                liveOk = false,
                status = if (local.isNotEmpty())
                    "Canlı servis cevap vermedi; uygulama çevrimdışı sonuçlarla devam ediyor"
                else
                    "Canlı servis cevap vermedi ve bu kategori için çevrimdışı kayıt yok"
            )
        }
    }
}
