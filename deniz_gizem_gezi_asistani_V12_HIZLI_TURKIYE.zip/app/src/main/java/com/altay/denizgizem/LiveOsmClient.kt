package com.altay.denizgizem

import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import kotlin.math.*

object LiveOsmClient {
    private const val USER_AGENT = "DenizGizemGeziAsistani/12.0 (personal travel search; Turkiye)"
    private const val NOMINATIM = "https://nominatim.openstreetmap.org/search"
    private val overpass = listOf(
        "https://overpass.private.coffee/api/interpreter",
        "https://overpass-api.de/api/interpreter"
    )

    private val geocodeCache = mutableMapOf<String, RegionBounds>()
    private val quickCache = mutableMapOf<String, List<PlaceItem>>()
    private val deepCache = mutableMapOf<String, List<PlaceItem>>()
    private var lastNominatim = 0L

    /**
     * İlk ekrana hızlı sonuç vermek için tek Nominatim isteği yapar.
     * Bölgeyi ayrıca geocode etmez; böylece ilk sonuç için iki ayrı ağ turu beklenmez.
     */
    fun quickSearch(regionText: String, category: CategorySpec): List<PlaceItem> {
        val cacheKey = "quick|${TextNorm.norm(regionText)}|${category.key}"
        synchronized(quickCache) { quickCache[cacheKey]?.let { return it } }

        val term = queryTerms(category).first()
        val q = "$term $regionText Türkiye"
        val url = "$NOMINATIM?format=jsonv2&limit=18&countrycodes=tr&accept-language=tr" +
            "&addressdetails=1&namedetails=1&extratags=1&q=${enc(q)}"

        val body = nominatimGet(url)
        val out = parseNominatimDirect(body, regionText, category, term)
            .sortedByDescending { it.smartScore() }
            .take(12)

        synchronized(quickCache) { quickCache[cacheKey] = out }
        return out
    }

    /**
     * Hızlı sonuç ekrana geldikten sonra çalışır. Kesin bölge sınırını çözer,
     * Overpass'tan daha fazla POI getirir ve gerekirse ikinci hedefli terimi dener.
     */
    fun deepSearch(regionText: String, category: CategorySpec): List<PlaceItem> {
        val cacheKey = "deep|${TextNorm.norm(regionText)}|${category.key}"
        synchronized(deepCache) { deepCache[cacheKey]?.let { return it } }

        val bounds = resolveRegion(regionText)
        val all = mutableListOf<PlaceItem>()

        try {
            val body = overpassPost(buildQuery(bounds, category))
            all += parseOverpass(body, bounds, category)
        } catch (_: Throwable) {
            // Hızlı sonuç zaten ekranda; derin kaynak hatası kullanıcıyı bloke etmez.
        }

        if (all.size < 6) {
            val second = queryTerms(category).drop(1).firstOrNull()
            if (second != null) {
                try {
                    all += targetedNominatim(bounds, regionText, category, second)
                } catch (_: Throwable) { }
            }
        }

        val out = SafetyRules.dedupe(all)
            .filter { SafetyRules.isMeaningfulName(it.name) }
            .sortedByDescending { it.smartScore() }
            .take(24)
        synchronized(deepCache) { deepCache[cacheKey] = out }
        return out
    }

    @Synchronized
    fun resolveRegion(region: String): RegionBounds {
        RegionCatalog.known(region)?.let { return it }
        val key = TextNorm.norm(region)
        geocodeCache[key]?.let { return it }

        val q = if (key.contains("turkiye") || key.contains("turkey")) region else "$region, Türkiye"
        val body = nominatimGet(
            "$NOMINATIM?format=jsonv2&limit=1&countrycodes=tr&accept-language=tr&addressdetails=1&q=${enc(q)}"
        )
        val root = MiniJson.parse(body) as? List<*> ?: error("Bölge cevabı okunamadı")
        val first = root.firstOrNull() as? Map<*, *> ?: error("Türkiye içinde bölge bulunamadı")
        val bb = first["boundingbox"] as? List<*> ?: error("Bölge sınırı yok")
        val g = RegionBounds(
            canonical = first["display_name"]?.toString() ?: region,
            south = bb[0].toString().toDouble(),
            north = bb[1].toString().toDouble(),
            west = bb[2].toString().toDouble(),
            east = bb[3].toString().toDouble(),
            centerLat = first["lat"].toString().toDouble(),
            centerLon = first["lon"].toString().toDouble()
        )
        geocodeCache[key] = g
        return g
    }

    fun queryTerms(c: CategorySpec): List<String> = when (c.key) {
        "ciger" -> listOf("ciğerci", "arnavut ciğeri")
        "kofte" -> listOf("köfteci", "köfte restoranı")
        "kebap" -> listOf("kebapçı", "ocakbaşı")
        "sulu" -> listOf("ev yemekleri", "sulu yemek lokantası")
        "tavuk" -> listOf("tavukçu", "tavuk restoran")
        "esnaf" -> listOf("esnaf lokantası", "lokanta")
        "balik" -> listOf("balık restoranı", "balıkçı")
        "kahvalti" -> listOf("kahvaltı", "serpme kahvaltı")
        "plaj" -> listOf("plaj", "halk plajı")
        "kum" -> listOf("sığ kumlu plaj", "kumsal")
        "koy" -> listOf("koy", "koyu")
        "antik" -> listOf("antik kent", "ören yeri")
        "kale" -> listOf("kale", "hisar")
        "magara" -> listOf("mağara", "cave")
        "muze" -> listOf("müze", "museum")
        "tarihi" -> listOf("tarihi yer", "tarihi yapı")
        "gizem" -> listOf("efsane tarihi yer", "mitolojik yer")
        "pansiyon" -> listOf("pansiyon", "guest house")
        "apart" -> listOf("apart otel", "apart")
        "otel" -> listOf("otel", "hotel")
        "kamp" -> listOf("kamp alanı", "camp site")
        else -> listOf(c.title)
    }

    fun buildQuery(b: RegionBounds, c: CategorySpec): String {
        val box = "${b.south},${b.west},${b.north},${b.east}"
        fun nwr(filters: String) = "nwr$filters($box);"
        val q = StringBuilder("[out:json][timeout:9];(")
        when (c.key) {
            "plaj" -> {
                q.append(nwr("[\"natural\"=\"beach\"][\"name\"]"))
                q.append(nwr("[\"leisure\"~\"^(beach|beach_resort)$\"][\"name\"]"))
            }
            "kum" -> {
                q.append(nwr("[\"natural\"=\"beach\"][\"surface\"~\"sand|fine_sand|sandy\",i][\"name\"]"))
                q.append(nwr("[\"natural\"=\"beach\"][\"name\"~\"kum|kumsal|sand\",i]"))
                q.append(nwr("[\"natural\"=\"beach\"][\"description\"~\"sığ|sig|shallow|kum|sand\",i][\"name\"]"))
            }
            "koy" -> q.append(nwr("[\"natural\"=\"bay\"][\"name\"]"))
            "magara" -> {
                q.append(nwr("[\"natural\"=\"cave_entrance\"][\"name\"]"))
                q.append(nwr("[\"natural\"=\"cave\"][\"name\"]"))
            }
            "muze" -> q.append(nwr("[\"tourism\"=\"museum\"][\"name\"]"))
            "kale" -> {
                q.append(nwr("[\"historic\"~\"^(castle|fort|city_gate|citywalls)$\"][\"name\"]"))
                q.append(nwr("[\"name\"~\"kale|hisar|sur|fort\",i][\"historic\"][\"name\"]"))
            }
            "antik" -> {
                q.append(nwr("[\"historic\"=\"archaeological_site\"][\"name\"]"))
                q.append(nwr("[\"historic\"=\"ruins\"][\"name\"]"))
                q.append(nwr("[\"tourism\"=\"attraction\"][\"name\"~\"antik|ören|oren\",i]"))
            }
            "tarihi" -> q.append(nwr("[\"historic\"][\"name\"]"))
            "gizem" -> {
                q.append(nwr("[\"historic\"][\"wikipedia\"][\"name\"]"))
                q.append(nwr("[\"historic\"][\"wikidata\"][\"name\"]"))
                q.append(nwr("[\"natural\"=\"cave_entrance\"][\"wikipedia\"][\"name\"]"))
            }
            "otel" -> q.append(nwr("[\"tourism\"~\"^(hotel|motel|resort)$\"][\"name\"]"))
            "pansiyon" -> q.append(nwr("[\"tourism\"~\"^(guest_house|hostel|bed_and_breakfast)$\"][\"name\"]"))
            "apart" -> q.append(nwr("[\"tourism\"=\"apartment\"][\"name\"]"))
            "kamp" -> q.append(nwr("[\"tourism\"~\"^(camp_site|caravan_site)$\"][\"name\"]"))
            else -> {
                val food = "[\"amenity\"~\"^(restaurant|fast_food|cafe)$\"]"
                when (c.key) {
                    "ciger" -> q.append(nwr(food + "[\"name\"~\"ciğer|ciger|arnavut|liver\",i]"))
                    "kofte" -> {
                        q.append(nwr(food + "[\"name\"~\"köfte|kofte|köfteci|koftecisi|meatball\",i]"))
                        q.append(nwr(food + "[\"cuisine\"~\"meatball|köfte|kofte\",i][\"name\"]"))
                    }
                    "kebap" -> {
                        q.append(nwr(food + "[\"name\"~\"kebap|kebab|ocakbaşı|ocakbasi\",i]"))
                        q.append(nwr(food + "[\"cuisine\"~\"kebab\",i][\"name\"]"))
                    }
                    "sulu", "esnaf" -> q.append(nwr(food + "[\"name\"~\"lokanta|sofra|ev yemek|esnaf|tabldot\",i]"))
                    "tavuk" -> q.append(nwr(food + "[\"name\"~\"tavuk|piliç|pilic|chicken\",i]"))
                    "balik" -> q.append(nwr(food + "[\"name\"~\"balık|balik|fish|seafood\",i]"))
                    "kahvalti" -> q.append(nwr(food + "[\"name\"~\"kahvaltı|kahvalti|breakfast|serpme\",i]"))
                }
            }
        }
        return q.append(");out center tags 50;").toString()
    }

    @Suppress("UNCHECKED_CAST")
    fun parseOverpass(body: String, bounds: RegionBounds, category: CategorySpec): List<PlaceItem> {
        val root = MiniJson.parse(body) as? Map<String, Any?> ?: return emptyList()
        val elements = root["elements"] as? List<Any?> ?: return emptyList()
        val out = mutableListOf<PlaceItem>()
        for (e0 in elements) {
            val e = e0 as? Map<String, Any?> ?: continue
            val tags = e["tags"] as? Map<String, Any?> ?: continue
            val name = tags["name"]?.toString()?.trim().orEmpty()
            if (!SafetyRules.isMeaningfulName(name)) continue
            var lat = (e["lat"] as? Number)?.toDouble()
            var lon = (e["lon"] as? Number)?.toDouble()
            if (lat == null || lon == null) {
                val center = e["center"] as? Map<String, Any?>
                lat = (center?.get("lat") as? Number)?.toDouble()
                lon = (center?.get("lon") as? Number)?.toDouble()
            }
            if (lat == null || lon == null || !bounds.contains(lat, lon)) continue

            val osmType = typeLabel(tags)
            val brand = tags["brand"]?.toString().orEmpty()
            val evidence = listOfNotNull(
                tags["cuisine"]?.toString(), tags["description"]?.toString(), tags["surface"]?.toString(),
                tags["wikipedia"]?.toString()?.let { "wikipedia $it" },
                tags["wikidata"]?.toString()?.let { "wikidata $it" }
            ).joinToString(" ")
            if (!SafetyRules.acceptLive(name, category, osmType, brand, evidence)) continue

            val hasWiki = tags["wikipedia"] != null || tags["wikidata"] != null
            val hasHistory = !tags["start_date"]?.toString().isNullOrBlank()
            val exactFood = category.group == Group.FOOD && SafetyRules.foodKeywords(category.key).any {
                TextNorm.norm("$name $evidence").contains(it)
            }
            val fame = when {
                hasWiki -> 9
                hasHistory -> 8
                exactFood -> 7
                else -> 4
            }
            val area = listOfNotNull(
                tags["addr:district"]?.toString(), tags["addr:city"]?.toString(), tags["addr:province"]?.toString()
            ).filter { it.isNotBlank() }.distinct().joinToString(", ").ifBlank { bounds.canonical }

            out += PlaceItem(
                name=name, categoryKey=category.key, group=category.group, area=area,
                address=listOfNotNull(tags["addr:street"]?.toString(), tags["addr:neighbourhood"]?.toString(), tags["addr:suburb"]?.toString()).filter { it.isNotBlank() }.joinToString(", "),
                why=when {
                    category.key == "gizem" && hasWiki -> "Kaynak bağlantısı olan tarihî/doğal nokta."
                    category.group == Group.FOOD -> "Seçtiğin yemek türüyle adı veya mutfak etiketi doğrudan eşleşiyor."
                    else -> "Seçtiğin kategoriyle canlı açık harita verisinde doğrudan eşleşiyor."
                },
                tags=listOfNotNull("Canlı", osmType, if (hasWiki) "Kaynaklı" else null),
                established=tags["start_date"]?.toString().orEmpty(),
                sourceLabel=if (hasWiki) "OpenStreetMap + Wikipedia/Wikidata etiketi" else "OpenStreetMap",
                routeQuery="$name $area", verified=false, fameScore=fame,
                localScore=if (brand.isBlank()) 8 else 3, typeScore=10,
                distanceKm=haversine(bounds.centerLat,bounds.centerLon,lat,lon), lat=lat, lon=lon, live=true
            )
        }
        return out.sortedByDescending { it.smartScore() }.take(24)
    }

    @Suppress("UNCHECKED_CAST")
    private fun parseNominatimDirect(body: String, regionText: String, category: CategorySpec, term: String): List<PlaceItem> {
        val root = MiniJson.parse(body) as? List<Any?> ?: return emptyList()
        val out = mutableListOf<PlaceItem>()
        val regionNorm = TextNorm.norm(regionText)
        for (x0 in root) {
            val x = x0 as? Map<String, Any?> ?: continue
            val lat = x["lat"]?.toString()?.toDoubleOrNull() ?: continue
            val lon = x["lon"]?.toString()?.toDoubleOrNull() ?: continue
            val display = x["display_name"]?.toString().orEmpty()
            if (!TextNorm.norm(display).contains(regionNorm)) continue

            val named = x["namedetails"] as? Map<String, Any?>
            val name = named?.get("name")?.toString()?.trim()?.takeIf { it.isNotBlank() }
                ?: x["name"]?.toString()?.trim()?.takeIf { it.isNotBlank() }
                ?: continue
            if (!SafetyRules.isMeaningfulName(name)) continue

            val clazz = x["category"]?.toString().orEmpty()
            val type = x["type"]?.toString().orEmpty()
            val extra = x["extratags"] as? Map<String, Any?>
            val evidence = buildString {
                extra?.forEach { (k,v) -> append(k).append(' ').append(v).append(' ') }
            }
            val mapped = nominatimType(clazz,type,name)
            if (!SafetyRules.acceptLive(name,category,mapped,extra?.get("brand")?.toString().orEmpty(),evidence)) continue

            val importance = (x["importance"] as? Number)?.toDouble()
                ?: x["importance"]?.toString()?.toDoubleOrNull() ?: 0.0
            val fame = when {
                importance >= 0.5 -> 9
                importance >= 0.2 -> 8
                importance >= 0.05 -> 7
                else -> 6
            }
            out += PlaceItem(
                name=name, categoryKey=category.key, group=category.group,
                area=areaFromNominatim(x, regionText), address=display,
                why=if(category.group == Group.FOOD)
                    "Hızlı aramada seçtiğin yemek türüyle adı veya mutfak bilgisi eşleşti."
                else "Hızlı aramada seçtiğin kategoriyle eşleşti.",
                tags=listOf("⚡ Hızlı", term), sourceLabel="OpenStreetMap Nominatim",
                routeQuery="$name $regionText", verified=false, fameScore=fame,
                localScore=8, typeScore=10, lat=lat, lon=lon, live=true
            )
        }
        return SafetyRules.dedupe(out)
    }

    private fun targetedNominatim(bounds: RegionBounds, regionText: String, category: CategorySpec, term: String): List<PlaceItem> {
        val q = "$term $regionText Türkiye"
        val view = "${bounds.west},${bounds.north},${bounds.east},${bounds.south}"
        val url = "$NOMINATIM?format=jsonv2&limit=16&countrycodes=tr&accept-language=tr" +
            "&addressdetails=1&namedetails=1&extratags=1&bounded=1&viewbox=${enc(view)}&q=${enc(q)}"
        val body = nominatimGet(url)
        return parseNominatimDirect(body, regionText, category, term)
            .filter { it.lat != null && it.lon != null && bounds.contains(it.lat, it.lon) }
    }

    @Suppress("UNCHECKED_CAST")
    private fun areaFromNominatim(x: Map<String, Any?>, fallback: String): String {
        val address = x["address"] as? Map<String, Any?>
        if (address == null) return fallback
        return listOfNotNull(
            address["suburb"]?.toString(), address["town"]?.toString(), address["city"]?.toString(),
            address["county"]?.toString(), address["state"]?.toString()
        ).filter { it.isNotBlank() }.distinct().take(3).joinToString(", ").ifBlank { fallback }
    }

    private fun nominatimType(clazz: String, type: String, name: String): String {
        val s = TextNorm.norm("$clazz $type $name")
        return when {
            listOf("restaurant","fast food","cafe").any { s.contains(it) } -> "Restaurant"
            s.contains("beach") -> "Beach / Plaj"
            s.contains("bay") -> "Bay / Koy"
            s.contains("cave") -> "Cave / Mağara"
            s.contains("museum") -> "Museum / Müze"
            s.contains("castle") || s.contains("fort") || s.contains("city gate") -> "Historic / Castle"
            s.contains("archaeological") || s.contains("ruins") -> "Historic / Archaeological"
            s.contains("historic") || s.contains("memorial") || s.contains("monument") -> "Historic"
            s.contains("hotel") || s.contains("motel") || s.contains("resort") -> "Hotel"
            s.contains("guest house") || s.contains("hostel") -> "Guest House"
            s.contains("apartment") -> "Apartment"
            s.contains("camp") -> "Camp"
            else -> "$clazz / $type"
        }
    }

    private fun typeLabel(t: Map<String, Any?>): String = when {
        t["natural"]?.toString() == "beach" -> "Beach / Plaj"
        t["natural"]?.toString() == "bay" -> "Bay / Koy"
        t["natural"]?.toString() == "cave_entrance" || t["natural"]?.toString() == "cave" -> "Cave / Mağara"
        t["tourism"]?.toString() == "museum" -> "Museum / Müze"
        !t["historic"]?.toString().isNullOrBlank() -> "Historic / ${t["historic"]}"
        !t["tourism"]?.toString().isNullOrBlank() -> "Konaklama / ${t["tourism"]}"
        !t["amenity"]?.toString().isNullOrBlank() -> when (t["amenity"]!!.toString()) {
            "restaurant" -> "Restaurant"; "fast_food" -> "Fast Food"; "cafe" -> "Cafe"; else -> t["amenity"]!!.toString()
        }
        else -> "OpenStreetMap"
    }

    private fun overpassPost(query: String): String {
        var last: Throwable? = null
        for (endpoint in overpass) {
            try {
                val data = ("data=" + enc(query)).toByteArray(StandardCharsets.UTF_8)
                val c = URL(endpoint).openConnection() as HttpURLConnection
                c.requestMethod="POST"; c.doOutput=true; c.connectTimeout=5500; c.readTimeout=9000
                c.setRequestProperty("User-Agent",USER_AGENT)
                c.setRequestProperty("Content-Type","application/x-www-form-urlencoded; charset=UTF-8")
                c.outputStream.use { it.write(data) }
                val code=c.responseCode
                val body=read(if(code in 200..299)c.inputStream else c.errorStream)
                c.disconnect()
                if(code !in 200..299) error("Overpass HTTP $code")
                return body
            } catch(t:Throwable){ last=t }
        }
        throw last ?: IllegalStateException("Overpass erişilemiyor")
    }

    @Synchronized
    private fun nominatimGet(url: String): String {
        val wait = 1050 - (System.currentTimeMillis() - lastNominatim)
        if (wait > 0) Thread.sleep(wait)
        val c=URL(url).openConnection() as HttpURLConnection
        c.requestMethod="GET"; c.connectTimeout=5000; c.readTimeout=7000
        c.setRequestProperty("User-Agent",USER_AGENT); c.setRequestProperty("Accept","application/json")
        val code=c.responseCode
        val body=read(if(code in 200..299)c.inputStream else c.errorStream)
        c.disconnect(); lastNominatim=System.currentTimeMillis()
        if(code !in 200..299) error("Nominatim HTTP $code")
        return body
    }

    private fun read(input:InputStream?):String = if(input==null) "" else BufferedReader(InputStreamReader(input,StandardCharsets.UTF_8)).use { r -> buildString { while(true){ val line=r.readLine()?:break; append(line) } } }
    private fun enc(s:String)=URLEncoder.encode(s,StandardCharsets.UTF_8)
    private fun haversine(a:Double,o:Double,b:Double,p:Double):Double { val r=6371.0; val dLat=Math.toRadians(b-a); val dLon=Math.toRadians(p-o); val q=sin(dLat/2).pow(2)+cos(Math.toRadians(a))*cos(Math.toRadians(b))*sin(dLon/2).pow(2); return r*2*atan2(sqrt(q),sqrt(1-q)) }
}
