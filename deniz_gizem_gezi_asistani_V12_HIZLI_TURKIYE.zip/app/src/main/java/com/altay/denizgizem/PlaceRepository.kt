package com.altay.denizgizem

data class SearchBundle(
    val regionKey: String,
    val categoryKey: String,
    val items: List<PlaceItem>,
    val offlineCount: Int,
    val liveCount: Int,
    val liveOk: Boolean,
    val deepPending: Boolean,
    val status: String
)

object PlaceRepository {
    fun offline(region: String, category: CategorySpec): SearchBundle {
        val local = OfflineCatalog.find(region, category.key)
        return SearchBundle(
            regionKey=TextNorm.norm(region), categoryKey=category.key,
            items=local.take(15), offlineCount=local.size, liveCount=0,
            liveOk=false, deepPending=true,
            status=if(local.isNotEmpty())
                "${local.size} doğrulanmış sonuç anında hazır"
            else
                "⚡ Hızlı canlı arama başlatıldı"
        )
    }

    fun quick(region: String, category: CategorySpec): SearchBundle {
        val local = OfflineCatalog.find(region, category.key)
        return try {
            val quick = LiveOsmClient.quickSearch(region, category)
            val merged = SafetyRules.mergeAndRank(local, quick)
                .filter { it.categoryKey == category.key && SafetyRules.isMeaningfulName(it.name) }
                .take(15)
            SearchBundle(
                regionKey=TextNorm.norm(region), categoryKey=category.key,
                items=merged, offlineCount=local.size, liveCount=quick.size,
                liveOk=true, deepPending=true,
                status=when {
                    merged.isEmpty() -> "İlk hızlı taramada güvenli eşleşme çıkmadı; derin tarama sürüyor"
                    quick.isEmpty() && local.isNotEmpty() -> "Doğrulanmış sonuçlar hazır; daha fazla yer aranıyor"
                    else -> "⚡ ${merged.size} güvenli sonuç hazır • daha fazla yer aranıyor"
                }
            )
        } catch (_: Throwable) {
            SearchBundle(
                regionKey=TextNorm.norm(region), categoryKey=category.key,
                items=local.take(15), offlineCount=local.size, liveCount=0,
                liveOk=local.isNotEmpty(), deepPending=true,
                status=if(local.isNotEmpty()) "Doğrulanmış sonuçlar hazır • derin tarama sürüyor"
                else "Hızlı kaynak cevap vermedi • derin tarama sürüyor"
            )
        }
    }

    fun deep(region: String, category: CategorySpec, current: List<PlaceItem>): SearchBundle {
        val local = OfflineCatalog.find(region, category.key)
        return try {
            val deep = LiveOsmClient.deepSearch(region, category)
            val merged = SafetyRules.mergeAndRank(SafetyRules.mergeAndRank(local, current), deep)
                .filter { it.categoryKey == category.key && SafetyRules.isMeaningfulName(it.name) }
                .take(20)
            SearchBundle(
                regionKey=TextNorm.norm(region), categoryKey=category.key,
                items=merged, offlineCount=local.size,
                liveCount=merged.count { it.live }, liveOk=true, deepPending=false,
                status=when {
                    merged.isEmpty() -> "Bu bölgede güvenilir kategori eşleşmesi bulunamadı"
                    else -> "✅ ${merged.size} güvenli sonuç • tarama tamamlandı"
                }
            )
        } catch (_: Throwable) {
            val merged = SafetyRules.mergeAndRank(local, current)
                .filter { it.categoryKey == category.key && SafetyRules.isMeaningfulName(it.name) }
                .take(20)
            SearchBundle(
                regionKey=TextNorm.norm(region), categoryKey=category.key,
                items=merged, offlineCount=local.size, liveCount=merged.count { it.live },
                liveOk=merged.isNotEmpty(), deepPending=false,
                status=if(merged.isNotEmpty())
                    "Mevcut güvenli sonuçlar gösteriliyor; derin kaynak geçici olarak cevap vermedi"
                else
                    "Canlı kaynak geçici olarak cevap vermedi; tekrar dene"
            )
        }
    }
}
