#!/usr/bin/env python3
import argparse, json, math, re, sqlite3, unicodedata

def norm(s):
    s=(s or '').lower().replace('ı','i').replace('ğ','g').replace('ü','u').replace('ş','s').replace('ö','o').replace('ç','c')
    s=unicodedata.normalize('NFD',s);s=''.join(ch for ch in s if unicodedata.category(ch)!='Mn')
    return re.sub(r'[^a-z0-9]+',' ',s).strip()

def hav(a,b,c,d):
    r=6371000;p1=math.radians(a);p2=math.radians(c);dp=math.radians(c-a);dl=math.radians(d-b)
    x=math.sin(dp/2)**2+math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return 2*r*math.asin(min(1,math.sqrt(x)))

def nearby_duplicates(db):
    thresholds={'magara':1300,'antik':650,'kale':500,'plaj':350,'koy':650}
    bad=[]
    for key,thr in thresholds.items():
        groups=db.execute("SELECT province_norm,canonical_norm FROM poi WHERE category_key=? AND canonical_norm<>'' GROUP BY province_norm,canonical_norm HAVING count(*)>1",(key,)).fetchall()
        for prov,can in groups:
            rows=db.execute("SELECT id,name,lat,lon FROM poi WHERE category_key=? AND province_norm=? AND canonical_norm=?",(key,prov,can)).fetchall()
            for i in range(len(rows)):
                for j in range(i+1,len(rows)):
                    a,b=rows[i],rows[j]
                    if abs(a[2])<0.01 or abs(b[2])<0.01: continue
                    if hav(a[2],a[3],b[2],b[3])<=thr:
                        bad.append((key,a[1],b[1],round(hav(a[2],a[3],b[2],b[3]))));break
                if bad and bad[-1][0]==key and bad[-1][1]==rows[i][1]: break
    return bad

def main():
    ap=argparse.ArgumentParser();ap.add_argument('db');ap.add_argument('--strict',action='store_true');a=ap.parse_args();db=sqlite3.connect(a.db)
    prov=db.execute("select count(distinct name_norm) from regions where kind='province'").fetchone()[0]
    dist=db.execute("select count(*) from regions where kind='district'").fetchone()[0]
    poi=db.execute('select count(*) from poi').fetchone()[0]
    legends=db.execute('select count(*) from legends').fetchone()[0]
    legcov=db.execute('select count(distinct province_norm) from legends').fetchone()[0]
    aras=db.execute("select count(*) from poi where category_key='ciger' and name_norm like '%aras kargo%'").fetchone()[0]
    generic_leg=db.execute("select count(*) from legends where title_norm like '%tanitim videosu%' or title_norm like '%medya kutuphanesi%'").fetchone()[0]
    oylat=db.execute("select count(*) from poi where category_key='magara' and province_norm=? and canonical_norm='oylat'",(norm('Bursa'),)).fetchone()[0]
    besler=db.execute("select start_year,is_chain,curated from poi where category_key='kofte' and province_norm=? and name_norm like '%besler%' order by curated desc,start_year asc limit 1",(norm('Bursa'),)).fetchone()
    bursa_first=db.execute("""select name,start_year,is_chain from poi where category_key='kofte' and province_norm=? order by curated desc,case when start_year is null then 1 else 0 end,start_year asc,is_chain asc,source_count desc,quality_rank desc limit 1""",(norm('Bursa'),)).fetchone()
    near_dups=nearby_duplicates(db)
    summary={'provinces':prov,'districts':dist,'poi':poi,'legends':legends,'legend_province_coverage':legcov,'aras_kargo_as_ciger':aras,'generic_legends':generic_leg,'oylat_cave_cards':oylat,'besler':besler,'bursa_first_kofte':bursa_first,'near_duplicate_pairs':len(near_dups),'near_duplicate_examples':near_dups[:10]}
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    if a.strict:
        if prov!=81: raise SystemExit('81 il yok')
        if dist<900: raise SystemExit(f'ilce yetersiz {dist}')
        if poi<10000: raise SystemExit(f'poi cok az {poi}')
        if legcov<81: raise SystemExit(f'efsane il kapsami {legcov}/81')
        if aras: raise SystemExit('Aras Kargo hala ciger sonucunda')
        if generic_leg: raise SystemExit('Tanitim videosu/medya kutuphanesi efsane olarak kalmis')
        if oylat>1: raise SystemExit(f'Oylat Magarasi tekrar ediyor: {oylat}')
        if not besler or besler[0]!=1893: raise SystemExit('Besler 1893 koklu testi gecmedi')
        if not bursa_first or 'besler' not in norm(bursa_first[0]): raise SystemExit(f'Bursa kofte ilk sonuc koklu degil: {bursa_first}')
        if near_dups: raise SystemExit(f'Yakindaki tekrar fiziksel yerler kaldi: {near_dups[:5]}')
    db.close()
if __name__=='__main__':main()
