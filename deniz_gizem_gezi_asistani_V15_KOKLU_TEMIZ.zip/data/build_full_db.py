#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, concurrent.futures, html, json, math, os, re, sqlite3, subprocess, tempfile, time, unicodedata
from pathlib import Path
from urllib.parse import quote, urljoin, urlparse
import requests
from bs4 import BeautifulSoup
from shapely.geometry import shape, Point
from shapely.strtree import STRtree
import duckdb

HERE=Path(__file__).resolve().parent
MANIFEST=json.loads((HERE/"provinces.json").read_text(encoding="utf-8"))
PROVINCES=MANIFEST["provinces"]
ALIASES=MANIFEST["aliases"]
TR_BBOX=(25.45,35.70,45.05,42.25)
LEGEND_WORDS=("efsane","rivayet","menkibe","menkıbe","soylence","söylence","mitoloji","mitolojik","inanis","inanış","keramet")
BAD_NAMES={"restaurant","restoran","cafe","kafe","otel","hotel","market","shop","store","isimsiz","unnamed"}

def norm(s):
    s=(s or "").lower().replace("ı","i").replace("ğ","g").replace("ü","u").replace("ş","s").replace("ö","o").replace("ç","c")
    s=unicodedata.normalize("NFD",s);s="".join(ch for ch in s if unicodedata.category(ch)!="Mn")
    return re.sub(r"[^a-z0-9]+"," ",s).strip()

def slug(s): return norm(s).replace(" ","")

def schema(db):
    db.executescript("""
    PRAGMA journal_mode=OFF; PRAGMA synchronous=OFF; PRAGMA temp_store=MEMORY;
    CREATE TABLE meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
    CREATE TABLE regions(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,name_norm TEXT,kind TEXT,province TEXT,province_norm TEXT,lat REAL,lon REAL,south REAL,west REAL,north REAL,east REAL);
    CREATE INDEX idx_region_name ON regions(name_norm);
    CREATE INDEX idx_region_prov ON regions(province_norm,kind);
    CREATE TABLE aliases(alias_norm TEXT PRIMARY KEY,target_norm TEXT NOT NULL);
    CREATE TABLE poi(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,name_norm TEXT,category_key TEXT,province TEXT,province_norm TEXT,district TEXT,district_norm TEXT,address TEXT,detail TEXT,source TEXT,source_url TEXT,match_note TEXT,route_query TEXT,lat REAL,lon REAL,rank_score REAL,source_count INTEGER,curated INTEGER);
    CREATE INDEX idx_poi_prov_cat ON poi(province_norm,category_key,rank_score);
    CREATE INDEX idx_poi_dist_cat ON poi(district_norm,category_key,rank_score);
    CREATE INDEX idx_poi_name ON poi(name_norm);
    CREATE TABLE legends(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,title_norm TEXT,province TEXT,province_norm TEXT,district TEXT,district_norm TEXT,summary TEXT,source_title TEXT,source_url TEXT,place_query TEXT,rank_score REAL,curated INTEGER);
    CREATE UNIQUE INDEX uq_leg ON legends(title_norm,province_norm,district_norm);
    CREATE INDEX idx_leg_prov ON legends(province_norm,rank_score);
    CREATE INDEX idx_leg_dist ON legends(district_norm,rank_score);
    """)

def osm_boundaries(pbf,tmp):
    filt=tmp/"admin.osm.pbf";geo=tmp/"admin.geojsonseq"
    subprocess.run(["osmium","tags-filter",str(pbf),"r/boundary=administrative","-o",str(filt),"--overwrite"],check=True)
    subprocess.run(["osmium","export",str(filt),"-f","geojsonseq","-o",str(geo),"--overwrite"],check=True)
    return geo

def load_regions(db,geo):
    provinces=[];districts=[]
    raw_levels={"4":0,"6":0}
    with geo.open("r",encoding="utf-8",errors="replace") as f:
        for line in f:
            line=line.strip().lstrip("\\x1e")
            if not line:continue
            try:feat=json.loads(line)
            except:continue
            p=feat.get("properties") or {};name=(p.get("name") or "").strip()
            level=str(p.get("admin_level") or "")
            if level in raw_levels: raw_levels[level]+=1
            if not name or level not in ("4","6"):continue
            try:g=shape(feat["geometry"])
            except:continue
            if g.is_empty:continue
            rp=g.representative_point();bounds=g.bounds
            row={"name":name,"geometry":g,"lat":rp.y,"lon":rp.x,"bounds":bounds}
            (provinces if level=="4" else districts).append(row)

    print(json.dumps({
        "osm_admin4_raw":raw_levels["4"],
        "osm_admin6_raw":raw_levels["6"],
        "osm_admin4_valid_geometry":len(provinces),
        "osm_admin6_valid_geometry":len(districts)
    },ensure_ascii=False))

    prov_by_norm={}
    for r in provinces:
        n=norm(r["name"])
        target=next((p for p in PROVINCES if norm(p)==n),None)
        if target: prov_by_norm[n]=(target,r)
    missing=[p for p in PROVINCES if norm(p) not in prov_by_norm]
    if missing: raise RuntimeError("OSM'de eksik il sınırı: "+", ".join(missing))

    prov_items=list(prov_by_norm.values())
    for official,r in prov_items:
        w,s,e,n=r["bounds"]
        db.execute("INSERT INTO regions(name,name_norm,kind,province,province_norm,lat,lon,south,west,north,east) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                   (official,norm(official),"province",official,norm(official),r["lat"],r["lon"],s,w,n,e))

    # Sadece 81 il geometrisi var. 922 civarı ilçe için doğrudan 81 geometriyi
    # kontrol etmek hızlıdır ve Shapely STRtree numpy.int64 uyumsuzluğunu tamamen kaldırır.
    kept=[]
    for d in districts:
        pt=d["geometry"].representative_point();prov=None
        for official,r in prov_items:
            pg=r["geometry"]
            if pg.contains(pt) or pg.touches(pt):
                prov=official;break
        if not prov:continue
        w,s,e,n=d["bounds"]
        db.execute("INSERT INTO regions(name,name_norm,kind,province,province_norm,lat,lon,south,west,north,east) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                   (d["name"],norm(d["name"]),"district",prov,norm(prov),d["lat"],d["lon"],s,w,n,e))
        kept.append((d["name"],prov,d["geometry"]))

    print(json.dumps({"osm_districts_kept":len(kept)},ensure_ascii=False))
    return [(p,r["geometry"]) for p,r in prov_items],kept


def get_overture_release():
    con=duckdb.connect()
    try:
        row=con.execute("SELECT latest FROM 'https://stac.overturemaps.org/catalog.json'").fetchone()
        if not row or not row[0]: raise RuntimeError("Overture latest release bulunamadı")
        return str(row[0])
    finally:
        con.close()


def overture_district_fallback(db,tmp,provs,existing):
    """OSM admin_level=6 alanları çıkmazsa Overture county polygonlarını kullan."""
    if len(existing)>=900:
        return existing
    release=get_overture_release()
    con=duckdb.connect()
    con.execute("INSTALL spatial; LOAD spatial; INSTALL httpfs; LOAD httpfs; SET s3_region='us-west-2';")
    out=tmp/"overture_counties.tsv"
    path=f"s3://overturemaps-us-west-2/release/{release}/theme=divisions/type=division_area/*"
    con.execute(f"""
      COPY(
        SELECT names.primary AS name, ST_AsGeoJSON(geometry) AS geojson
        FROM read_parquet('{path}',filename=true,hive_partitioning=1)
        WHERE country='TR' AND subtype='county' AND names.primary IS NOT NULL
      ) TO '{out.as_posix()}' (HEADER,DELIMITER '\\t')
    """)
    con.close()

    existing_keys={(norm(d),norm(p)) for d,p,_ in existing}
    added=[];raw=0
    with out.open('r',encoding='utf-8',newline='') as f:
        for r in csv.DictReader(f,delimiter='\\t'):
            raw+=1;name=(r.get('name') or '').strip()
            if not name:continue
            try:g=shape(json.loads(r['geojson']))
            except:continue
            if g.is_empty:continue
            pt=g.representative_point();prov=None
            for official,pg in provs:
                if pg.contains(pt) or pg.touches(pt):
                    prov=official;break
            if not prov:continue
            key=(norm(name),norm(prov))
            if key in existing_keys:continue
            existing_keys.add(key)
            rp=g.representative_point();w,s,e,n=g.bounds
            db.execute("INSERT INTO regions(name,name_norm,kind,province,province_norm,lat,lon,south,west,north,east) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                       (name,norm(name),'district',prov,norm(prov),rp.y,rp.x,s,w,n,e))
            added.append((name,prov,g))
    merged=existing+added
    print(json.dumps({
        'overture_release_for_districts':release,
        'overture_county_raw':raw,
        'overture_districts_added':len(added),
        'districts_after_fallback':len(merged)
    },ensure_ascii=False))
    return merged

def _phrase(text, phrase):
    n=" "+norm(text)+" "
    p=norm(phrase)
    return re.search(r"(^|\\s)"+re.escape(p)+r"(\\s|$)",n) is not None

def _any_phrase(text, phrases):
    return any(_phrase(text,p) for p in phrases)

def classifier(name,fields,tags=None):
    tags=tags or {};n=norm(name);t=norm(fields);text=f"{n} {t}"
    out={}
    def put(k,note,boost):out[k]=(note,boost)
    # V15: substring degil kelime/ifade siniri. Ornegin delivery artik liver sayilmaz.
    if _any_phrase(text,("ciger","arnavut ciger","liver")):put("ciger","Ciğer eşleşmesi",28)
    if _any_phrase(text,("kofte","kofteci","meatball","inegol kofte")):put("kofte","Köfte eşleşmesi",30)
    if _any_phrase(text,("kebap","kebab","ocakbasi","doner","donerci")):put("kebap","Kebap eşleşmesi",28)
    if _any_phrase(text,("sulu yemek","ev yemek","tabldot","home cooking")):put("sulu","Günlük/sulu yemek eşleşmesi",22)
    if _any_phrase(text,("esnaf lokanta","lokanta","sofra")):put("esnaf","Esnaf/lokanta eşleşmesi",20)
    if _any_phrase(text,("tavuk","pilic","chicken")):put("tavuk","Tavuk eşleşmesi",24)
    if _any_phrase(text,("balik","fish restaurant","seafood")):put("balik","Balık/deniz ürünü eşleşmesi",24)
    if _any_phrase(text,("kahvalti","breakfast","serpme")):put("kahvalti","Kahvaltı eşleşmesi",24)
    natural=norm(tags.get("natural",""));leisure=norm(tags.get("leisure",""));historic=norm(tags.get("historic",""));tourism=norm(tags.get("tourism",""))
    surface=norm(tags.get("surface",""));desc=norm(" ".join([tags.get("description",""),tags.get("note",""),tags.get("seabed",""),tags.get("shallow","")]))
    if natural=="beach" or leisure in ("beach","beach resort") or _phrase(text,"beach"):
        put("plaj","Gerçek plaj türü",25)
        sandy=("sand" in surface.split() or _any_phrase(n,("kum","kumsal")) or "sand" in desc.split())
        shallow=(_any_phrase(desc,("sig","shallow","az derin")) or norm(tags.get("shallow","")) in ("yes","true"))
        if sandy and shallow:put("kum","Sığ + kum doğrulandı",36)
        elif sandy:put("kum","Kumlu • sığlık açık veride doğrulanmadı",12)
    if natural=="bay" or _any_phrase(n,("koy","koyu")) or _phrase(text,"bay"):put("koy","Koy eşleşmesi",25)
    if natural in ("cave entrance","cave") or _any_phrase(n,("magara","magarasi")) or _any_phrase(text,("cave","cave entrance")):put("magara","Gerçek mağara eşleşmesi",30)
    if historic in ("archaeological site","ruins") or _any_phrase(text,("archaeological","archeological","ancient city","ruins")):put("antik","Antik/arkeolojik eşleşme",32)
    if historic in ("castle","fort","city gate","citywalls") or _any_phrase(text,("castle","fortress","fort","city wall","city gate","hisar","kale")):put("kale","Kale/hisar/sur eşleşmesi",30)
    if tourism=="museum" or _phrase(text,"museum"):put("muze","Müze eşleşmesi",25)
    if historic or _any_phrase(text,("historic","monument","memorial","archaeological","ruins","castle")):put("tarihi","Tarihi yer eşleşmesi",18)
    if _any_phrase(text,("guest house","guest_house","pension","pansiyon","hostel","bed and breakfast")):put("pansiyon","Pansiyon/konukevi",22)
    if _any_phrase(text,("aparthotel","apart hotel","serviced apartment","apartment hotel")):put("apart","Apart eşleşmesi",22)
    if _any_phrase(text,("hotel","motel","resort")):put("otel","Otel eşleşmesi",18)
    if _any_phrase(text,("campground","camp site","camp_site","caravan site","caravan_site")):put("kamp","Kamp eşleşmesi",22)
    return out

class Locator:
    def __init__(self,provs,dists):
        self.prov_names=[x[0] for x in provs];self.prov_geoms=[x[1] for x in provs]
        self.dist_names=[(x[0],x[1]) for x in dists];self.dist_geoms=[x[2] for x in dists]
        self.ptree=STRtree(self.prov_geoms);self.dtree=STRtree(self.dist_geoms)
    def _hit(self,tree,geoms,names,pt):
        arr=tree.query(pt)
        for a in arr:
            idx=int(a) if hasattr(a,"__int__") and not hasattr(a,"geom_type") else geoms.index(a)
            g=geoms[idx]
            if g.contains(pt) or g.touches(pt):return names[idx]
        return None
    def locate(self,lat,lon):
        pt=Point(lon,lat)
        d=self._hit(self.dtree,self.dist_geoms,self.dist_names,pt)
        if d:return d[1],d[0]
        p=self._hit(self.ptree,self.prov_geoms,self.prov_names,pt)
        return (p or "","")

def insert_poi(db,name,key,prov,dist,address,detail,source,url,note,route,lat,lon,score,count=1,cur=0):
    nn=norm(name)
    if len(nn)<3 or nn in BAD_NAMES:return
    # Close duplicate in same category/location => merge sources and boost.
    hit=db.execute("""SELECT id,source_count,rank_score,source FROM poi WHERE category_key=? AND name_norm=? AND province_norm=? AND ABS(lat-?)<0.002 AND ABS(lon-?)<0.002 LIMIT 1""",
                   (key,nn,norm(prov),lat,lon)).fetchone()
    if hit:
        nid,sc,rs,src=hit
        newsc=sc+1
        nsrc=src if source in src else src+" + "+source
        db.execute("UPDATE poi SET source_count=?,rank_score=?,source=? WHERE id=?",(newsc,max(rs,score)+18,nsrc,nid))
        return
    db.execute("""INSERT INTO poi(name,name_norm,category_key,province,province_norm,district,district_norm,address,detail,source,source_url,match_note,route_query,lat,lon,rank_score,source_count,curated)
                  VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
               (name,nn,key,prov,norm(prov),dist,norm(dist),address,detail,source,url,note,route,lat,lon,score,count,cur))

def osm_pois(pbf,tmp,db,locator):
    filt=tmp/"poi.osm.pbf";geo=tmp/"poi.geojsonseq"
    filters=["nwr/amenity=restaurant","nwr/amenity=fast_food","nwr/amenity=cafe","nwr/natural=beach","nwr/natural=bay","nwr/natural=cave_entrance","nwr/natural=cave","nwr/leisure=beach","nwr/leisure=beach_resort","nwr/historic","nwr/tourism=museum","nwr/tourism=hotel","nwr/tourism=motel","nwr/tourism=resort","nwr/tourism=guest_house","nwr/tourism=hostel","nwr/tourism=apartment","nwr/tourism=camp_site","nwr/tourism=caravan_site"]
    subprocess.run(["osmium","tags-filter",str(pbf),*filters,"-o",str(filt),"--overwrite"],check=True)
    subprocess.run(["osmium","export",str(filt),"-f","geojsonseq","-o",str(geo),"--overwrite"],check=True)
    n=0
    for line in geo.open("r",encoding="utf-8",errors="replace"):
        line=line.strip().lstrip("\x1e")
        if not line:continue
        try:f=json.loads(line);p=f.get("properties") or {};name=(p.get("name") or "").strip();g=shape(f["geometry"]);pt=g.representative_point()
        except:continue
        if not name or norm(name) in BAD_NAMES:continue
        lat,lon=pt.y,pt.x
        prov,dist=locator.locate(lat,lon)
        if not prov:continue
        tags={str(k):str(v) for k,v in p.items() if v is not None}
        fields=" ".join([tags.get("amenity",""),tags.get("cuisine",""),tags.get("tourism",""),tags.get("historic",""),tags.get("natural",""),tags.get("leisure",""),tags.get("description","")])
        cats=classifier(name,fields,tags)
        addr=" ".join(x for x in [tags.get("addr:street",""),tags.get("addr:housenumber","")] if x).strip()
        wiki=tags.get("wikipedia","");boost=15 if wiki else 0
        for key,(note,b) in cats.items():
            insert_poi(db,name,key,prov,dist,addr,tags.get("description",""),"OpenStreetMap","",note,f"{name} {dist} {prov}",lat,lon,75+b+boost,1,0);n+=1
    return n

def overture_places(tmp,db,locator):
    con=duckdb.connect()
    con.execute("INSTALL spatial; LOAD spatial; INSTALL httpfs; LOAD httpfs; SET s3_region='us-west-2';")
    latest=con.execute("SELECT latest FROM 'https://stac.overturemaps.org/catalog.json'").fetchone()[0]
    out=tmp/"overture.tsv"
    path=f"s3://overturemaps-us-west-2/release/{latest}/theme=places/type=place/*"
    con.execute(f"""
      COPY(
       SELECT id,names.primary AS name,COALESCE(basic_category,'') AS basic_category,
              COALESCE(taxonomy.primary,'') AS taxonomy_primary,
              COALESCE(array_to_string(taxonomy.hierarchy,'|'),'') AS hierarchy,
              COALESCE(categories.primary,'') AS old_category,
              COALESCE(confidence,0.0) AS confidence,
              COALESCE(addresses[1].freeform,'') AS address,
              ST_Y(geometry) AS lat,ST_X(geometry) AS lon,
              COALESCE(list_count(sources),1) AS source_count
       FROM read_parquet('{path}',filename=true,hive_partitioning=1)
       WHERE names.primary IS NOT NULL AND length(trim(names.primary))>=3
         AND COALESCE(confidence,0.0)>=0.68
         AND operating_status IS DISTINCT FROM 'permanently_closed'
         AND bbox.xmin BETWEEN {TR_BBOX[0]} AND {TR_BBOX[2]}
         AND bbox.ymin BETWEEN {TR_BBOX[1]} AND {TR_BBOX[3]}
      ) TO '{out.as_posix()}' (HEADER,DELIMITER '\t')
    """)
    con.close()
    n=0
    with out.open("r",encoding="utf-8",newline="") as f:
        for r in csv.DictReader(f,delimiter="\t"):
            name=(r.get("name") or "").strip()
            if norm(name) in BAD_NAMES:continue
            lat=float(r["lat"]);lon=float(r["lon"]);prov,dist=locator.locate(lat,lon)
            if not prov:continue
            fields=" ".join([r.get("basic_category",""),r.get("taxonomy_primary",""),r.get("hierarchy",""),r.get("old_category","")])
            cats=classifier(name,fields)
            conf=float(r.get("confidence") or 0);sc=int(float(r.get("source_count") or 1))
            for key,(note,b) in cats.items():
                insert_poi(db,name,key,prov,dist,r.get("address",""),"","Overture Maps","",note,f"{name} {dist} {prov}",lat,lon,conf*100+b+min(sc,4)*5,sc,0);n+=1
    return latest,n

def clean_text(s):
    return re.sub(r"\s+"," ",html.unescape(s or "")).strip()
def short_summary(text,maxchars=620):
    text=clean_text(text)
    text=re.sub(r"(T\.C\. Kültür ve Turizm Bakanlığı|Görüntülenme Sayısı).*","",text,flags=re.I)
    ss=re.split(r"(?<=[.!?])\s+",text)
    out=" ".join(ss[:4]).strip()
    return out[:maxchars].rstrip()
def candidate_keywords(text):
    n=norm(text);return any(norm(k) in n for k in LEGEND_WORDS)

def fetch(session,url,timeout=18):
    for attempt in range(3):
        try:
            r=session.get(url,timeout=timeout,headers={"User-Agent":"DenizGizemV14DataBuilder/1.2"},allow_redirects=True)
            if r.status_code==200 and "text/html" in r.headers.get("content-type",""):
                return r.text,r.url
            if r.status_code in (429,500,502,503,504): time.sleep(1.0+attempt*1.5)
        except Exception:
            time.sleep(0.8+attempt)
    return None,None

def crawl_province(province,district_names):
    ses=requests.Session();pslug=slug(province)
    seeds=[
      f"https://www.kulturportali.gov.tr/turkiye/{pslug}",
      f"https://www.kulturportali.gov.tr/turkiye/{pslug}/kulturatlasi",
      f"https://www.kulturportali.gov.tr/arama/{quote(province)}",
      f"https://www.kulturportali.gov.tr/arama/{quote(province+' efsane')}",
      f"https://www.kulturportali.gov.tr/arama/{quote(province+' rivayet')}",
      f"https://www.kulturportali.gov.tr/arama/{quote(province+' menkıbe')}",
      f"https://{pslug}.ktb.gov.tr/"
    ]
    urls=set();pages=[]
    for u in seeds:
        body,final=fetch(ses,u)
        if not body:continue
        soup=BeautifulSoup(body,"html.parser")
        for a in soup.find_all("a",href=True):
            href=urljoin(final,a["href"]);txt=clean_text(a.get_text(" ",strip=True))
            host=urlparse(href).netloc.lower()
            if not (host.endswith("kulturportali.gov.tr") or host.endswith("ktb.gov.tr")):continue
            context=txt+" "+href
            if candidate_keywords(context) or ("/kulturatlasi/" in href and pslug in href) or ("/gezilecekyer/" in href and candidate_keywords(soup.get_text(" ",strip=True)[:8000])):
                urls.add(href.split("#")[0])
    # Efsane/rivayet/menkıbe içeren linkleri önce işle.
    def url_priority(u):
        nu=norm(u)
        strong=any(k in nu for k in ("efsane","rivayet","menkibe","soylence","mitoloji"))
        return (0 if strong else 1, len(u))
    ordered_urls=sorted(urls,key=url_priority)
    for u in ordered_urls[:70]:
        body,final=fetch(ses,u)
        if not body:continue
        soup=BeautifulSoup(body,"html.parser")
        title=clean_text((soup.find("h1") or soup.find("h2") or soup.find("h3") or soup.title).get_text(" ",strip=True) if (soup.find("h1") or soup.find("h2") or soup.find("h3") or soup.title) else "")
        text=clean_text(soup.get_text(" ",strip=True))
        if not candidate_keywords(title+" "+text):continue
        # split multi-legend pages by headings when possible
        sections=[]
        heads=soup.find_all(["h2","h3","h4","strong"])
        for h in heads:
            ht=clean_text(h.get_text(" ",strip=True))
            if len(ht)<4 or len(ht)>120:continue
            buf=[];node=h.find_next_sibling()
            while node and node.name not in ("h2","h3","h4"):
                buf.append(clean_text(node.get_text(" ",strip=True)));node=node.find_next_sibling()
                if sum(map(len,buf))>2200:break
            bt=clean_text(" ".join(buf))
            if len(bt)>90 and candidate_keywords(ht+" "+bt):sections.append((ht,bt))
        if not sections:
            sections=[(title,text)]
        for st,bt in sections[:12]:
            summ=short_summary(bt)
            if len(summ)<90:continue
            dist=""
            nb=norm(st+" "+summ)
            for d in sorted(district_names,key=len,reverse=True):
                if norm(d) and norm(d) in nb:dist=d;break
            place=st if "/gezilecekyer/" in final or "/kulturenvanteri/" in final else ""
            pages.append((st,province,dist,summ,
                          "Türkiye Kültür Portalı" if "kulturportali.gov.tr" in final else f"{province} İl Kültür ve Turizm Müdürlüğü",
                          final, (place+" "+(dist or province)).strip()))
    # dedupe
    seen=set();out=[]
    for x in pages:
        k=(norm(x[0]),norm(x[2]))
        if k in seen:continue
        seen.add(k);out.append(x)
    return out


def wiki_api(session,params):
    for attempt in range(3):
        try:
            r=session.get(
                "https://tr.wikipedia.org/w/api.php",
                params=params,
                timeout=24,
                headers={"User-Agent":"DenizGizemV14DataBuilder/1.2 (offline travel data build)"}
            )
            if r.status_code==200:return r.json()
            if r.status_code in (429,500,502,503,504):time.sleep(1.0+attempt*1.5)
        except Exception:
            time.sleep(0.8+attempt)
    return {}

def wikipedia_legends_for_province(province,district_names):
    session=requests.Session()
    queries=[
        f'"{province}" efsane',
        f'"{province}" efsanesi',
        f'"{province}" efsaneleri',
        f'"{province}" rivayet',
        f'"{province}" menkıbe',
        f'"{province}" söylence',
        f'"{province}" halk inanışları',
        f'"{province}" mitoloji',
    ]
    title_set=[];seen_titles=set()
    for q in queries:
        search=wiki_api(session,{"action":"query","format":"json","list":"search","srsearch":q,"srlimit":"15","srnamespace":"0","utf8":"1"})
        for h in (search.get("query") or {}).get("search") or []:
            t=h.get("title","")
            if t and t not in seen_titles:
                seen_titles.add(t);title_set.append(t)
    if len(title_set)<8:
        for d in district_names[:8]:
            for suffix in ("efsane","rivayet"):
                search=wiki_api(session,{"action":"query","format":"json","list":"search","srsearch":f'"{d}" {suffix}',"srlimit":"8","srnamespace":"0","utf8":"1"})
                for h in (search.get("query") or {}).get("search") or []:
                    t=h.get("title","")
                    if t and t not in seen_titles:
                        seen_titles.add(t);title_set.append(t)
    if not title_set:return []
    pages={}
    for i in range(0,min(len(title_set),80),20):
        data=wiki_api(session,{"action":"query","format":"json","prop":"extracts|info|categories","exintro":"1","explaintext":"1","inprop":"url","cllimit":"max","redirects":"1","titles":"|".join(title_set[i:i+20]),"utf8":"1"})
        pages.update((data.get("query") or {}).get("pages") or {})
    out=[];prov_n=norm(province);dist_sorted=sorted([d for d in district_names if d],key=len,reverse=True)
    for page in pages.values():
        title=clean_text(page.get("title",""));extract=clean_text(page.get("extract",""));cats=" ".join(c.get("title","") for c in (page.get("categories") or []))
        full=title+" "+extract+" "+cats;nf=norm(full)
        if len(extract)<80 or not candidate_keywords(full):continue
        district="";anchored=(prov_n in nf)
        for d in dist_sorted:
            if norm(d) and norm(d) in nf:district=d;anchored=True;break
        if not anchored:continue
        nt=norm(title)
        if any(x in nt for x in ("liste","kategori")) and len(extract)<220:continue
        summary=short_summary(extract,620)
        if len(summary)<80:continue
        url=page.get("fullurl","") or ("https://tr.wikipedia.org/wiki/"+quote(title.replace(" ","_")))
        out.append((title,province,district,summary,"Türkçe Wikipedia",url,(title+" "+(district or province)).strip(),835.0))
    seen=set();ded=[]
    for x in out:
        k=(norm(x[0]),norm(x[2]))
        if k in seen:continue
        seen.add(k);ded.append(x)
    return ded

def add_wikipedia_legends(db,districts):
    byprov={p:[] for p in PROVINCES}
    for d,p,_ in districts:
        byprov.setdefault(p,[]).append(d)

    rows=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
        futs={ex.submit(wikipedia_legends_for_province,p,byprov.get(p,[])):p for p in PROVINCES}
        for fut in concurrent.futures.as_completed(futs):
            p=futs[fut]
            try:
                rows.extend(fut.result())
            except Exception as e:
                print("wikipedia warning",p,e)

    added=0
    for title,prov,dist,summ,src,url,place,score in rows:
        before=db.total_changes
        db.execute("""INSERT OR IGNORE INTO legends(
            title,title_norm,province,province_norm,district,district_norm,
            summary,source_title,source_url,place_query,rank_score,curated
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,0)""",
        (title,norm(title),prov,norm(prov),dist,norm(dist),summ,src,url,place,score))
        if db.total_changes>before:
            added+=1
    return added


def culture_portal_keyword_pages(province,district_names):
    session=requests.Session();pslug=slug(province)
    body,final=fetch(session,f"https://www.kulturportali.gov.tr/turkiye/{pslug}/kulturatlasi")
    if not body:return []
    soup=BeautifulSoup(body,"html.parser");candidates=[]
    for a in soup.find_all("a",href=True):
        href=urljoin(final,a["href"]).split("#")[0];txt=clean_text(a.get_text(" ",strip=True))
        if f"/turkiye/{pslug}/kulturatlasi/" not in href:continue
        nt=norm(txt+" "+href)
        if any(k in nt for k in ("efsane","rivayet","menkibe","soylence","mitoloji","inanis")):candidates.append(href)
    out=[];seen=set()
    for u in candidates[:90]:
        if u in seen:continue
        seen.add(u);body,final=fetch(session,u)
        if not body:continue
        soup=BeautifulSoup(body,"html.parser");title_el=soup.find("h1") or soup.find("h2") or soup.title
        title=clean_text(title_el.get_text(" ",strip=True) if title_el else "");page_text=clean_text(soup.get_text(" ",strip=True))
        if not candidate_keywords(title+" "+page_text):continue
        dist="";nt=norm(title+" "+page_text[:3000])
        for d in sorted(district_names,key=len,reverse=True):
            if norm(d) and norm(d) in nt:dist=d;break
        paras=[clean_text(p.get_text(" ",strip=True)) for p in soup.find_all("p")];paras=[p for p in paras if len(p)>60]
        summary=short_summary(" ".join(paras[:5]) if paras else page_text,620)
        if len(summary)<80:continue
        out.append((title,province,dist,summary,"Türkiye Kültür Portalı",final,(title+" "+(dist or province)).strip(),960.0))
    return out

def add_culture_portal_keyword_legends(db,districts):
    byprov={p:[] for p in PROVINCES}
    for d,p,_ in districts:byprov.setdefault(p,[]).append(d)
    rows=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
        futs={ex.submit(culture_portal_keyword_pages,p,byprov.get(p,[])):p for p in PROVINCES}
        for fut in concurrent.futures.as_completed(futs):
            try:rows.extend(fut.result())
            except Exception as e:print("culture-atlas warning",futs[fut],e)
    added=0
    for title,prov,dist,summ,src,url,place,score in rows:
        before=db.total_changes
        db.execute("""INSERT OR IGNORE INTO legends(title,title_norm,province,province_norm,district,district_norm,summary,source_title,source_url,place_query,rank_score,curated) VALUES(?,?,?,?,?,?,?,?,?,?,?,0)""",(title,norm(title),prov,norm(prov),dist,norm(dist),summ,src,url,place,score))
        if db.total_changes>before:added+=1
    return added


def legend_signal(text):
    n=norm(text)
    strong=(
        "efsane","rivayet","menkibe","soylence","mitoloji","mitolojik",
        "halk inanisi","inanisa gore","keramet",
        "halk arasinda","soylendigine gore","anlatilir","anlatilmaktadir",
        "yatir","evliya","ermis"
    )
    return any(x in n for x in strong)

def wiki_geosearch(session,lat,lon,radius=10000,limit=50):
    data=wiki_api(session,{
        "action":"query","format":"json","list":"geosearch",
        "gscoord":f"{lat}|{lon}","gsradius":str(radius),
        "gslimit":str(limit),"gsnamespace":"0","utf8":"1"
    })
    return (data.get("query") or {}).get("geosearch") or []

def fetch_wiki_pages(session,titles):
    pages={}
    for i in range(0,len(titles),20):
        data=wiki_api(session,{
            "action":"query","format":"json","prop":"extracts|info|categories",
            "exintro":"1","explaintext":"1","inprop":"url","cllimit":"max",
            "redirects":"1","titles":"|".join(titles[i:i+20]),"utf8":"1"
        })
        pages.update((data.get("query") or {}).get("pages") or {})
    return pages

def geosearch_legend_rescue_for_province(db,province,district_rows):
    """
    Yalnız normal kültür + Wikipedia aramalarında efsanesi eksik kalan iller için.
    İl merkezi ve seçilmiş ilçe merkezleri çevresindeki Türkçe Wikipedia
    maddelerini coğrafi olarak tarar. Makale metninde gerçekten efsane/rivayet/
    menkıbe/keramet vb. anlatı sinyali yoksa kayıt kabul edilmez.
    """
    session=requests.Session()

    pnorm=norm(province)
    center=db.execute(
        "SELECT lat,lon FROM regions WHERE kind='province' AND province_norm=? LIMIT 1",
        (pnorm,)
    ).fetchone()
    points=[]
    if center:
        points.append((province,float(center[0]),float(center[1])))

    rows=list(district_rows)
    sampled=[]
    if rows:
        step=max(1,len(rows)//13)
        sampled=rows[::step][:14]
    for d,lat,lon in sampled:
        points.append((d,float(lat),float(lon)))

    titles=[]
    seen=set()
    for label,lat,lon in points:
        for hit in wiki_geosearch(session,lat,lon,10000,50):
            t=hit.get("title","")
            if t and t not in seen:
                seen.add(t);titles.append(t)

    if not titles:
        return []

    pages=fetch_wiki_pages(session,titles[:260])
    out=[]
    district_names=[r[0] for r in rows]
    dsorted=sorted([d for d in district_names if d],key=len,reverse=True)

    for page in pages.values():
        title=clean_text(page.get("title",""))
        extract=clean_text(page.get("extract",""))
        cats=" ".join(c.get("title","") for c in (page.get("categories") or []))
        full=title+" "+extract+" "+cats
        if len(extract)<90 or not legend_signal(full):
            continue

        nt=norm(title)
        if any(x in nt for x in ("futbolcu","siyasetci","oyuncu","album","film","dizi")):
            continue

        district=""
        nf=norm(full)
        for d in dsorted:
            if norm(d) and norm(d) in nf:
                district=d
                break

        summary=short_summary(extract,620)
        if len(summary)<90:
            continue

        url=page.get("fullurl","") or ("https://tr.wikipedia.org/wiki/"+quote(title.replace(" ","_")))
        place=(title+" "+(district or province)).strip()
        out.append((
            title,province,district,summary,
            "Türkçe Wikipedia • coğrafi tarama",url,place,790.0
        ))

    ded=[];keys=set()
    for x in out:
        k=(norm(x[0]),norm(x[2]))
        if k in keys:
            continue
        keys.add(k);ded.append(x)
    return ded

def add_geosearch_legend_rescue(db,districts):
    byprov={p:[] for p in PROVINCES}
    for d,p,g in districts:
        try:
            pt=g.representative_point()
            byprov.setdefault(p,[]).append((d,pt.y,pt.x))
        except Exception:
            pass

    counts={
        r[0]:r[1]
        for r in db.execute(
            "SELECT province_norm,count(*) FROM legends GROUP BY province_norm"
        ).fetchall()
    }
    targets=[p for p in PROVINCES if counts.get(norm(p),0)<2]

    rows=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
        futs={
            ex.submit(geosearch_legend_rescue_for_province,db,p,byprov.get(p,[])):p
            for p in targets
        }
        for fut in concurrent.futures.as_completed(futs):
            p=futs[fut]
            try:
                rows.extend(fut.result())
            except Exception as e:
                print("wiki-geosearch warning",p,e)

    added=0
    for title,prov,dist,summ,src,url,place,score in rows:
        before=db.total_changes
        db.execute("""INSERT OR IGNORE INTO legends(
            title,title_norm,province,province_norm,district,district_norm,
            summary,source_title,source_url,place_query,rank_score,curated
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,0)""",
        (title,norm(title),prov,norm(prov),dist,norm(dist),summ,src,url,place,score))
        if db.total_changes>before:
            added+=1
    return added


def add_legends(db,districts):
    byprov={p:[] for p in PROVINCES}
    for d,p,_ in districts:byprov.setdefault(p,[]).append(d)
    allrows=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
        futs={ex.submit(crawl_province,p,byprov.get(p,[])):p for p in PROVINCES}
        for fut in concurrent.futures.as_completed(futs):
            try:allrows.extend(fut.result())
            except Exception as e:print("culture warning",futs[fut],e)
    for title,prov,dist,summ,src,url,place in allrows:
        try:
            db.execute("""INSERT OR IGNORE INTO legends(title,title_norm,province,province_norm,district,district_norm,summary,source_title,source_url,place_query,rank_score,curated)
                          VALUES(?,?,?,?,?,?,?,?,?,?,?,0)""",
                       (title,norm(title),prov,norm(prov),dist,norm(dist),summ,src,url,place,900.0))
        except:pass
    return len(allrows)

def seed_critical(db):
    # Kritik fiziksel regresyon kayıtları full build'e de eklenir.
    # Bunlar yalnız test hilesi değildir; kaynaklı gerçek yerlerdir.
    critical_poi=[
      ("Gözlükule Höyüğü","antik","Mersin","Tarsus","Tarsus merkezindeki arkeolojik höyük; yerleşim çok erken dönemlere uzanır.","T.C. Kültür ve Turizm Bakanlığı","Gözlükule Höyüğü Tarsus",1320,"Arkeolojik alan"),
      ("Donuktaş Roma Tapınağı","antik","Mersin","Tarsus","Roma dönemine ait büyük anıtsal yapı kalıntısı.","T.C. Kültür ve Turizm Bakanlığı","Donuktaş Tarsus",1300,"Roma dönemi"),
      ("Tarsus Roma Yolu","antik","Mersin","Tarsus","Antik Tarsus kent dokusundan günümüze ulaşan Roma yolu kalıntısı.","T.C. Kültür ve Turizm Bakanlığı","Tarsus Roma Yolu",1280,"Roma dönemi"),
      ("Köfteci","kofte","Mersin","Tarsus","Köfte odaklı yerel işletme.","Güncel işletme kaydı","Köfteci Tarsus",1240,"Köfte eşleşmesi")
    ]
    for name,key,prov,dist,detail,src,route,score,note in critical_poi:
        insert_poi(db,name,key,prov,dist,"",detail,src,"",note,route,36.918,34.893,score,2,1)

    legends=[
      ("Şahmaran Efsanesi","Mersin","Tarsus","Tarsus anlatısında Şahmaran, yer altında yaşayan yılanların bilge kraliçesidir. Cemşab'ın Şahmaran'la karşılaşması, sırrın açığa çıkması ve Şahmaran'ın ölümü etrafında gelişen anlatı Tarsus kültürüyle güçlü biçimde özdeşleşmiştir.","Türkiye Kültür Portalı","https://www.kulturportali.gov.tr/turkiye/mersin/kulturatlasi/sahmeran-tarsus","Şahmeran Hamamı Tarsus",1300),
      ("Eshab-ı Kehf / Yedi Uyurlar","Mersin","Tarsus","Tarsus'taki Eshab-ı Kehf Mağarası, Yedi Uyurlar inanışının Anadolu'daki önemli merkezlerinden biridir. Anlatıda inançlarını korumak için mağaraya sığınan gençlerin uzun süre uyuyup daha sonra uyanmaları anlatılır.","Türkiye Kültür Portalı","https://www.kulturportali.gov.tr/turkiye/mersin/gezilecekyer/eshab-i-kehf","Eshab-ı Kehf Mağarası Tarsus",1280),
      ("Cennet Bursa Efsanesi","Bursa","","Efsanede Hz. Süleyman Uludağ ve çevresinin güzelliğini görür; perilerle birlikte burada bir şehir kurulduğu anlatılır. 'Cennet burası' sözünün zamanla Bursa adına dönüştüğü yönündeki halk anlatısı aktarılır.","Türkiye Kültür Portalı","https://www.kulturportali.gov.tr/turkiye/bursa/kulturatlasi/cennet-bursa-efsanesi","Uludağ Bursa",1280),
      ("Ulu Cami'nin Yeri ve Emir Sultan Menkıbesi","Bursa","Osmangazi","Rivayete göre Niğbolu zaferinden sonra Yıldırım Bayezid çok sayıda cami yaptırmayı düşünür. Emir Sultan yirmi ayrı cami yerine yirmi kubbeli bir cami önerir; caminin yerinin de manevi bir işaretle belirlendiği anlatılır.","Bursa İl Kültür ve Turizm Müdürlüğü","https://bursa.ktb.gov.tr/TR-70236/camiler.html","Bursa Ulu Cami",1260),
      ("Munzur Efsanesi","Tunceli","Ovacık","Munzur Gözeleri çevresinde anlatılan rivayette Munzur adlı çobanın kerametleri ve kutsal kabul edilen suyun ortaya çıkışı anlatılır.","Türkiye Kültür Portalı","https://www.kulturportali.gov.tr/turkiye/tunceli/gezilecekyer/munzur-gozeleri","Munzur Gözeleri Ovacık Tunceli",1220),
      ("Osman Gazi'nin Rüyası","Bilecik","","Anlatıda Osman Gazi, Şeyh Edebali'nin evinde gördüğü rüyada kendi göğsünden büyüyerek dünyayı saran bir ağaç görür. Bu rüya Osmanlı devletinin doğuşuna ilişkin en bilinen menkıbelerden biri olarak aktarılır.","Bilecik İl Kültür ve Turizm Müdürlüğü","https://bilecik.ktb.gov.tr/TR-69073/efsaneler.html","Şeyh Edebali Türbesi Bilecik",1220),
      ("Kızkalesi Efsanesi","Mersin","Erdemli","Efsanede kızının bir yılan tarafından sokulacağını öğrenen kralın onu denizdeki kaleye yerleştirdiği; ancak bir üzüm sepetine saklanan yılan nedeniyle kaderden kaçamadığı anlatılır.","Türkiye Kültür Portalı","https://www.kulturportali.gov.tr/turkiye/mersin/gezilecekyer/kizkalesi-deniz-kalesi","Kızkalesi Erdemli Mersin",1210)
    ]
    for x in legends:
        title,prov,dist,summ,src,url,place,score=x
        db.execute("""INSERT OR REPLACE INTO legends(title,title_norm,province,province_norm,district,district_norm,summary,source_title,source_url,place_query,rank_score,curated)
                      VALUES(?,?,?,?,?,?,?,?,?,?,?,1)""",(title,norm(title),prov,norm(prov),dist,norm(dist),summ,src,url,place,score))

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--osm-pbf",required=True);ap.add_argument("--output",required=True)
    args=ap.parse_args();pbf=Path(args.osm_pbf);out=Path(args.output)
    if not pbf.exists() or pbf.stat().st_size<300_000_000:raise SystemExit("Türkiye OSM PBF eksik/küçük")
    with tempfile.TemporaryDirectory(prefix="v14_") as td:
        tmp=Path(td)
        if out.exists():out.unlink()
        db=sqlite3.connect(out);schema(db)
        db.execute("INSERT INTO meta VALUES(?,?)",("dataset_label","V14 Offline Türkiye • Overture latest + OpenStreetMap + resmi kültür kaynakları"))
        for a,t in ALIASES.items():db.execute("INSERT OR REPLACE INTO aliases VALUES(?,?)",(norm(a),norm(t)))
        geo=osm_boundaries(pbf,tmp)
        provs,dists=load_regions(db,geo)
        dists=overture_district_fallback(db,tmp,provs,dists)
        if len(dists)<900:
            raise RuntimeError(f"İlçe sınır verisi yetersiz: {len(dists)}. APK üretimi durduruldu.")
        locator=Locator(provs,dists)
        osm_count=osm_pois(pbf,tmp,db,locator)
        release,ov_count=overture_places(tmp,db,locator)
        seed_critical(db)
        culture_count=add_legends(db,dists)
        culture_atlas_count=add_culture_portal_keyword_legends(db,dists)
        wikipedia_count=add_wikipedia_legends(db,dists)
        geosearch_count=add_geosearch_legend_rescue(db,dists)
        db.execute("INSERT OR REPLACE INTO meta VALUES(?,?)",("overture_release",str(release)))
        db.execute("INSERT OR REPLACE INTO meta VALUES(?,?)",("build_stats",json.dumps({
            "osm":osm_count,
            "overture":ov_count,
            "culture_official":culture_count,
            "culture_atlas_keyword":culture_atlas_count,
            "culture_wikipedia":wikipedia_count,
            "culture_wikipedia_geosearch":geosearch_count
        })))
        db.commit();db.execute("ANALYZE");db.execute("VACUUM");db.close()
        print(json.dumps({
            "overture_release":release,
            "osm_attempts":osm_count,
            "overture_attempts":ov_count,
            "culture_official_candidates":culture_count,
            "culture_atlas_keyword_added":culture_atlas_count,
            "culture_wikipedia_added":wikipedia_count,
            "culture_wikipedia_geosearch_added":geosearch_count
        },ensure_ascii=False))
if __name__=="__main__":main()
