package com.altay.denizgizem
import org.junit.Assert.*
import org.junit.Test
class CoreTest {
 @Test fun normalization(){assertEquals("sanliurfa",TextNorm.norm("ŞANLIURFA"));assertEquals("igdir",TextNorm.norm("Iğdır"))}
 @Test fun allButtons(){assertEquals(21,Categories.all.map{it.key}.toSet().size);assertNotNull(Categories.byKey("gizem"));assertNotNull(Categories.byKey("kum"))}
}
