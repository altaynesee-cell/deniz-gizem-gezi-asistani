package com.altay.denizgizem;
import java.text.Normalizer;
import java.util.*;

public final class CuratedData {
    public static final class Entry {
        public final String region,group,profileId,name,address,yearLabel,why,tag;
        public final int foundedYear;
        Entry(String r,String g,String p,String n,String a,int y,String yl,String w,String t){
            region=r;group=g;profileId=p;name=n;address=a;foundedYear=y;yearLabel=yl;why=w;tag=t;
        }
    }
    private static final List<Entry> ALL=new ArrayList<>();
    static{
        add("bodrum","food","ciger","Milas Sofrası Ciğerci Durmuş Usta","Bodrum, Muğla",2000,"2000'den beri","Yerel ciğer ve esnaf lokantası çizgisinde köklü seçenek.","KÖKLÜ • YEREL");
        add("bodrum","food","sulu","Milas Sofrası Ciğerci Durmuş Usta","Bodrum, Muğla",2000,"2000'den beri","Sulu yemek ve ciğer için yerel/köklü seçim.","KÖKLÜ • YEREL");
        add("bursa","food","kebap","Kebapçı İskender","Bursa",1867,"1867'den beri","İskender kebap geleneğinin tarihî aile işletmesi.","ÇOK KÖKLÜ");
        add("istanbul","food","kofte","Tarihi Sultanahmet Köftecisi","Sultanahmet, İstanbul",1920,"1920'den beri","Sultanahmet köftesiyle uzun süredir tanınan tarihî işletme.","KÖKLÜ • MEŞHUR");

        add("bodrum","sea","plaj","Ortakent Yahşi Plajı","Ortakent, Bodrum, Muğla",0,"","Bodrum yarımadasında bilinen plajlardan.","BİLİNEN PLAJ");
        add("bodrum","sea","kum","Akyarlar Sahili","Akyarlar, Bodrum, Muğla",0,"","Kumlu kıyı bölümleriyle bilinen plaj seçeneği.","KUMLU KIYI");
        add("bodrum","sea","koy","Bitez Koyu","Bitez, Bodrum, Muğla",0,"","Korunaklı koy yapısıyla bilinen kıyı.","KOY");

        add("bodrum","discover","magara","Peynir Çiçeği Mağarası","Bodrum Yarımadası, Muğla",0,"","Gerçek mağara ve tarihöncesi izlerle ilişkilendirilen doğal alan.","MAĞARA");
        add("bodrum","discover","antik","Myndos Antik Kenti","Gümüşlük, Bodrum, Muğla",0,"","Antik Myndos yerleşimi ve arkeolojik kalıntıları.","ANTİK KENT");
        add("bodrum","discover","kale","Bodrum Kalesi","Bodrum Merkez, Muğla",0,"","Saint Jean Şövalyeleri döneminden tarihî kale.","KALE");
        add("bodrum","discover","muze","Bodrum Sualtı Arkeoloji Müzesi","Bodrum Kalesi, Muğla",0,"","Sualtı arkeolojisi koleksiyonlarıyla bilinen müze.","MÜZE");
        add("bodrum","discover","tarihi","Halikarnassos Mausoleion","Bodrum, Muğla",0,"","Antik Dünyanın Yedi Harikası arasında anılan anıt mezar.","TARİH");
        add("bodrum","discover","gizem","Salmakis (Bardakçı) Koyu","Bardakçı, Bodrum, Muğla",0,"","Salmakis–Hermaphroditos efsanesiyle ilişkilendirilen yer.","EFSANE");
        add("bodrum","discover","gizem","Halikarnassos Mausoleion","Bodrum, Muğla",0,"","Antik ölüm anıtı ve Yedi Harika bağlantısıyla gizem/tarih durağı.","GİZEM • TARİH");

        add("antalya","discover","magara","Karain Mağarası","Yağca, Antalya",0,"","Türkiye'nin önemli tarihöncesi mağara yerleşimlerinden.","MAĞARA");
        add("alanya","discover","magara","Damlataş Mağarası","Alanya, Antalya",0,"","Alanya merkezde gerçek turistik mağara.","MAĞARA");
        add("mersin","discover","magara","Cennet-Cehennem Obrukları","Narlıkuyu, Silifke, Mersin",0,"","Karst oluşumları ve mitolojik anlatılarla bilinen doğal alan.","DOĞAL OLUŞUM");
    }
    private CuratedData(){}
    private static void add(String r,String g,String p,String n,String a,int y,String yl,String w,String t){ALL.add(new Entry(r,g,p,n,a,y,yl,w,t));}
    public static List<Entry> find(String region,String group,String profileId){
        String r=norm(region);List<Entry>out=new ArrayList<>();
        for(Entry e:ALL){if(!group.equals(e.group)||!profileId.equals(e.profileId))continue;String er=norm(e.region);if(r.equals(er)||r.contains(er)||er.contains(r))out.add(e);}
        out.sort(Comparator.comparingInt((Entry e)->e.foundedYear==0?Integer.MAX_VALUE:e.foundedYear).thenComparing(e->e.name));return out;
    }
    public static String norm(String s){
        if(s==null)return "";String x=s.toLowerCase(new Locale("tr","TR")).replace('ı','i').replace('ğ','g').replace('ü','u').replace('ş','s').replace('ö','o').replace('ç','c');
        x=Normalizer.normalize(x,Normalizer.Form.NFD).replaceAll("\\p{M}","");return x.replaceAll("[^a-z0-9]+"," ").trim();
    }
}
