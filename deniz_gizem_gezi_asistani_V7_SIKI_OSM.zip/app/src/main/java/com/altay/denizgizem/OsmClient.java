package com.altay.denizgizem;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

public final class OsmClient {
    private static final String UA="DenizGizemGeziAsistani/7.0 Android";
    private static final String NOMINATIM="https://nominatim.openstreetmap.org/search";
    private static final String[] OVERPASS={"https://overpass-api.de/api/interpreter","https://overpass.private.coffee/api/interpreter"};
    private static final Map<String,GeoArea>CACHE=new HashMap<>();
    private static long lastNominatim=0L;

    public static final class GeoArea {
        public String displayName="";
        public double south,west,north,east,lat,lon;
        public boolean contains(double y,double x){return y>=south&&y<=north&&x>=west&&x<=east;}
        public String bbox(){return south+","+west+","+north+","+east;}
    }

    public static final class Place {
        public String name="",typeLabel="",address="",phone="",startDate="",wikipedia="",wikidata="",surface="",brand="";
        public double lat=Double.NaN,lon=Double.NaN,distanceKm=Double.NaN;
        public boolean encyclopedic(){return !wikipedia.isEmpty()||!wikidata.isEmpty();}
        public int startYear(){Matcher m=Pattern.compile("(1[0-9]{3}|20[0-9]{2})").matcher(startDate==null?"":startDate);return m.find()?Integer.parseInt(m.group(1)):9999;}
    }

    private OsmClient(){}

    public static synchronized GeoArea geocode(String region)throws Exception{
        String key=CuratedData.norm(region);if(key.isEmpty())throw new IllegalArgumentException("Bölge boş.");
        if(CACHE.containsKey(key))return CACHE.get(key);
        long wait=1100-(System.currentTimeMillis()-lastNominatim);if(wait>0)Thread.sleep(wait);

        String q=region.trim();String nq=CuratedData.norm(q);
        if(!nq.contains("turkiye")&&!nq.contains("turkey"))q+=", Türkiye";
        String url=NOMINATIM+"?format=jsonv2&limit=1&countrycodes=tr&accept-language=tr&q="+enc(q);

        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setRequestMethod("GET");c.setConnectTimeout(10000);c.setReadTimeout(12000);c.setRequestProperty("User-Agent",UA);c.setRequestProperty("Accept","application/json");
        int code=c.getResponseCode();String body=read(code>=200&&code<300?c.getInputStream():c.getErrorStream());c.disconnect();lastNominatim=System.currentTimeMillis();
        if(code<200||code>=300)throw new IOException("Bölge servisi HTTP "+code);

        Object root=MiniJson.parse(body);if(!(root instanceof List)||((List<?>)root).isEmpty())throw new IOException("Bölge bulunamadı.");
        @SuppressWarnings("unchecked") Map<String,Object>m=(Map<String,Object>)((List<?>)root).get(0);
        @SuppressWarnings("unchecked") List<Object>b=(List<Object>)m.get("boundingbox");

        GeoArea g=new GeoArea();g.displayName=str(m.get("display_name"));g.lat=dbl(m.get("lat"));g.lon=dbl(m.get("lon"));
        g.south=dbl(b.get(0));g.north=dbl(b.get(1));g.west=dbl(b.get(2));g.east=dbl(b.get(3));
        CACHE.put(key,g);return g;
    }

    public static List<Place> search(GeoArea area,SearchProfiles.Profile p)throws Exception{
        String q=buildQuery(area,p);Exception last=null;
        for(String ep:OVERPASS){try{List<Place>x=filter(parseOverpass(post(ep,q),area),p);rank(x);return x.size()>30?new ArrayList<>(x.subList(0,30)):x;}catch(Exception e){last=e;}}
        throw last==null?new IOException("Harita servisi yok"):last;
    }

    private static String nwr(String b,String filters){return "nwr"+filters+"("+b+");";}

    public static String buildQuery(GeoArea a,SearchProfiles.Profile p){
        String b=a.bbox();StringBuilder q=new StringBuilder("[out:json][timeout:24];(");
        if("sea".equals(p.group)){
            if("plaj".equals(p.id)){q.append(nwr(b,"[\"natural\"=\"beach\"][\"name\"]"));q.append(nwr(b,"[\"leisure\"~\"^(beach|beach_resort)$\"][\"name\"]"));}
            else if("kum".equals(p.id)){q.append(nwr(b,"[\"natural\"=\"beach\"][\"surface\"~\"^(sand|fine_sand|sandy)$\",i][\"name\"]"));q.append(nwr(b,"[\"natural\"=\"beach\"][\"name\"~\"kum|kumsal|sand\",i]"));}
            else if("koy".equals(p.id))q.append(nwr(b,"[\"natural\"=\"bay\"][\"name\"]"));
        }else if("discover".equals(p.group)){
            if("magara".equals(p.id))q.append(nwr(b,"[\"natural\"=\"cave_entrance\"][\"name\"]"));
            else if("muze".equals(p.id))q.append(nwr(b,"[\"tourism\"=\"museum\"][\"name\"]"));
            else if("kale".equals(p.id))q.append(nwr(b,"[\"historic\"~\"^(castle|fort)$\"][\"name\"]"));
            else if("antik".equals(p.id)){q.append(nwr(b,"[\"historic\"=\"archaeological_site\"][\"name\"]"));q.append(nwr(b,"[\"historic\"=\"ruins\"][\"name\"]"));}
            else if("tarihi".equals(p.id))q.append(nwr(b,"[\"historic\"][\"name\"]"));
        }else if("stay".equals(p.group)){
            if("otel".equals(p.id))q.append(nwr(b,"[\"tourism\"~\"^(hotel|motel|resort)$\"][\"name\"]"));
            else if("pansiyon".equals(p.id))q.append(nwr(b,"[\"tourism\"~\"^(guest_house|hostel|bed_and_breakfast)$\"][\"name\"]"));
            else if("apart".equals(p.id))q.append(nwr(b,"[\"tourism\"=\"apartment\"][\"name\"]"));
            else if("kamp".equals(p.id))q.append(nwr(b,"[\"tourism\"~\"^(camp_site|caravan_site)$\"][\"name\"]"));
        }else if("food".equals(p.group)){
            String aTag="[\"amenity\"~\"^(restaurant|fast_food|cafe)$\"]";
            if("ciger".equals(p.id))q.append(nwr(b,aTag+"[\"name\"~\"ciğer|ciger|arnavut|liver\",i]"));
            else if("kofte".equals(p.id)){q.append(nwr(b,aTag+"[\"name\"~\"köfte|kofte|meatball\",i]"));q.append(nwr(b,aTag+"[\"cuisine\"~\"meatball\",i][\"name\"]"));}
            else if("kebap".equals(p.id)){q.append(nwr(b,aTag+"[\"name\"~\"kebap|kebab|ocakbaşı|ocakbasi\",i]"));q.append(nwr(b,aTag+"[\"cuisine\"~\"kebab\",i][\"name\"]"));}
            else if("sulu".equals(p.id)||"esnaf".equals(p.id))q.append(nwr(b,aTag+"[\"name\"~\"lokanta|sofra|ev yemek|esnaf\",i]"));
            else if("tavuk".equals(p.id)){q.append(nwr(b,aTag+"[\"name\"~\"tavuk|piliç|pilic|chicken\",i]"));q.append(nwr(b,aTag+"[\"cuisine\"~\"chicken\",i][\"name\"]"));}
            else if("balik".equals(p.id)){q.append(nwr(b,aTag+"[\"name\"~\"balık|balik|fish|seafood\",i]"));q.append(nwr(b,aTag+"[\"cuisine\"~\"fish|seafood\",i][\"name\"]"));}
            else if("kahvalti".equals(p.id)){q.append(nwr(b,aTag+"[\"name\"~\"kahvaltı|kahvalti|breakfast|serpme\",i]"));q.append(nwr(b,aTag+"[\"breakfast\"=\"yes\"][\"name\"]"));}
        }
        return q.append(");out center tags;").toString();
    }

    @SuppressWarnings("unchecked")
    public static List<Place> parseOverpass(String body,GeoArea area){
        Object root=MiniJson.parse(body);List<Place>out=new ArrayList<>();if(!(root instanceof Map))return out;
        Object es=((Map<String,Object>)root).get("elements");if(!(es instanceof List))return out;Set<String>seen=new HashSet<>();

        for(Object eo:(List<Object>)es){
            if(!(eo instanceof Map))continue;Map<String,Object>e=(Map<String,Object>)eo;Object to=e.get("tags");if(!(to instanceof Map))continue;Map<String,Object>t=(Map<String,Object>)to;
            String name=str(t.get("name"));if(name.isEmpty())continue;double lat=num(e.get("lat"),Double.NaN),lon=num(e.get("lon"),Double.NaN);
            if(Double.isNaN(lat)||Double.isNaN(lon)){Object co=e.get("center");if(co instanceof Map){Map<String,Object>cm=(Map<String,Object>)co;lat=num(cm.get("lat"),Double.NaN);lon=num(cm.get("lon"),Double.NaN);}}
            if(Double.isNaN(lat)||Double.isNaN(lon)||!area.contains(lat,lon))continue;
            String key=CuratedData.norm(name)+"|"+Math.round(lat*1000)+"|"+Math.round(lon*1000);if(!seen.add(key))continue;

            Place p=new Place();p.name=name;p.lat=lat;p.lon=lon;p.distanceKm=haversine(area.lat,area.lon,lat,lon);p.phone=first(t,"phone","contact:phone");
            p.startDate=str(t.get("start_date"));p.wikipedia=str(t.get("wikipedia"));p.wikidata=str(t.get("wikidata"));p.surface=str(t.get("surface"));p.brand=str(t.get("brand"));
            p.typeLabel=typeLabel(t);p.address=address(t);out.add(p);
        }return out;
    }

    public static List<Place> filter(List<Place>in,SearchProfiles.Profile p){
        List<Place>out=new ArrayList<>();
        for(Place x:in){
            String n=CuratedData.norm(x.name),ty=CuratedData.norm(x.typeLabel),brand=CuratedData.norm(x.brand);
            if("food".equals(p.group)&&!brand.isEmpty())continue; // yerel öncelik: markalı zincirleri çıkar
            if("sea".equals(p.group)&&any(n,"market","bank","banka","akbank","otel","hotel","cafe","restoran","restaurant","eczane","mobilya","emlak"))continue;
            if("discover".equals(p.group)&&any(n,"cafe","market","restoran","restaurant","otel","hotel"))continue;
            if("stay".equals(p.group)&&any(n,"market","bank","banka","cafe","restoran","restaurant"))continue;

            if("sea".equals(p.group)){
                if("plaj".equals(p.id)&&!any(ty,"beach","plaj"))continue;
                if("kum".equals(p.id)&&!(any(ty,"beach","plaj")&&(any(CuratedData.norm(x.surface),"sand","sandy","fine sand")||any(n,"kum","kumsal","sand"))))continue;
                if("koy".equals(p.id)&&!any(ty,"bay","koy"))continue;
            }
            if("discover".equals(p.group)){
                if("magara".equals(p.id)&&!any(ty,"cave","magara"))continue;
                if("muze".equals(p.id)&&!any(ty,"museum","muze"))continue;
                if("kale".equals(p.id)&&!any(ty,"castle","fort","kale"))continue;
                if("antik".equals(p.id)&&!any(ty,"archaeological","ruins","arkeoloji","harabe"))continue;
                if("tarihi".equals(p.id)&&!any(ty,"historic","tarihi"))continue;
            }
            out.add(x);
        }return out;
    }

    public static void rank(List<Place>x){
        x.sort((a,b)->{int ay=a.startYear(),by=b.startYear();if(ay!=by)return Integer.compare(ay,by);if(a.encyclopedic()!=b.encyclopedic())return a.encyclopedic()?-1:1;return Double.compare(a.distanceKm,b.distanceKm);});
    }

    private static String typeLabel(Map<String,Object>t){
        if("beach".equals(str(t.get("natural"))))return "Beach / Plaj";if("bay".equals(str(t.get("natural"))))return "Bay / Koy";if("cave_entrance".equals(str(t.get("natural"))))return "Cave / Mağara";
        if("museum".equals(str(t.get("tourism"))))return "Museum / Müze";String h=str(t.get("historic"));if(!h.isEmpty())return "Historic / "+h;String tr=str(t.get("tourism"));if(!tr.isEmpty())return "Konaklama / "+tr;
        String a=str(t.get("amenity"));if(!a.isEmpty())return "Yeme-İçme / "+a;return "OpenStreetMap kaydı";
    }
    private static String address(Map<String,Object>t){StringBuilder b=new StringBuilder();for(String k:new String[]{"addr:street","addr:neighbourhood","addr:suburb","addr:district","addr:city","addr:province"}){String v=str(t.get(k));if(!v.isEmpty()){if(b.length()>0)b.append(", ");b.append(v);}}return b.toString();}
    private static String first(Map<String,Object>t,String...ks){for(String k:ks){String v=str(t.get(k));if(!v.isEmpty())return v;}return "";}
    private static boolean any(String h,String...ns){for(String n:ns)if(h.contains(CuratedData.norm(n)))return true;return false;}
    private static String post(String ep,String q)throws Exception{byte[]d=("data="+enc(q)).getBytes(StandardCharsets.UTF_8);HttpURLConnection c=(HttpURLConnection)new URL(ep).openConnection();c.setRequestMethod("POST");c.setDoOutput(true);c.setConnectTimeout(12000);c.setReadTimeout(28000);c.setRequestProperty("User-Agent",UA);c.setRequestProperty("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");try(OutputStream o=c.getOutputStream()){o.write(d);}int code=c.getResponseCode();String body=read(code>=200&&code<300?c.getInputStream():c.getErrorStream());c.disconnect();if(code<200||code>=300)throw new IOException("Harita servisi HTTP "+code);return body;}
    private static String read(InputStream in)throws IOException{if(in==null)return "";try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){StringBuilder b=new StringBuilder();String l;while((l=r.readLine())!=null)b.append(l);return b.toString();}}
    private static String enc(String s){return URLEncoder.encode(s,StandardCharsets.UTF_8);}private static String str(Object o){return o==null?"":String.valueOf(o);}private static double dbl(Object o){return Double.parseDouble(String.valueOf(o));}
    private static double num(Object o,double f){return o instanceof Number?((Number)o).doubleValue():f;}
    private static double haversine(double a,double o,double b,double p){double R=6371,dLat=Math.toRadians(b-a),dLon=Math.toRadians(p-o),q=Math.sin(dLat/2)*Math.sin(dLat/2)+Math.cos(Math.toRadians(a))*Math.cos(Math.toRadians(b))*Math.sin(dLon/2)*Math.sin(dLon/2);return R*2*Math.atan2(Math.sqrt(q),Math.sqrt(1-q));}
}
