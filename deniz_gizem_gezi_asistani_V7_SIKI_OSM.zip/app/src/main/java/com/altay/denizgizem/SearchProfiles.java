package com.altay.denizgizem;
import java.util.*;

public final class SearchProfiles {
    public static final class Profile {
        public final String group,id,label; public final boolean curatedOnly;
        Profile(String g,String i,String l,boolean c){group=g;id=i;label=l;curatedOnly=c;}
    }
    private SearchProfiles(){}
    private static Profile p(String g,String i,String l,boolean c){return new Profile(g,i,l,c);}
    public static List<Profile> forGroup(String g){
        switch(g){
            case "food": return Arrays.asList(
                p("food","ciger","🥩 Ciğer / Arnavut",false),
                p("food","kofte","🧆 Köfte",false),
                p("food","kebap","🔥 Kebap",false),
                p("food","sulu","🍲 Sulu Yemek",false),
                p("food","tavuk","🍗 Tavuk",false),
                p("food","esnaf","🥘 Esnaf Lokantası",false),
                p("food","balik","🐟 Balık",false),
                p("food","kahvalti","🍳 Kahvaltı",false));
            case "sea": return Arrays.asList(
                p("sea","plaj","🏖️ Plaj",false),
                p("sea","kum","👣 Kumlu Plaj",false),
                p("sea","koy","🌊 Koy",false));
            case "discover": return Arrays.asList(
                p("discover","antik","🏺 Antik Kent / Arkeoloji",false),
                p("discover","kale","🏰 Kale",false),
                p("discover","magara","🕳️ Mağara",false),
                p("discover","muze","🏛️ Müze",false),
                p("discover","tarihi","📜 Tarihi Yer",false),
                p("discover","gizem","👁️ Gizem / Efsane",true));
            case "stay": return Arrays.asList(
                p("stay","pansiyon","🏡 Pansiyon",false),
                p("stay","apart","🏢 Apart",false),
                p("stay","otel","🏨 Otel",false),
                p("stay","kamp","⛺ Kamp",false));
            default:return Collections.emptyList();
        }
    }
}
