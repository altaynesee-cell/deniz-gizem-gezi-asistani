package com.altay.denizgizem;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private EditText region; private LinearLayout options,results; private TextView status; private ProgressBar progress;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(14),dp(12),dp(14),dp(8));
        TextView title=tv("DENİZ GİZEM\nGEZİ ASİSTANI V7",24,true);title.setGravity(Gravity.CENTER);root.addView(title);
        TextView sub=tv("SIKI MOD • gerçek mekân türü • bölge sınırı kilitli",14,false);sub.setGravity(Gravity.CENTER);root.addView(sub);
        region=new EditText(this);region.setHint("Bölge: Bodrum, Bursa, Kemer…");region.setSingleLine(true);region.setTextSize(19);root.addView(region);
        status=tv("Bölgeyi yaz ve kategori seç.",14,false);root.addView(status);
        progress=new ProgressBar(this);progress.setVisibility(View.GONE);root.addView(progress);

        HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);LinearLayout tabs=row();
        addTab(tabs,"🍽 LEZZET","food");addTab(tabs,"🌊 DENİZ","sea");addTab(tabs,"🏛 KEŞFET","discover");addTab(tabs,"🛏 KONAK","stay");hs.addView(tabs);root.addView(hs);

        ScrollView sc=new ScrollView(this);LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);
        options=new LinearLayout(this);options.setOrientation(LinearLayout.VERTICAL);body.addView(options);
        results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);body.addView(results);
        sc.addView(body);root.addView(sc,new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,0,1f));
        TextView attr=tv("Mekân verileri: © OpenStreetMap katkıcıları",11,false);attr.setGravity(Gravity.CENTER);root.addView(attr);
        setContentView(root);showGroup("food");
    }

    private void addTab(LinearLayout p,String s,String g){Button b=button(s);b.setOnClickListener(v->showGroup(g));p.addView(b);}
    private void showGroup(String g){
        options.removeAllViews();results.removeAllViews();
        if("food".equals(g)){options.addView(tv("🍽 LEZZET",20,true));options.addView(tv("Köklü/meşhur doğrulanmış seçim varsa üstte; zincir marka ve alakasız işletme elenir.",13,false));}
        else if("sea".equals(g)){options.addView(tv("🌊 DENİZ",20,true));options.addView(tv("Plaj=gerçek beach. Koy=gerçek bay. Market/banka/otel çıkmaz.",13,false));}
        else if("discover".equals(g)){options.addView(tv("🏛 KEŞFET",20,true));options.addView(tv("Mağara=cave_entrance, müze=museum, antik=archaeological_site. İsim benzerliği kullanılmaz.",13,false));}
        else{options.addView(tv("🛏 KONAK",20,true));options.addView(tv("Yalnız gerçek otel/pansiyon/apart/kamp türleri.",13,false));}
        for(SearchProfiles.Profile p:SearchProfiles.forGroup(g)){Button b=button(p.label);b.setAllCaps(false);b.setOnClickListener(v->runSearch(p));options.addView(b);}
    }

    private void runSearch(SearchProfiles.Profile p){
        String r=region.getText().toString().trim();if(r.isEmpty()){Toast.makeText(this,"Önce bölge yaz.",Toast.LENGTH_SHORT).show();return;}
        results.removeAllViews();List<CuratedData.Entry>cur=CuratedData.find(r,p.group,p.id);renderCurated(cur);
        if(p.curatedOnly){status.setText(r+" • "+p.label);if(cur.isEmpty())results.addView(tv("Bu bölge için doğrulanmış gizem/efsane kaydı yok. Uydurma sonuç göstermiyorum.",14,false));return;}

        progress.setVisibility(View.VISIBLE);status.setText(r+" • bölge sınırı bulunuyor…");
        new Thread(()->{try{
            OsmClient.GeoArea a=OsmClient.geocode(r);runOnUiThread(()->status.setText(a.displayName+" • "+p.label+" aranıyor…"));
            List<OsmClient.Place>live=OsmClient.search(a,p);
            runOnUiThread(()->{progress.setVisibility(View.GONE);renderLive(live);status.setText(r+" • "+p.label+" • hazır");});
        }catch(Exception e){runOnUiThread(()->{progress.setVisibility(View.GONE);results.addView(tv("Canlı arama alınamadı: "+(e.getMessage()==null?"bağlantı hatası":e.getMessage()),13,false));status.setText(r+" • yerel kayıtlar");});}}).start();
    }

    private void renderCurated(List<CuratedData.Entry>x){
        if(x.isEmpty())return;results.addView(tv("🏆 KÖKLÜ / MEŞHUR DOĞRULANMIŞ",19,true));int i=1;
        for(CuratedData.Entry e:x){LinearLayout c=card();c.addView(tv((i==1?"⭐ ÖNE ÇIKAN • ":"")+e.name,18,true));if(!e.yearLabel.isEmpty())c.addView(tv("📅 "+e.yearLabel,14,true));c.addView(tv("🏷 "+e.tag,13,false));c.addView(tv(e.why,14,false));c.addView(tv("📍 "+e.address,13,false));
            Button b=button("YOL TARİFİ");b.setOnClickListener(v->openAddress(e.address,e.name));c.addView(b);results.addView(c);i++;}
    }

    private void renderLive(List<OsmClient.Place>x){
        results.addView(tv("🗺️ CANLI • DOĞRU TÜRDE SONUÇLAR",18,true));
        if(x.isEmpty()){results.addView(tv("Güvenli eşleşme bulunmadı. Yanlış yer göstermek yerine boş bırakıyorum.",14,false));return;}
        int i=1;for(OsmClient.Place p:x){LinearLayout c=card();String badge=p.startYear()!=9999?"🕰️ TARİHLİ • ":(p.encyclopedic()?"📚 TANINMIŞ • ":"");
            c.addView(tv(badge+i+". "+p.name,17,true));c.addView(tv(p.typeLabel,12,false));if(p.startYear()!=9999)c.addView(tv("📅 "+p.startDate,13,false));
            c.addView(tv(String.format(Locale.getDefault(),"📏 Merkezden %.1f km",p.distanceKm),13,false));if(!p.surface.isEmpty())c.addView(tv("🏖 Yüzey: "+p.surface,13,false));if(!p.address.isEmpty())c.addView(tv("📍 "+p.address,13,false));
            LinearLayout a=row();Button rt=button("YOL TARİFİ");rt.setOnClickListener(v->openLive(p));a.addView(rt);if(!p.phone.isEmpty()){Button ph=button("ARA");ph.setOnClickListener(v->dial(p.phone));a.addView(ph);}c.addView(a);results.addView(c);i++;}
    }

    private void openAddress(String a,String n){try{startActivity(Intent.createChooser(new Intent(Intent.ACTION_VIEW,Uri.parse("geo:0,0?q="+Uri.encode(a+" "+n))),"Yol tarifi"));}catch(Exception e){Toast.makeText(this,"Navigasyon açılamadı.",Toast.LENGTH_SHORT).show();}}
    private void openLive(OsmClient.Place p){try{String u="geo:"+p.lat+","+p.lon+"?q="+Uri.encode(p.lat+","+p.lon+"("+p.name+")");startActivity(Intent.createChooser(new Intent(Intent.ACTION_VIEW,Uri.parse(u)),"Yol tarifi"));}catch(Exception e){Toast.makeText(this,"Navigasyon açılamadı.",Toast.LENGTH_SHORT).show();}}
    private void dial(String t){try{startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+Uri.encode(t))));}catch(Exception ignored){}}
    private LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(10),dp(8),dp(10),dp(8));return c;}
    private LinearLayout row(){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);return r;}
    private Button button(String s){Button b=new Button(this);b.setText(s);return b;}
    private TextView tv(String s,float z,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);if(bold)t.setTypeface(null,Typeface.BOLD);t.setPadding(0,dp(3),0,dp(3));return t;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
