package com.altay.denizgizem;

import java.text.Normalizer;
import java.util.*;

public final class CuratedData {
    public static final class Entry {
        public final String region,group,profileId,name,address,yearLabel,why,tag,source;
        public final int foundedYear;
        Entry(String r,String g,String p,String n,String a,int y,String yl,String w,String t,String s){
            region=r;group=g;profileId=p;name=n;address=a;foundedYear=y;yearLabel=yl;why=w;tag=t;source=s;
        }
    }
    private static final List<Entry> ALL=new ArrayList<>();
    static{
        add("bodrum","food","ciger","Milas Sofrası Ciğerci Durmuş Usta","Bodrum, Muğla",2000,"2000'den beri",
            "Ciğer, sulu yemek ve ızgara sunan yerel lokanta. Köklü/meşhur seçim olarak üstte gösterilir.","YEREL • SALAŞ","Doğrulanmış işletme bilgisi");
        add("bodrum","food","sulu","Milas Sofrası Ciğerci Durmuş Usta","Bodrum, Muğla",2000,"2000'den beri",
            "Sulu yemek ve ciğer için yerel, köklü seçenek.","YEREL • SALAŞ","Doğrulanmış işletme bilgisi");
        add("bodrum","food","kofte","Köfteci Bilal'in Yeri","Bodrum Merkez, Muğla",1972,"1970'lerden beri",
            "Bodrum merkezde eski esnaf lokantası geleneğiyle anılan köfteci.","ESNAF • SALAŞ","Yerel tarih/işletme kayıtları");
        add("bodrum","food","esnaf","Köfteci Bilal'in Yeri","Bodrum Merkez, Muğla",1972,"1970'lerden beri",
            "Köfte, çorba ve esnaf lokantası tarzı yemekler için köklü seçim.","ESNAF • SALAŞ","Yerel tarih/işletme kayıtları");
        add("bodrum","food","balik","Körfez Restaurant","Bodrum Merkez, Muğla",1927,"1927'den beri",
            "Bodrum'un en köklü lokantalarından; balık ve deniz ürünleri geçmişiyle bilinir.","KÖKLÜ • UCUZLUK GARANTİSİ YOK","İşletme tarihçesi");
        add("bodrum","food","kahvalti","Asmalı Çardak","Yalıkavak, Bodrum, Muğla",0,"",
            "Eski Bodrum evi atmosferinde yerel kahvaltı için bilinen seçenek.","YEREL","İşletme tanıtımı");

        add("bursa","food","kebap","Kebapçı İskender","Bursa",1867,"1867'den beri",
            "İskender kebap geleneğinin tarihî aile işletmesi.","ÇOK KÖKLÜ","Resmî işletme tarihi");
        add("bursa","food","kofte","Besler İnegöl Köftecisi","İnegöl, Bursa",1893,"1893'ten beri",
            "İnegöl köftesi geleneğinin eski işletmelerinden.","KÖKLÜ","Yerel turizm kaynağı");

        add("bodrum","sea","sig_kum","Akyarlar Sahili","Akyarlar, Bodrum, Muğla",0,"",
            "Kumlu ve nispeten sığ bölümleriyle aile tipi deniz için güçlü seçenek.","PLAJ","Yerel gezi verisi");
        add("bodrum","sea","sig_kum","Bitez Sahili","Bitez, Bodrum, Muğla",0,"",
            "Koy yapısı ve sığlaşan kıyı bölümleriyle rahat yüzme seçeneği.","PLAJ","Yerel gezi verisi");
        add("bodrum","sea","plaj","Ortakent Yahşi Plajı","Ortakent, Bodrum, Muğla",0,"",
            "Uzun sahil ve temiz deniz için bilinen plaj.","PLAJ","Yerel gezi verisi");
        add("bodrum","sea","sakin_koy","Bitez Koyu","Bitez, Bodrum, Muğla",0,"",
            "Korunaklı koy yapısıyla daha sakin olabilen bölümler.","KOY","Yerel gezi verisi");

        add("bodrum","discover","magara","Peynir Çiçeği Mağarası","Gündoğan çevresi, Bodrum, Muğla",0,"",
            "Gerçek mağara; tarihöncesi buluntu ve doğal oluşumlarıyla bilinir.","MAĞARA","Yerel belediye/tanıtım kaynağı");
        add("bodrum","discover","antik","Myndos Antik Kenti","Gümüşlük, Bodrum, Muğla",0,"",
            "Antik Myndos yerleşimi ve nekropol alanları.","ANTİK KENT","Yerel gezi verisi");
        add("bodrum","discover","kale","Bodrum Kalesi","Bodrum Merkez, Muğla",0,"",
            "Saint Jean Şövalyeleri tarafından inşa edilen simge tarihî yapı.","KALE","Yerel gezi verisi");
        add("bodrum","discover","muze","Bodrum Sualtı Arkeoloji Müzesi","Bodrum Kalesi, Muğla",0,"",
            "Sualtı arkeolojisi koleksiyonlarıyla ana müze durağı.","MÜZE","Yerel gezi verisi");
        add("bodrum","discover","tarihi","Halikarnassos Mausoleion","Bodrum, Muğla",0,"",
            "Antik Dünyanın Yedi Harikası arasında anılan anıt mezar.","TARİH","Yerel gezi verisi");
        add("bodrum","discover","gizem","Salmakis (Bardakçı) Koyu","Bardakçı, Bodrum, Muğla",0,"",
            "Salmakis–Hermaphroditos efsanesiyle ilişkilendirilen yer.","EFSANE","Yerel tarih kaynağı");
        add("bodrum","discover","gizem","Halikarnassos Mausoleion","Bodrum, Muğla",0,"",
            "Antik ölüm anıtı ve Yedi Harika bağlantısıyla gizem/tarih durağı.","GİZEM • TARİH","Yerel gezi verisi");

        add("antalya","discover","magara","Karain Mağarası","Yağca, Antalya",0,"",
            "Türkiye'nin önemli tarihöncesi mağara yerleşimlerinden.","MAĞARA","Yerel gezi verisi");
        add("alanya","discover","magara","Damlataş Mağarası","Alanya, Antalya",0,"",
            "Alanya merkezde gerçek turistik mağara.","MAĞARA","Yerel gezi verisi");
        add("mersin","discover","magara","Cennet-Cehennem Obrukları","Narlıkuyu, Silifke, Mersin",0,"",
            "Büyük karst oluşumları ve mitolojik anlatılarla bilinen doğal alan.","DOĞAL OLUŞUM","Yerel gezi verisi");
    }
    private CuratedData(){}
    private static void add(String r,String g,String p,String n,String a,int y,String yl,String w,String t,String s){
        ALL.add(new Entry(r,g,p,n,a,y,yl,w,t,s));
    }
    public static List<Entry> find(String region,String group,String profileId){
        String r=norm(region); List<Entry> out=new ArrayList<>();
        for(Entry e:ALL){
            if(!group.equals(e.group)||!profileId.equals(e.profileId))continue;
            String er=norm(e.region);
            if(r.contains(er)||er.contains(r)) out.add(e);
        }
        out.sort(Comparator.comparingInt((Entry e)->e.foundedYear==0?Integer.MAX_VALUE:e.foundedYear).thenComparing(e->e.name));
        return out;
    }
    public static String norm(String s){
        if(s==null)return "";
        String x=s.toLowerCase(new Locale("tr","TR")).replace('ı','i').replace('ğ','g').replace('ü','u').replace('ş','s').replace('ö','o').replace('ç','c');
        x=Normalizer.normalize(x,Normalizer.Form.NFD).replaceAll("\\p{M}","");
        return x.replaceAll("[^a-z0-9]+"," ").trim();
    }
}
