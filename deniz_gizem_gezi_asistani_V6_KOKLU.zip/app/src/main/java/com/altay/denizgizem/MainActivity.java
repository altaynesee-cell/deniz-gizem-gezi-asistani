package com.altay.denizgizem;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final String PREFS="dg_v6",KEY="fsq_key";
    private EditText region,keyInput; private LinearLayout keyBox,options,results; private TextView status; private ProgressBar progress;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(14),dp(14),dp(14),dp(10));
        TextView title=tv("DENİZ GİZEM\nGEZİ ASİSTANI V6",24,true); title.setGravity(Gravity.CENTER); root.addView(title);
        TextView sub=tv("Köklü/meşhur yerleri ayrı gösterir; yanlış türde mekânları eler.",14,false); sub.setGravity(Gravity.CENTER); root.addView(sub);

        Button kb=button("⚙ API ANAHTARI"); kb.setOnClickListener(v->keyBox.setVisibility(keyBox.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE)); root.addView(kb);
        keyBox=new LinearLayout(this); keyBox.setOrientation(LinearLayout.VERTICAL);
        keyInput=new EditText(this); keyInput.setHint("Foursquare Service API Key"); keyInput.setSingleLine(true); keyInput.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD); keyBox.addView(keyInput);
        Button save=button("ANAHTARI KAYDET"); save.setOnClickListener(v->saveKey()); keyBox.addView(save); root.addView(keyBox); keyBox.setVisibility(savedKey().isEmpty()?View.VISIBLE:View.GONE);

        region=new EditText(this); region.setHint("Bölge: örn. Bodrum, Bursa, Antalya"); region.setSingleLine(true); region.setTextSize(18); root.addView(region);
        status=tv("Bölgeyi yaz ve kategori seç.",14,false); root.addView(status);
        progress=new ProgressBar(this); progress.setVisibility(View.GONE); root.addView(progress);

        HorizontalScrollView hs=new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false); LinearLayout tabs=row();
        addTab(tabs,"🍽 LEZZET","food"); addTab(tabs,"🌊 DENİZ","sea"); addTab(tabs,"🏛 KEŞFET","discover"); addTab(tabs,"🛏 KONAK","stay"); hs.addView(tabs); root.addView(hs);

        ScrollView sc=new ScrollView(this); LinearLayout body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL);
        options=new LinearLayout(this); options.setOrientation(LinearLayout.VERTICAL); body.addView(options);
        results=new LinearLayout(this); results.setOrientation(LinearLayout.VERTICAL); body.addView(results);
        sc.addView(body); root.addView(sc,new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,0,1f));
        setContentView(root); showGroup("food");
    }

    private void addTab(LinearLayout p,String s,String g){Button b=button(s);b.setOnClickListener(v->showGroup(g));p.addView(b);}
    private void showGroup(String g){
        options.removeAllViews();results.removeAllViews();
        if("food".equals(g)){options.addView(tv("🍽 LEZZET",20,true));options.addView(tv("Önce köklü/meşhur seçimler; sonra doğru türde canlı yerel sonuçlar.",13,false));}
        else if("sea".equals(g)){options.addView(tv("🌊 DENİZ",20,true));options.addView(tv("Market, restoran, otel plaj listesine giremez.",13,false));}
        else if("discover".equals(g)){options.addView(tv("🏛 KEŞFET",20,true));options.addView(tv("Mağara yalnız gerçek mağara/doğal oluşum; gizem yalnız doğrulanmış kayıt.",13,false));}
        else {options.addView(tv("🛏 KONAK",20,true));options.addView(tv("Yalnız pansiyon/apart/otel/kamp türleri.",13,false));}
        for(SearchProfiles.Profile p:SearchProfiles.forGroup(g)){Button b=button(p.label);b.setAllCaps(false);b.setOnClickListener(v->runSearch(p));options.addView(b);}
    }

    private void runSearch(SearchProfiles.Profile p){
        String r=region.getText().toString().trim(); if(r.isEmpty()){Toast.makeText(this,"Önce bölge yaz.",Toast.LENGTH_SHORT).show();return;}
        results.removeAllViews(); List<CuratedData.Entry> curated=CuratedData.find(r,p.group,p.id); renderCurated(curated);

        if(p.curatedOnly){
            status.setText(r+" • "+p.label+" • doğrulanmış kayıtlar");
            if(curated.isEmpty())results.addView(tv("Bu bölge için doğrulanmış gizem/efsane kaydı henüz eklenmedi. Rastgele sonuç göstermiyorum.",15,false));
            return;
        }

        String k=savedKey(); if(k.isEmpty()){status.setText(r+" • "+p.label+" • köklü kayıtlar hazır");results.addView(tv("Canlı ek sonuçlar için API anahtarını kaydet.",13,false));return;}
        progress.setVisibility(View.VISIBLE); status.setText(r+" • "+p.label+" • aranıyor…");

        new Thread(()->{try{
            List<FoursquareClient.Place> live=FoursquareClient.search(k,r,p);
            runOnUiThread(()->{progress.setVisibility(View.GONE);renderLive(live);status.setText(r+" • "+p.label+" • hazır");});
        }catch(Exception e){runOnUiThread(()->{progress.setVisibility(View.GONE);results.addView(tv("Canlı sonuç alınamadı: "+(e.getMessage()==null?"hata":e.getMessage()),13,false));status.setText(r+" • köklü kayıtlar gösteriliyor");});}}).start();
    }

    private void renderCurated(List<CuratedData.Entry> list){
        if(list.isEmpty())return; results.addView(tv("🏺 KÖKLÜ / MEŞHUR",19,true));
        results.addView(tv("Bu sıra puan sırası değildir; kuruluş geçmişi/yerel ünü doğrulanabilen seçimlerdir.",12,false));
        int i=1; for(CuratedData.Entry e:list){LinearLayout c=card();c.addView(tv((i==1?"🏆 EN KÖKLÜ SEÇİM • ":"")+e.name,18,true));
            if(!e.yearLabel.isEmpty())c.addView(tv("📅 "+e.yearLabel,14,true)); if(!e.tag.isEmpty())c.addView(tv("🏷 "+e.tag,13,false)); c.addView(tv(e.why,14,false)); c.addView(tv("📍 "+e.address,13,false));
            Button rt=button("YOL TARİFİ");rt.setOnClickListener(v->openAddress(e.address,e.name));c.addView(rt);results.addView(c);i++;}
    }

    private void renderLive(List<FoursquareClient.Place> list){
        results.addView(tv("📡 DİĞER DOĞRU TÜRDE SONUÇLAR",18,true));
        if(list.isEmpty()){results.addView(tv("Doğru kategoriye uyan başka sonuç çıkmadı. Yanlış sonuç göstermiyorum.",14,false));return;}
        int i=1;for(FoursquareClient.Place p:list){LinearLayout c=card();c.addView(tv(i+". "+p.name,17,true));if(!p.categories.isEmpty())c.addView(tv(p.categories,12,false));if(!p.address.isEmpty())c.addView(tv("📍 "+p.address,13,false));
            LinearLayout a=row();Button rt=button("YOL TARİFİ");rt.setOnClickListener(v->openLive(p));a.addView(rt);if(!p.tel.isEmpty()){Button cl=button("ARA");cl.setOnClickListener(v->dial(p.tel));a.addView(cl);}c.addView(a);results.addView(c);i++;}
    }

    private void openAddress(String a,String n){try{startActivity(Intent.createChooser(new Intent(Intent.ACTION_VIEW,Uri.parse("geo:0,0?q="+Uri.encode(a+" "+n))),"Yol tarifi"));}catch(Exception e){Toast.makeText(this,"Navigasyon açılamadı.",Toast.LENGTH_SHORT).show();}}
    private void openLive(FoursquareClient.Place p){try{String u=!Double.isNaN(p.latitude)&&!Double.isNaN(p.longitude)?"geo:"+p.latitude+","+p.longitude+"?q="+Uri.encode(p.latitude+","+p.longitude+"("+p.name+")"):"geo:0,0?q="+Uri.encode(p.address+" "+p.name);startActivity(Intent.createChooser(new Intent(Intent.ACTION_VIEW,Uri.parse(u)),"Yol tarifi"));}catch(Exception e){Toast.makeText(this,"Navigasyon açılamadı.",Toast.LENGTH_SHORT).show();}}
    private void dial(String t){try{startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+Uri.encode(t))));}catch(Exception e){}}
    private void saveKey(){String k=keyInput.getText().toString().trim();if(k.length()<20){Toast.makeText(this,"Anahtar kısa görünüyor.",Toast.LENGTH_SHORT).show();return;}getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putString(KEY,k).apply();keyInput.setText("");keyBox.setVisibility(View.GONE);Toast.makeText(this,"Anahtar kaydedildi.",Toast.LENGTH_SHORT).show();}
    private String savedKey(){SharedPreferences p=getSharedPreferences(PREFS,Context.MODE_PRIVATE);return p.getString(KEY,"");}
    private LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(10),dp(8),dp(10),dp(8));return c;}
    private LinearLayout row(){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);return r;}
    private Button button(String s){Button b=new Button(this);b.setText(s);return b;}
    private TextView tv(String s,float z,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);if(bold)t.setTypeface(null,Typeface.BOLD);t.setPadding(0,dp(3),0,dp(3));return t;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
