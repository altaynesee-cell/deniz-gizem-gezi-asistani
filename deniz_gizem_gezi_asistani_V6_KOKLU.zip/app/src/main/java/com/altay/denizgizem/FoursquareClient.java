package com.altay.denizgizem;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class FoursquareClient {
    public static final String ENDPOINT="https://places-api.foursquare.com/places/search";
    public static final String API_VERSION="2025-06-17";

    public static final class Place {
        public String id="",name="",address="",categories="",tel="";
        public double latitude=Double.NaN,longitude=Double.NaN;
        public int distance=-1;
    }
    public static final class ApiException extends Exception {
        public final int httpCode; public ApiException(int c,String m){super(m);httpCode=c;}
    }
    private FoursquareClient(){}

    public static List<Place> search(String key,String region,SearchProfiles.Profile p)throws Exception{
        if(key==null||key.trim().isEmpty())throw new ApiException(401,"Foursquare API anahtarı girilmemiş.");
        HttpURLConnection c=(HttpURLConnection)new URL(buildUrl(region,p)).openConnection();
        c.setRequestMethod("GET"); c.setConnectTimeout(9000); c.setReadTimeout(11000);
        c.setRequestProperty("Accept","application/json");
        c.setRequestProperty("Authorization","Bearer "+key.trim());
        c.setRequestProperty("X-Places-Api-Version",API_VERSION);
        int code=c.getResponseCode(); InputStream st=code>=200&&code<300?c.getInputStream():c.getErrorStream();
        StringBuilder b=new StringBuilder(); if(st!=null)try(BufferedReader r=new BufferedReader(new InputStreamReader(st,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)b.append(line);}
        c.disconnect();
        if(code<200||code>=300){
            if(code==401)throw new ApiException(code,"API anahtarı geçersiz.");
            if(code==429)throw new ApiException(code,"Foursquare ücretsiz kullanım sınırına ulaşıldı.");
            throw new ApiException(code,"Foursquare servis hatası: HTTP "+code);
        }
        return StrictRules.filter(parsePlaces(b.toString()),p);
    }

    public static String buildUrl(String region,SearchProfiles.Profile p){
        String near=region==null?"":region.trim(); String low=CuratedData.norm(near);
        if(!low.contains("turkiye")&&!low.contains("turkey"))near+=", Türkiye";
        String fields="fsq_place_id,name,categories,location,latitude,longitude,distance,tel";
        StringBuilder u=new StringBuilder(ENDPOINT);
        u.append("?near=").append(enc(near)).append("&query=").append(enc(p.query)).append("&sort=RATING&limit=30&fields=").append(enc(fields));
        if(p.excludeChains)u.append("&exclude_all_chains=true");
        return u.toString();
    }

    @SuppressWarnings("unchecked")
    public static List<Place> parsePlaces(String json){
        Object ro=MiniJson.parse(json); List<Place> out=new ArrayList<>(); if(!(ro instanceof Map))return out;
        Object rr=((Map<String,Object>)ro).get("results"); if(!(rr instanceof List))return out;
        for(Object o:(List<Object>)rr){ if(!(o instanceof Map))continue; Map<String,Object>m=(Map<String,Object>)o; Place p=new Place();
            p.id=str(m.get("fsq_place_id")); p.name=str(m.get("name")); p.latitude=num(m.get("latitude"),Double.NaN); p.longitude=num(m.get("longitude"),Double.NaN); p.distance=(int)num(m.get("distance"),-1); p.tel=str(m.get("tel"));
            Object lo=m.get("location"); if(lo instanceof Map){ Map<String,Object>l=(Map<String,Object>)lo; String a=str(l.get("address")),city=str(l.get("locality")),reg=str(l.get("region")); StringBuilder ab=new StringBuilder();
                if(!a.isEmpty())ab.append(a); if(!city.isEmpty()){if(ab.length()>0)ab.append(", ");ab.append(city);} if(!reg.isEmpty()&&!reg.equalsIgnoreCase(city)){if(ab.length()>0)ab.append(", ");ab.append(reg);} p.address=ab.toString();}
            Object cc=m.get("categories"); if(cc instanceof List){StringBuilder cb=new StringBuilder();for(Object co:(List<Object>)cc){if(!(co instanceof Map))continue;String n=str(((Map<String,Object>)co).get("name"));if(!n.isEmpty()){if(cb.length()>0)cb.append(" • ");cb.append(n);}}p.categories=cb.toString();}
            if(!p.name.isEmpty())out.add(p);
        }
        return out;
    }
    private static String enc(String s){return URLEncoder.encode(s,StandardCharsets.UTF_8);}
    private static String str(Object o){return o==null?"":String.valueOf(o);}
    private static double num(Object o,double f){return o instanceof Number?((Number)o).doubleValue():f;}
}
