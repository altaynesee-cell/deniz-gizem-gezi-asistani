package com.altay.denizgizem;

import java.util.*;

public final class MiniJson {
    private final String s; private int p;
    private MiniJson(String s){ this.s=s==null?"":s; }
    public static Object parse(String s){ MiniJson j=new MiniJson(s); Object v=j.v(); j.ws(); if(j.p!=j.s.length()) throw new IllegalArgumentException("JSON sonu"); return v; }
    private Object v(){ ws(); if(p>=s.length()) throw new IllegalArgumentException("Boş JSON"); char c=s.charAt(p);
        if(c=='{') return obj(); if(c=='[') return arr(); if(c=='"') return str();
        if(c=='t'){word("true");return true;} if(c=='f'){word("false");return false;} if(c=='n'){word("null");return null;}
        if(c=='-'||Character.isDigit(c)) return num(); throw new IllegalArgumentException("JSON"); }
    private Map<String,Object> obj(){ Map<String,Object> m=new LinkedHashMap<>(); ch('{'); ws(); if(peek('}')){p++;return m;}
        while(true){ String k=str(); ch(':'); m.put(k,v()); ws(); if(peek('}')){p++;return m;} ch(','); } }
    private List<Object> arr(){ List<Object>a=new ArrayList<>(); ch('['); ws(); if(peek(']')){p++;return a;}
        while(true){ a.add(v()); ws(); if(peek(']')){p++;return a;} ch(','); } }
    private String str(){ ch('"'); StringBuilder b=new StringBuilder(); while(p<s.length()){ char c=s.charAt(p++); if(c=='"') return b.toString();
        if(c=='\\'){ char e=s.charAt(p++); switch(e){case '"':b.append('"');break;case '\\':b.append('\\');break;case '/':b.append('/');break;
        case 'b':b.append('\b');break;case 'f':b.append('\f');break;case 'n':b.append('\n');break;case 'r':b.append('\r');break;case 't':b.append('\t');break;
        case 'u':b.append((char)Integer.parseInt(s.substring(p,p+4),16));p+=4;break;default:throw new IllegalArgumentException("escape");}} else b.append(c);}
        throw new IllegalArgumentException("string");}
    private Number num(){ int st=p; if(peek('-'))p++; while(p<s.length()&&Character.isDigit(s.charAt(p)))p++; boolean d=false;
        if(peek('.')){d=true;p++;while(p<s.length()&&Character.isDigit(s.charAt(p)))p++;} String x=s.substring(st,p); return d?Double.parseDouble(x):Long.parseLong(x);}
    private void ws(){while(p<s.length()&&Character.isWhitespace(s.charAt(p)))p++;} private boolean peek(char c){return p<s.length()&&s.charAt(p)==c;}
    private void ch(char c){ws();if(!peek(c))throw new IllegalArgumentException("Beklenen "+c);p++;} private void word(String x){if(!s.startsWith(x,p))throw new IllegalArgumentException(x);p+=x.length();}
}
