package com.altay.denizgizem;

import java.util.*;

public final class SearchProfiles {
    public static final class Profile {
        public final String group,id,label,query; public final boolean curatedOnly,excludeChains;
        Profile(String g,String i,String l,String q,boolean c,boolean e){group=g;id=i;label=l;query=q;curatedOnly=c;excludeChains=e;}
    }
    private SearchProfiles(){}
    private static Profile p(String g,String i,String l,String q,boolean c,boolean e){return new Profile(g,i,l,q,c,e);}
    public static List<Profile> forGroup(String g){
        switch(g){
            case "food": return Arrays.asList(
                p("food","ciger","🥩 Ciğer / Arnavut","ciğer",false,true),
                p("food","kofte","🧆 Köfte","köfte",false,true),
                p("food","kebap","🔥 Kebap","kebap",false,true),
                p("food","sulu","🍲 Sulu Yemek","sulu yemek",false,true),
                p("food","tavuk","🍗 Tavuk","tavuk",false,true),
                p("food","esnaf","🥘 Esnaf Lokantası","esnaf lokantası",false,true),
                p("food","balik","🐟 Balık","balık",false,true),
                p("food","kahvalti","🍳 Kahvaltı","kahvaltı",false,true));
            case "sea": return Arrays.asList(
                p("sea","plaj","🏖️ Plaj","plaj",false,false),
                p("sea","sig_kum","👣 Kum / Sığ Deniz","kum plaj",false,false),
                p("sea","sakin_koy","🌊 Sakin Koy","koy",false,false));
            case "discover": return Arrays.asList(
                p("discover","antik","🏺 Antik Kent","antik kent",false,false),
                p("discover","kale","🏰 Kale","kale",false,false),
                p("discover","magara","🕳️ Mağara","mağara",false,false),
                p("discover","muze","🏛️ Müze","müze",false,false),
                p("discover","tarihi","📜 Tarihi Yer","tarihi yer",false,false),
                p("discover","gizem","👁️ Gizem / Efsane","gizem",true,false));
            case "stay": return Arrays.asList(
                p("stay","pansiyon","🏡 Pansiyon","pansiyon",false,true),
                p("stay","apart","🏢 Apart","apart otel",false,true),
                p("stay","otel","🏨 Otel","otel",false,true),
                p("stay","kamp","⛺ Kamp","kamp alanı",false,true));
            default:return Collections.emptyList();
        }
    }
}
