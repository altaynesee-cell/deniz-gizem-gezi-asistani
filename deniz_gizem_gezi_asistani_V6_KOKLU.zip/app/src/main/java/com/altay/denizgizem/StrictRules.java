package com.altay.denizgizem;
import java.util.*;

public final class StrictRules {
    private StrictRules(){}
    public static List<FoursquareClient.Place> filter(List<FoursquareClient.Place> in,SearchProfiles.Profile p){
        List<FoursquareClient.Place> out=new ArrayList<>(); for(FoursquareClient.Place x:in) if(accept(x,p)) out.add(x); return out;
    }
    public static boolean accept(FoursquareClient.Place p,SearchProfiles.Profile f){
        String n=CuratedData.norm(p.name), c=CuratedData.norm(p.categories);
        if("food".equals(f.group)) return food(n,c,f.id);
        if("sea".equals(f.group)) return sea(n,c,f.id);
        if("discover".equals(f.group)) return discover(n,c,f.id);
        if("stay".equals(f.group)) return stay(n,c,f.id);
        return false;
    }
    private static boolean food(String n,String c,String id){
        boolean rest=any(c,"restaurant","diner","bbq","barbecue","steakhouse","kebab","turkish","breakfast","seafood","fish","cafe","bakery");
        if(!rest)return false;
        switch(id){
            case "ciger":return any(n,"ciger","arnavut","milas")||any(c,"liver");
            case "kofte":return any(n,"kofte","koft")||any(c,"meatball");
            case "kebap":return any(n,"kebap","kebab","ocakbasi","ocak basi")||any(c,"kebab");
            case "sulu":return any(n,"lokanta","sofra","ev yemek")||any(c,"diner");
            case "tavuk":return any(n,"tavuk","pilic","chicken")||any(c,"chicken");
            case "esnaf":return any(n,"lokanta","sofra","ev yemek","esnaf")||any(c,"diner");
            case "balik":return any(c,"seafood","fish")||any(n,"balik","balikci");
            case "kahvalti":return any(c,"breakfast")||any(n,"kahvalti");
            default:return false;
        }
    }
    private static boolean sea(String n,String c,String id){
        if(any(c,"market","grocery","store","shop","restaurant","cafe","hotel","office")) return false;
        boolean beach=any(c,"beach","bathing","swimming","shore","waterfront")||any(n,"plaj","beach","sahil");
        if("plaj".equals(id)||"sig_kum".equals(id)) return beach;
        if("sakin_koy".equals(id)) return beach&&any(n,"koy","bay","buku");
        return false;
    }
    private static boolean discover(String n,String c,String id){
        if(any(c,"restaurant","cafe","food","market","store","hotel","bar","nightclub"))return false;
        switch(id){
            case "magara":return any(c,"cave","cavern","geological","natural attraction")&&(any(n,"magara","cave","cavern")||any(c,"cave","cavern"));
            case "muze":return any(c,"museum");
            case "kale":return any(c,"castle","fort","historic","monument")&&(any(n,"kale","castle","fort")||any(c,"castle","fort"));
            case "antik":return any(c,"archaeological","historic","ruins","monument")&&(any(n,"antik","ancient","arkeoloji","ruin","harabe","kent")||any(c,"archaeological","ruins"));
            case "tarihi":return any(c,"historic","monument","archaeological","museum","castle","fort");
            default:return false;
        }
    }
    private static boolean stay(String n,String c,String id){
        if(any(c,"restaurant","cafe","market","store"))return false;
        switch(id){
            case "otel":return any(c,"hotel","resort","motel","lodging")||any(n,"otel","hotel");
            case "pansiyon":return any(c,"guest house","bed and breakfast","hostel","lodging")||any(n,"pansiyon","guesthouse");
            case "apart":return any(c,"apartment","lodging","hotel")&&any(n,"apart","apartment","residence");
            case "kamp":return any(c,"campground","camping")||any(n,"kamp","camp");
            default:return false;
        }
    }
    private static boolean any(String h,String...ns){for(String x:ns)if(h.contains(CuratedData.norm(x)))return true;return false;}
}
